# A14b — The Pauline Baynes Map (Companion l. 3059–3159) + Latitude Statements
[T] = Tolkien-quoted; [CT] = Christopher Tolkien; [H&S] = editorial.

## Setup
- [H&S] 1969: Baynes commissioned for poster map; published by Allen & Unwin 1970. Tolkien "sent her a marked photocopy of the general map, as well as additional names to include and advice on a few points of topography and nomenclature (e.g. that Ciril etc. should be spelled with C rather than K)." "The following additions were supplied by Tolkien:"

## Tolkien-supplied added names, with stated positions (positions quoted whole, per instruction)
- The Adorn — "a tributary of the River Isen which flows into it from the west of the Ered Nimrais (mentioned in Appendix A)."
- Andrast — Sindarin "long cape"; "the 'dark cape of Ras Morthil' at the end of the northern arm of the Bay of Belfalas" (Aldarion and Erendis, UT 175).
- The Drúwaith Iaur (Old Púkel-land) — "between the River Isen and the Ered Nimrais." [T, The Drúedain, UT 384]: the mountainous region of the promontory of Andrast was called "'the Old Púkel-wilderness' (Drúwaith Iaur)." [CT, UT 387 n. 13, on its placement]: "placed well to the north of the mountains of the promontory of Andrast. My father stated however that the name was inserted by him and was correctly placed."
- Edhellond — "an ''Elf-haven'' [edhel 'elf' + lond 'haven'] in Belfalas near the confluence of the rivers Morthond and Ringló, north of Dol Amroth" (UT 431–2). [T, ATB Preface p. 8]: "In the Langstrand and Dol Amroth there were many traditions of the ancient Elvish dwellings, and of the haven at the mouth of the Morthond from which 'westward ships' had sailed as far back as the fall of Eregion in the Second Age." [H&S elsewhere, l. 17081–87]: "On his instructions, Pauline Baynes placed the haven at the mouth of the Morthond on her decorated map with the name Edhellond"; Christopher therefore included it on the 1980 map.
- Éothéod — (OE "horse-people"/"horse-land") "in the far North near the sources of the Anduin."
- Eryn Vorn — (Sindarin "dark wood", i.e. "Blackwood") "a cape at the mouth of the Baranduin"; refuge of Minhiriath's native forest-dwellers fleeing Númenórean deforestation (Rivers and Beacon-hills; UT 262–3). First printing misspelled "Erin Voru".
- Framsburg — "near Éothéod"; presumably stronghold of Fram son of Frumgar, slayer of Scatha.
- Lond Daer — [T, Rivers and Beacon-hills]: "one of the earliest ports of the Númenóreans, begun by the renowned mariner-king Tar-Aldarion… It was called Lond Daer Enedh, the Great Middle Haven (as being between Lindon in the North and Pelargir on the Anduin)"; sited "at the head of the estuary of the Gwathló" on the sea-route to "the river-port of Tharbad" (UT 264 n.). [CT] = Vinyalondë.
- The Undeeps — "two great westward bends in the Anduin between the Brown Lands and the Wold of Rohan." [T, late note, UT 260]: "the great loops of the Anduin (where it came down swiftly past Lórien and entered low flat lands before its descent again into the chasm of the Emyn Muil)"; it "had many shallows and wide shoals over which a determined and well-equipped enemy could force a crossing by rafts or pontoons, especially in the two westward bends, known as the North and South Undeeps."

## Errors on the Baynes map
- [H&S] "R. Swanfleet is erroneously written on the map to mark the lower course of the river whose upper course is labelled R. Glanduin"; Swanfleet (Nîn-in-Eilph) is really the FENS at the Glanduin–Gwathló confluence near Tharbad. Label corrected in a later printing, "among a handful of other errors, chiefly misreadings of the source maps provided to the artist, or continuation of errors on the 1954 map."
- Adorn, Glanduin, Swanfleet later copied onto the general LotR map (A&U printings from 1969) — with Swanfleet/Glanduin "applied to the upper course of the Isen, far to the south of the correct location" (see A14d).

## NOT in the Companion's Baynes list
- Dorwinion, Thranduil's halls: the word "Dorwinion" does not occur anywhere in the Companion; no Baynes-list entry for Thranduil's halls is given. (Companion's Baynes list = the nine items above only.)

## Latitude / climate statements (verbatim, whole)
- [T, letter to Charlotte and Denis Plimmer, 8 Feb 1967, Letters 376; quoted in maps front-matter l. 3018–27]: "The action of the story [The Lord of the Rings] takes place in the North-west of 'Middle-earth', equivalent in latitude to the coastlands of Europe and the north shores of the Mediterranean. But this is not a purely 'Nordic' area in any sense. If Hobbiton and Rivendell are taken (as intended) to be at about the latitude of Oxford, then Minas Tirith, 600 miles south, is at about the latitude of Florence. The Mouths of the Anduin and the ancient city of Pelargir are at about the latitude of ancient Troy." (H&S introduce this "purely as analogies of location".)
- No Umbar latitude statement occurs in the Companion.
- [H&S citing J.A. Schulp, 'The Flora of Middle-earth', l. 23582–88]: "North Ithilien is 600 miles South of the Shire. The Shire being comparable in climate and vegetation with Middle or South England, Tolkien is justified in confronting the readers with an all-Mediterranean vegetation."
- Related placement quote [T, Hunt for the Ring papers, l. 14795–98]: the Shire "is north-west from here [Isengard], some 600 miles, on the borders of the sea-ward Elvish country."
