# Geographic/Spatial Extraction: LOTR Book III, Chapters 1–4 (lines 19025–22528)

## III.1 THE DEPARTURE OF BOROMIR

**Amon Hen / Parth Galen complex**
- Aragorn runs from spring near hilltop "to the summit, across the great ﬂag-stones, and up the steps" — high seat on Amon Hen crowns the hill; view described as ranging full circle ("He turned from the North back again to North").
- Orc sounds "in the woodlands below, on the west side of the River" — battle glade is west of Anduin.
- **"A mile, maybe, from Parth Galen in a little glade not far from the lake he found Boromir"** — battle glade ≈1 mile from Parth Galen, near the lake (Nen Hithoel).
- Stones "nearer than the water-side" lacking — glade is inland, treed.
- **"It was a mile or more"** — Legolas and Gimli go back on foot from the water-side (near glade) to Parth Galen for boats; confirms ~1 mile spacing.
- Funeral route: "turning into the swift-running channel they passed the green sward of Parth Galen. The steep sides of Tol Brandir were glowing" — channel past Parth Galen runs by Tol Brandir; "As they went south the fume of Rauros rose" — Rauros south of Parth Galen; time "now mid-afternoon."
- Posthumous course: "bore him down through Osgiliath, and past the many mouths of Anduin, out into the Great Sea" — Anduin sequence: Rauros → Osgiliath → many mouths → Great Sea. Anduin called "The River of Gondor."
- Lament geography: West Wind "Through Rohan over fen and ﬁeld"; South Wind "From the mouths of the Sea... from the sandhills and the stones... wailing of the gulls" (mouths of Anduin southward, gull-coast); North Wind "From the Gate of Kings... past the roaring falls" — Gate of Kings (Argonath) north of Rauros; "Beneath Amon Hen I heard his cry"; "The Tower of Guard shall ever northward gaze / To Rauros" — Minas Tirith lies south of Rauros, within notional sight-line north.
- Hobbit prints at bank "close to where the rill from the spring trickled out into the River" — spring-rill enters Anduin at Parth Galen.
- Pursuit start: "The woods about the lake they left behind. Long slopes they climbed... They passed away, grey shadows in a stony land" — ascent west/north from lake into stony hills at dusk. Timing: Boromir fell before mid-afternoon; they leave as "afternoon was fading."

## III.2 THE RIDERS OF ROHAN

**Emyn Muil structure**
- "the highlands of the Emyn Muil ran from North to South in two long tumbled ridges. The western side of each ridge was steep and difﬁcult, but the eastward slopes were gentler, furrowed with many gullies" — two N–S ridges; west faces steep, east faces gentle. All-night scramble over "the crest of the ﬁrst and tallest ridge" into "a deep winding valley on the other side" (first=easternmost ridge is tallest).
- Route options debated: "Northward to take a straighter road to Isengard, or Fangorn... Or southward to strike the Entwash?" — Isengard/Fangorn NW; Entwash south of Emyn Muil.
- In valley: "went on for a mile or more northwards"; five dead orcs found at slope-foot.
- Dawn view west from western crest: **"far off to the left, thirty leagues or more, blue and purple stood the White Mountains, rising into peaks of jet, tipped with glimmering snows"** — White Mountains ≈30+ leagues SSW of NW Emyn Muil; snow-capped in late Feb.
- **"Below it twenty fathoms or more, there was a wide and rugged shelf which ended suddenly in the brink of a sheer cliff: the East Wall of Rohan. So ended the Emyn Muil"** — western scarp: 20-fathom drop to shelf, then sheer cliff to plain; scarp named East Wall of Rohan.
- **"They are many leagues away: twelve, I guess; but the ﬂatness of the plain is hard to measure"** — Legolas sights orc company 12 leagues off across plain.
- Descent: "a deep cleft carved in the rock by a stream... In the narrow ravine a rough path descended like a steep stair into the plain" — stream-cut stair through East Wall (the same "stair" Uglúk names).
- Plain: grass "swelled like a green sea up to the very foot of the Emyn Muil"; stream vanishes "down long gentle slopes towards the fens of Entwash Vale far away" — Entwash Vale fens SW/W, downslope.
- Climate: "They seemed to have left winter clinging to the hills behind. Here the air was softer and warmer" — Rohan plain milder than Emyn Muil.
- Trail bearing: "Nearly due west the broad swath of the marching Orcs."

**Pursuit log (day-by-day)**
- Day 1 of run ends: "One day now had passed since Boromir fell"; **"twelve leagues now lay between them and the eastern wall where they had stood at dawn"** — 12 leagues covered from East Wall, two brief rests only. They halt for the night (moon young, sets early).
- Day 3 of pursuit ("So the third day of their pursuit began" — counting from evening departure): trail "straight on, going north-west without a break"; "Far away to the left the river Entwash wound, a silver thread."
- Rohirrim settlement: "The dwellings of the Rohirrim were for the most part many leagues away to the South, under the wooded eaves of the White Mountains"; "the Horse-lords had formerly kept many herds and studs in the Eastemnet, this easterly region of their realm" — Eastemnet = eastern grazing region; dwellings along White Mountains' skirts.
- Day 3 dusk: **"Now twice twelve leagues they had passed over the plains of Rohan"** — cumulative 24 leagues across the plain; Emyn Muil "lost in the shadows of the East."
- "north lies our road between down and fen" — corridor between downs (W) and Entwash fens (E).
- Day 4: downs reached "an hour before noon": "green slopes rising to bare ridges that ran in a line straight towards the North. At their feet... a long strip of sunken land, **some ten miles wide**, lay between them and the river wandering deep in dim thickets of reed and rush" — downs separated from Entwash by 10-mile sunken strip. Orc camp-ring "Just to the West of the southernmost slope."
- Freshness estimate: "it is thrice twelve hours, I guess, since the Orcs stood where we now stand" (36 hours); "at sundown yesterday they would reach the borders of Fangorn."
- Aragorn's reckoning: **"these downs run eight leagues or more to the north, and then north-west to the issuing of the Entwash there lies still a wide land, another ﬁfteen leagues it may be"** — downs 8 leagues N–S; downs-end to Entwash's issuing from Fangorn ≈15 leagues NW.
- Day 4 sunset: at "the most northerly of the downs," a "round hill smooth and bare, standing by itself." View NW: "the Mountains of Mist and the forest at their feet." Wind shifts: "north from the snows," then East by morning. "Three suns already have risen on our chase."
- Day 5 dawn from hill: "Ahead and eastward... the windy uplands of the Wold of Rohan that they had already glimpsed many days ago from the Great River" (Wold visible E, seen earlier from Anduin); **"North-westward stalked the dark forest of Fangorn; still ten leagues away stood its shadowy eaves"**; "Beyond there glimmered far away... the white head of tall Methedras, the last peak of the Misty Mountains" — Methedras beyond Fangorn's far slopes. "Out of the forest the Entwash ﬂowed to meet them, its stream now swift and narrow, and its banks deep-cloven" — upper Entwash issues from Fangorn.
- Riders: Legolas counts "one hundred and ﬁve"; **"The riders are little more than ﬁve leagues distant"** — elf-sight resolves riders/hair at ~5 leagues.

**Éomer's data**
- Éomer's éored rides "back southward along the western skirts of the downs"; spear "within a foot of Aragorn's breast."
- "scouts warned me of the orc-host coming down out of the East Wall four nights ago" — orc descent 4 nights before.
- "we overtook the Orcs at nightfall two days ago, near to the borders of the Entwood. There we surrounded them, and gave battle yesterday at dawn. Fifteen of my men I lost, and twelve horses" — battle at Fangorn's border ("Entwood"), dawn of previous day; mound with **fifteen spears** later seen "not far from the river, where it came streaming out from the edge of the wood."
- Reinforcements "coming out of the East across the Great River: their trail is plain to see a little north of this spot."
- Fears "a league between Orthanc and the Dark Tower" [political "league," noted to avoid confusion].
- "There is battle even now upon the Westemnet" — Westemnet = western region, war zone.
- Éomer is "Third Marshal of Riddermark"; charge "The East-mark"; "I have removed all our herds and herdfolk, withdrawing them beyond Entwash" — Entwash as defensive line.
- Loan condition: "return with the horses over the Entwade to Meduseld, the high house in Edoras where Théoden now sits" — Entwade = Entwash crossing on route to Edoras; éored ordered "to assemble on the path, and make ready to ride to the Entwade."
- Saruman "has closed the Gap against us" — Gap of Rohan blocked; Rohan "likely to be beset both east and west."
- **The famous quote (context)**: Aragorn: "It is now the fourth day since he was slain... since the evening of that day we have journeyed from the shadow of Tol Brandir." Éomer: **"Forty leagues and ﬁve you have measured ere the fourth day is ended! Hardy is the race of Elendil!"** — 45 leagues Tol Brandir→northernmost down, evening of Day 0 to morning of Day 4 (i.e., before the fourth day's end).
- Ride to battlefield: "Before long they came to the borders of the Entwash, and there they met the other trail... coming down from the East out of the Wold" — Mordor-orc trail descends from the Wold to Entwash banks. "As the afternoon was waning they came to the eaves of the forest" — horseback, Entwash-crossing area to Fangorn eaves by late afternoon; battlefield glade "among the ﬁrst trees," burning-place with orc-head on stake; Rohirrim mound nearby by the river.
- Camp "A little way beyond the battle-ﬁeld... under a spreading tree"; "We are near to the mountain-marches of the traitor Saruman. Also we are on the very edge of Fangorn." Old-man apparition; horses flee. "endless leagues lay between them and the Men of Rohan."
- Fangorn lore: "as old as the forest by the Barrow-downs, and it is far greater. Elrond says that the two are akin, the last strongholds of the mighty woods of the Elder Days."

## III.3 THE URUK-HAI

**Captors' route (mirror of pursuit)**
- Uglúk's plan: **"We go straight west from here, and down the stair. From there straight to the downs, then along the river to the forest. And we march day and night"** — full itinerary: Emyn Muil → stair (East Wall descent) → downs → along Entwash → Fangorn.
- Grishnákh crossed Anduin: "A winged Nazgûl awaits us northward on the east-bank"; others: "there are not enough of us to venture down to the bridges" — bridges (Osgiliath) far south; Nazgûl not yet allowed "across the Great River."
- Cliff halt: "on the edge of a cliff that seemed to look out over a sea of pale mist. There was a sound of water falling nearby" — East Wall brink with waterfall; descent by "a narrow ravine leading down into the misty plain below."
- "Now straight on!... West and a little north" — bearing on the plain.
- **"They had gone only a mile or so from the cliff"** when Pippin dashes aside in "a wide shallow depression, where the ground was soft and wet" and drops his brooch — brooch site ≈1 mile W of East Wall.
- Northerners can't run in sun; forced march anyway ("Run while night lasts!").
- Morning halt: "by the banks of a swift narrow river. Ahead mountains loomed: a tall peak was catching the ﬁrst rays of the sun. A dark smudge of forest lay on the lower slopes" — upper Entwash bank, Methedras ahead, Fangorn on lower slopes; over a hundred Northerners flee "along the river towards the mountains."
- Grishnákh returns with "a couple of score" Red-Eye orcs "eastward" — from Anduin side.
- Sunset: "the sun was sinking, falling behind the Misty Mountains"; Riders herd orcs "along the line of the river."
- Final stand: "the Orcs came to a hillock. The eaves of the forest were very near, probably no more than **three furlongs** away" — knoll 3 furlongs from Fangorn; "fully two hundred remained."
- Watch-fires "a complete ring... within a long bowshot."
- Grishnákh's escape bid: "out into the night, down the slope and away westward towards the river that ﬂowed out of the forest" (Entwash flows out of forest W of knoll); "After going a dozen yards he halted."
- Hobbits crawl "to the edge of the river, gurgling away in the black shadows under its deep banks" — deep-banked Entwash beside knoll; banks "too steep" to drink.
- Merry's orientation: **"We are walking west along the Entwash. The butt-end of the Misty Mountains is in front, and Fangorn Forest"** — Misty Mountains' southern end ("butt-end") directly W.
- Dawn: "Far over the Great River, and the Brown Lands, leagues upon grey leagues away, the Dawn came" — Brown Lands beyond Anduin to the E.
- Uglúk slain "at the very edge of Fangorn" by Éomer; smoke of burning "seen by many watchful eyes."

## III.4 TREEBEARD

**Into Fangorn**
- Hobbits follow "the line of the running stream, westward and up towards the slopes of the mountains, deeper and deeper into Fangorn" — Entwash as guide-line, rising W. Air "stuffy"; Pippin: "Nothing to eat for a hundred miles, I should guess" [hyperbole]; lembas left = "fragments for about ﬁve meagre days."
- Climate/vegetation: lichen-bearded trees, "ragged dry leaves that have never fallen"; unlike Mirkwood ("all dark and black").
- Treebeard's hill: "a rock-wall... the side of a hill, or the abrupt end of some long root thrust out by the distant mountains"; stair "rough and uneven"; shelf "High up, almost level with the tops of forest-trees."
- **"They saw that they had only come some three or four miles into the forest"** — hill 3–4 miles inside eaves; smoke of the burning visible "near the fringe."
- Treebeard: "at least **fourteen foot** high"; feet with seven toes.
- Fangorn = Treebeard's own name for himself; forest is "my country."
- Ancient extent: **"there was all one wood once upon a time from here to the Mountains of Lune, and this was just the East End"** — primeval forest Fangorn↔Lune; Ent-names for the wood: "Ambaróna, in Tauremorna, in Aldalómë... Tauremornalómë."
- Song-geography (First Age, "now under the wave"): Tasarinan/Nan-tasarion willow-meads (Spring), Ossiriand elm-woods "by the Seven Rivers of Ossir" (Summer), Neldoreth beeches/Taur-na-neldor (Autumn), Dorthonion pines/Orod-na-Thôn highland (Winter).
- Bad spots: "hollow dales in this land where the Darkness has never been lifted, and the trees are older than I am."

**Wellinghall**
- Approach at dusk: "they had come to the feet of the mountains, and to the green roots of tall Methedras. Down the hillside the young Entwash, leaping from its springs high above, ran noisily from step to step" — **Entwash springs high on Methedras**; treeless grass slope right of stream.
- Hall: "the ﬂoor of a great hall had been cut in the side of the hill... walls sloped upwards, until they were **ﬁfty feet high or more**"; bay with arched roof; spring-curtain falls down sheer wall into stone basin, "out to rejoin the Entwash."
- **"I have brought you about seventy thousand ent-strides"** (edge of forest → Wellinghall); "we are near the roots of the Last Mountain. Part of the name of this place might be Wellinghall" — Methedras = "the Last Mountain."
- Stone table "six feet above the ground"; bed "not more than a couple of feet high."
- Skinbark (Fladrif) "lived on the mountain-slopes west of Isengard... He has gone up into the high places" — Ent-country extends W of Isengard.
- Entwives: "crossed the Great River, and made new gardens" — their land east of Anduin; "all the gardens of the Entwives are wasted: Men call them the **Brown Lands** now"; "We crossed over Anduin and came to their land; but we found a desert."

**Derndingle & the march**
- "We shall meet in the place where we have always met: Derndingle Men call it. It is away south from here. We must be there before noon" — Derndingle south of Wellinghall, reachable in a morning.
- Route: "turned to the right, stepped over the stream, and strode away southwards along the feet of great tumbled slopes"; birch/rowan thickets above, "dark climbing pinewoods" higher — altitudinal zoning on Methedras' skirts. Pippin loses stride-count "at about three thousand."
- Derndingle: "a great dingle, almost as round as a bowl, very wide and deep, crowned at the rim with the high dark evergreen hedge... no trees except three very tall... silver-birches... at the bottom. Two other paths led down... from the west and from the east"; well "away yonder in the north bank." ~2 dozen Ents + as many arriving; Entmoot lasts from before noon Day 1 to afternoon Day 3.
- View from W lip: "above the ﬁr-trees of the furthest ridge there rose, sharp and white, the peak of a high mountain"; Merry: "that peak is probably Methedras, and as far as I can remember **the ring of Isengard lies in a fork or deep cleft at the end of the mountains**. It is probably down behind this great ridge"; smoke/haze "left of the peak." Southwards "the forest falling away... a pale green glimmer... the plains of Rohan."
- Merry's hearsay Isengard: "a sort of ring of rocks or hills... with a ﬂat space inside and an island or pillar of rock in the middle, called Orthanc... a stream running through it; it comes out of the mountains, and ﬂows on across the Gap of Rohan" — Isen source in mountains, crossing the Gap.
- March: Treebeard + "some ﬁfty followers," "marched southwards"; huorn-groves follow.
- Final leg: "descended into a long fold of the land that fell away southward; now they began to climb up... on to the high western ridge" — bare slopes, gaunt pines near crest; sunset behind "the dark hill-back in front."
- **"At last they stood upon the summit, and looked down into a dark pit: the great cleft at the end of the mountains: Nan Curunı́r, the Valley of Saruman"** — Nan Curunír = cleft at the Misty Mountains' end, holding Isengard; reached at nightfall from Derndingle in one afternoon–evening march.

**Numeric register (all figures in span)**: 1 mile (glade↔Parth Galen, twice); 20+ at glade (slain orcs); 30 leagues (White Mts); 20 fathoms (scarp shelf); 12 leagues (sighted company); 12 leagues (day 1 run); 24 ("twice twelve") leagues cumulative; 36 h ("thrice twelve hours") trail age; 10 miles (sunken strip); 8 leagues (downs length); 15 leagues (downs→Entwash issuing); 10 leagues (to Fangorn eaves); 105 riders; 5 leagues (riders' distance); 45 leagues/4 days (Tol Brandir→downs); 4 nights (orc descent from East Wall); 15 men/12 horses lost, 15 spears; 1 mile (brooch from cliff); 3 furlongs (knoll→forest); 200 orcs remaining; 100+ fleeing Northerners; ~80 ("four score") Isengarders, ~40 ("couple of score") Grishnákh's; dozen yards (Grishnákh's creep); 3–4 miles (into forest); 14 ft (Treebeard); 100 miles ("nothing to eat," guess); 5 days (lembas); 50 ft (Wellinghall walls); 70,000 ent-strides; 6 ft (table); 2 ft (bed); ~3,000 (Pippin's stride-count); ~50 (marching Ents); ~24+24 (Ents at Moot).