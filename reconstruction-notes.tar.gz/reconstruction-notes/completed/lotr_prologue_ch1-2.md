Notes written to A1_part1.md. Distilled extraction for lines 918–3633 (Prologue; Ch 1 A Long-expected Party; Ch 2 The Shadow of the Past):

GAZETTEER
1. Shire | region | NW Old World settlement of hobbits; between Brandywine and Far Downs; four Farthings (N/S/E/W) + Buckland (East March) + Westmarch (added S.R. 1452) | "all the land beyond to dwell in, between the river and the Far Downs" | Prologue §1, §3
2. Brandywine/Baranduin | river | "the brown river Baranduin"; E border of Shire proper; Buckland lies east of it; Marish "down by the Brandywine" | "they crossed the brown river Baranduin" | Prologue §1
3. Brandywine Bridge (Bridge of Stonebows/Great Bridge) | bridge | E end of Shire's 40-league E–W span; built by North Kingdom | "passed over the Bridge of Stonebows" | Prologue §1
4. Far Downs | hills | W end of 40-league span | "between the river and the Far Downs" | Prologue §1
5. Tower Hills | hills | "beyond the western marches"; bear three Elf-towers; tallest furthest west on green mound; Sea visible from its top (hobbit report) | "Three Elf-towers... on the Tower Hills beyond the western marches" | Prologue §1
6. Grey Havens | haven | "away to the west"; terminus of East–West Road; elven-ships sail thence | "the ancient East–West Road ran through the Shire to its end at the Grey Havens" | Ch 2 / Prologue §1
7. White Downs | downs | site of Michel Delving, chief township; Free Fair held there | "Michel Delving on the White Downs" | Prologue §1, §3
8. Michel Delving | town | chief township; in Westfarthing; has Mathom-house museum | "the museum at Michel Delving" | Prologue §1; Ch 1
9. Hobbiton | village | "hilly regions and the older villages, such as Hobbiton or Tuckborough"; contains the Hill/Bag End | Prologue §1; Ch 1
10. The Hill & Bag End | hill/smial | Bagshot Row No. 3 "just below Bag End"; garden window "looking out west"; party field "south of Bilbo's front door"; road up the Hill from Bywater | "They lived on the Hill itself, in Number 3 Bagshot Row" | Ch 1
11. Bywater | village | on road between Brandywine Bridge direction and Hobbiton; The Green Dragon and Ivy Bush ("on the Bywater road") inns; the Water adjacent (fireworks "came down again into the Water," dragon "burst over Bywater") | Ch 1, Ch 2
12. Tuckborough | village | older hilly village; Great Smials; library | Prologue §1; Note on Shire Records
13. Tookland | folkland | "Nearly all Tooks still lived in the Tookland" | Prologue §3
14. Marish | farmland | Eastfarthing "down by the Brandywine"; Stoor-blooded folk; came "up from south-away" | Prologue §1
15. Buckland | march | "east of the River"; occupied after Marish; Brandy Hall (Gorbadoc: "couple of hundred relations"); "right agin the Old Forest"; Bucklebury library | Prologue §1, §3; Ch 1
16. Old Forest | forest | adjoining Buckland; "That's a dark bad place" | Ch 1
17. Northfarthing/North Moors | region | tree-man "seen up away beyond the North Moors"; no elms there; Overhill village near Hobbiton (Hal works there, hunts in Northfarthing) | Ch 2
18. Longbottom | village | Southfarthing; pipe-weed heartland, "warm sheltered places like Longbottom"; Old Winyards wine also Southfarthing | Prologue §2; Ch 1
19. Bree | town | "some forty miles east of the Shire"; with Chetwood "round about"; "ancient road-meeting"; Prancing Pony inn (Butterbur family); pipe-weed "on the south slopes of the hill" | Prologue §1, §2
20. Chetwood | wood | "lay round about" Bree | Prologue §1
21. Fornost (Norbury) | ruined city | "away north of the Shire"; seat of high king; "ruins of Kings' Norbury were covered with grass"; last battle vs Witch-lord of Angmar there | Prologue §1, §3
22. Eriador | region | "the westlands of Eriador, between the Misty Mountains and the Mountains of Lune"; North Kingdom lands "falling far and wide into waste" | Prologue §1
23. Mountains of Lune / Blue Mountains | mountains | W bound of Eriador; dwarf "mines in the Blue Mountains" reached by E–W Road | Prologue §1; Ch 2
24. Misty Mountains | mountains | E bound of Eriador; crossed by migrating hobbits; high pass where Bilbo's party was assailed; orc-mines with "lower gates... on the eastward side"; cold lake with Gollum's island at "the roots of the mountains" | Prologue §1, §4
25. Anduin/Great River | river | hobbits' first home "upper vales of Anduin, between the eaves of Greenwood the Great and the Misty Mountains"; Stoors "lingered long by the banks"; Sméagol's folk "by the banks... on the edge of Wilderland" | Prologue §1; Ch 2
26. Gladden Fields | marsh/river-field | "near the Gladden Fields" Isildur ambushed "marching north along the east banks of the River"; "great beds of iris and flowering reeds"; "dark pools"; downstream ("went down") of Sméagol's home | Ch 2
27. Greenwood the Great / Mirkwood | forest | renamed when "a shadow fell on the forest"; Sauron's hold before returning to Mordor; Wood-elves dwell there (hold Gollum); Gollum tracked "through Mirkwood and back", exit at "western edge" | Prologue §1; Ch 2
28. Loudwater | river | Stoors "followed the course of the Loudwater southwards" to between Tharbad and Dunland | Prologue §1
29. Hoarwell | river | Fallohides "crossed the mountains north of Rivendell and came down the River Hoarwell" | Prologue §1
30. Tharbad & Dunland | crossing/region | Stoors "long dwelt between Tharbad and the borders of Dunland before they moved north again" | Prologue §1
31. Rivendell | valley-refuge | mountains crossable "north of Rivendell"; Bilbo took diary there; Elrond's sons remained after him | Prologue §1; Note on Shire Records
32. Weathertop | hill | Harfoots "roamed over Eriador as far as Weathertop" | Prologue §1
33. Greenway | road | pipe-weed "carried up the Greenway" from Gondor-ward lands | Prologue §2
34. East–West Road | road | "ran through the Shire to its end at the Grey Havens"; dwarves' route | Ch 2
35. Erebor/the Mountain & Dale | mountain/town | "the Kings under the Mountain, beneath Erebor in Dale, far off in the East"; toys "from the Mountain and from Dale" | Prologue §4; Ch 1
36. Esgaroth | town | "at Esgaroth on the Long Lake" (Bilbo's barrel arrival); Gollum's feet "taken him at last to Esgaroth" | Ch 1, Ch 2
37. Wilderland | region | lands E of Misty Mountains; Gollum hunted "down the whole length of Wilderland" | Prologue §1; Ch 2
38. Mordor | land | "the old strongholds of Mordor"; "Dark Tower had been rebuilt"; ring-verse "In the Land of Mordor where the Shadows lie"; Gollum went "south, down at last to the Land of Mordor" | Ch 2
39. Orodruin | volcano | "the Cracks of Doom in the depths of Orodruin, the Fire-mountain" | Ch 2
40. Eregion | region | "In Eregion long ago many Elven-rings were made" | Ch 2
41. Gondor/Arnor/Belfalas/Lune | realms/coasts | Westron "current through all the lands of the kings from Arnor to Gondor, and about all the coasts of the Sea from Belfalas to Lune"; pipe-weed "grows abundantly in Gondor" | Prologue §1, §2
42. Minas Tirith | city | Thain's Book kept there; Peregrin retired to Gondor IV 64 | Note on Shire Records
43. Undertowers | dwelling | home of Fairbairns, Wardens of Westmarch; Red Book kept there | Note on Shire Records
44. Overhill | village | Hal "works for Mr. Boffin at Overhill" | Ch 2

MEASUREMENTS (every numeric)
1. "some forty miles east of the Shire" — Bree from Shire | Prologue §1
2. "Forty leagues it stretched from the Far Downs to the Brandywine Bridge, and fifty from the northern moors to the marshes in the south" — Shire size | Prologue §1
3. Hobbit height "between two and four feet of our measure"; "seldom now reach three feet"; Bandobras Took "four foot five" | Prologue §1
4. T.A. 1601 Shire founded; convert "by adding 1600 to the dates of Shire-reckoning" | Prologue §1
5. Northern line ended "three hundred years later" (after Argeleb II) | Prologue §1 fn
6. Battle of Greenfields S.R. 1147; Days of Dearth "1158–60"; Dark Plague S.R. 37; "a thousand years they were little troubled by wars" | Prologue §1
7. Pipe-weed grown "about the year 1070 of Shire-reckoning" | Prologue §2
8. Westmarch added "S.R. 1452"; twelve Shirriffs, "three in each Farthing" | Prologue §3
9. Quest set out April 1341 S.R.; Bilbo returned "June the 22nd... (S.R. 1342)"; party S.R. 1401, Sept 22; "no king for nearly a thousand years" | Prologue §3–4
10. Tree-man "as big as an elm tree, and walking... seven yards to a stride" | Ch 2
11. Gandalf: away 3 years after party, frequent "next year or two," then "over nine years since Frodo had seen... him" | Ch 2
12. Gollum left mountains "After a year or two" of Bilbo's escape | Ch 2
13. Elrond's sons, Celeborn at Rivendell into Fourth Age (no distances) | Note on Shire Records

ITINERARIES
1. Hobbit migrations: upper Anduin vales → over Misty Mountains into Eriador. Harfoots earliest, "as far as Weathertop"; Stoors via "course of the Loudwater southwards" to Tharbad–Dunland, later north again; Fallohides crossed "north of Rivendell," descended Hoarwell. No durations | Prologue §1
2. Marcho & Blanco, T.A. 1601: Bree → over Baranduin at Bridge of Stonebows → settled to Far Downs. Mode: "a great following of Hobbits" on foot/wagon [ambig] | Prologue §1
3. Marish/Buckland folk entered Shire "up from south-away" | Prologue §1
4. Bilbo's quest (recap): Bag End (April 1341) → high pass, Misty Mountains (orc capture) → under-mountain tunnels → out "lower gates... on the eastward side" → (later) Erebor; returned June 22, 1342. Home "in the West" of return journey openly known | Prologue §4; Ch 2
5. Gollum: Anduin-bank home → "up the River" → up mountain stream into cave → (long after) out, "into Mirkwood" → Esgaroth/Dale → "back westward, as far as the Great River," turned aside → south from "western edge of Mirkwood" → Mordor → caught returning; imprisoned by Wood-elves | Ch 2
6. Gandalf's cart approached Hobbiton "through Bywater from the direction of Brandywine Bridge" | Ch 1
7. Isildur (historic): "marching north along the east banks of the River," ambushed near Gladden Fields | Ch 2

CONTRADICTIONS & ODDITIES
1. "beneath Erebor in Dale" (Prologue §4) — phrasing makes Erebor sound located "in Dale"; elsewhere Dale is a town mark on crackers, the Mountain distinct ("from the Mountain and from Dale," Ch 1).
2. Shire dimensions give E–W 40 leagues but Bree is "forty miles east of the Shire" — units switch league/mile in adjacent sections; no conversion stated in text.
3. "northern moors to the marshes in the south" (Prologue) vs Ch 2's "North Moors" as apparently local Northfarthing feature — same feature? [ambig]
4. Frodo's "cross the River" (Ch 2) river unnamed [ambig — Brandywine implied by context].

WORLD-STRUCTURE
1. "the North-West of the Old World, east of the Sea"; "the shape of all lands has been changed" since the Third Age | Prologue §1
2. Dúnedain "came over the Sea out of Westernesse"; pipe-weed "originally brought over Sea by the Men of Westernesse" | Prologue §1–2
3. Grey Havens: "elven-ships set sail, never to return"; Elves "sailing over the Sea... going into the West and leaving us"; distance to Sea unknown to hobbits ("neither he nor any of them knew how far it was to the Sea") | Ch 2
4. Sea seen from tallest Elf-tower per Westfarthing hobbits; Sea "a token of death"; hobbits "turned their faces away from the hills in the west" | Prologue §1
5. Westron spoken "about all the coasts of the Sea from Belfalas to Lune" | Prologue §1
6. "run off into the Blue" as idiom for vanishing into distance | Ch 2

Comprehensive notes (with line numbers) are at scratchpad/notes/parts/A1_part1.md.