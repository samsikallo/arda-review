I have read the full range (lines 9107–11594), covering all four chapters. Here is the extracted spatial evidence.

**Chapter key:** Ch.20 = Nirnaeth Arnoediad; Ch.21 = Túrin Turambar; Ch.22 = Ruin of Doriath; Ch.23 = Tuor & Fall of Gondolin.

---

## A) GAZETTEER

Format: Name | type | spatial relations | verbatim quote | chapter

1. **Tol Galen** | green isle | in midst of Adurant, beyond R. Gelion, in Ossiriand | "passed beyond the River Gelion into Ossiriand, and dwelt there in Tol Galen the green isle, in the midst of Adurant" | 20 (also 22)
2. **Dor Firn-i-Guinar / Land of the Dead that Live** | region | =Ossiriand country around Tol Galen | "The Eldar afterwards called that country Dor Firn-i-Guinar" | 20
3. **Anfauglith** | plain/desert | Maedhros to march over it; between the two hosts; Haudh raised in its midst | "purposed to march…in open force over Anfauglith" | 20
4. **Dorthonion** | highland | freed for a while; beacon-signal site | "the firing of a great beacon in Dorthonion" | 20
5. **Eithel Sirion / Barad Eithel** | fortress | Fingon's walls; W end of battle-front | "Fingon looked out from the walls of Eithel Sirion" | 20
6. **Ered Wethrin (Mountains of Shadow)** | mountains | Fingon's host in valleys/woods E of it; shadow falls E | "his host was arrayed in the valleys and the woods upon the east of Ered Wethrin" | 20
7. **Thangorodrim** | peaks | Fingon looks toward it; Húrin's stone-chair set on it | "Fingon looked towards Thangorodrim" | 20
8. **Himring** | hill/seat | Maedhros's; Fingon took counsel with it | "Fingon…took counsel with Himring" | 20
9. **Fen of Serech** | fen | inflow of Rivil; E end of battle-front; Húrin's last stand behind it | "from the walls of the fortress of Eithel Sirion to the inflowing of Rivil at the Fen of Serech" | 20
10. **Rivil** | stream | inflows at Fen of Serech; before Húrin at last stand | "had the stream of Rivil before them" | 20
11. **Angband / the Gate** | fortress | assaulted E and W; Fingon's banners raised before its walls | "the banners of Fingon…were raised before the walls of Angband" | 20
12. **Pass of Sirion** | pass | Gondolin host stationed southward guarding it; Turgon's retreat | "they had been stationed southward guarding the Pass of Sirion" | 20
13. **Mount Dolmed** | mountain | in the east; Fëanorians escape toward it | "escaped far away towards Mount Dolmed in the east" | 20 (also 22)
14. **Ered Lindon (Blue Mts)** | mountains | Fëanorians dwell "beneath the feet of" it | "a wild and woodland life beneath the feet of Ered Lindon" | 20
15. **Nan-tathren (Land of Willows)** | region | southern reach of Orc raids, by Ossiriand borders | "even as far as Nan-tathren, the Land of Willows, and the borders of Ossiriand" | 20 (also 23)
16. **Brithon & Nenning** | rivers | Morgoth's force came down them onto the Falas | "came down the rivers Brithon and Nenning and ravaged all the Falas" | 20
17. **Brithombar & Eglarest** | havens | on the Falas; walls besieged & broken | "besieged the walls of Brithombar and Eglarest" | 20
18. **Barad Nimras** | tower | of the Falas; cast down | "the tower of Barad Nimras cast down" | 20
19. **Isle of Balar** | island | south; Círdan's refuge | "This remnant sailed with Círdan south to the Isle of Balar" | 20
20. **Mouths of Sirion** | delta | Círdan's foothold; hidden creeks | "they kept a foothold also at the Mouths of Sirion" | 20 (also 22,23)
21. **Nevrast** | region | Voronwë cast ashore there; Vinyamar site | "cast him ashore in Nevrast" | 20 (also 23)
22. **Haudh-en-Ndengin / Haudh-en-Nirnaeth** | mound | in midst of Anfauglith; hill seen from afar | "piled them in a great mound in the midst of Anfauglith…seen from afar" | 20 (Rían dies on it, 21)
23. **Dor-lómin** | region | Morwen's home; reached over mountains from Doriath; has southern mountains & passes | "Morwen abode still in Dor-lómin" | 21
24. **Doriath / Menegroth (Thousand Caves)** | realm/city | reached over the mountains from Dor-lómin; Girdle of Melian | "find entry…into the kingdom of Doriath" | 21,22
25. **Teiglin & Crossings of Teiglin** | river/ford | outlaws dwell S of it; on Orc road; Haudh-en-Elleth near | "wooded lands south of Teiglin" | 21 (recurs 21,22)
26. **Pass of Anach** | pass | road down from Taur-nu-Fuin; between Crissaegrim & Gorgoroth | "made a road through the Pass of Anach" | 21
27. **Crissaegrim** | peaks | far off; Anach lies E of them | "you have seen the peaks of the Crissaegrim far off" | 21 (also 22)
28. **Ered Gorgoroth** | walls | to the east of viewer; Anach between it and Crissaegrim | "to the east the dark walls of the Gorgoroth. Anach lies between" | 21
29. **Mindeb** | river | Anach lies above its high springs | "Anach lies between, above the high springs of Mindeb" | 21
30. **Dimbar** | region | falling under attack; N-marches; between Brithiach and Anach | "Dimbar which used to be in peace is falling under the Black Hand" | 21,22
31. **Amon Rûdh (Bald Hill)** | hill | far W of Túrin's camp; on edge of moorlands between vales of Sirion & Narog; bare seregon-crowned crest | "that hill stood upon the edge of the moor-lands…between the vales of Sirion and Narog" | 21 (far E, 22)
32. **Bar-en-Danwedh** | cave-house | Mîm's, within Amon Rûdh | "Enter into Bar-en-Danwedh, the House of Ransom" | 21
33. **Amon Obel** | hill | in midst of Brethil, north of Amon Rûdh; Ephel Brandir on it | "the forest of Brethil climbing green about Amon Obel in its midst" | 21
34. **Brethil** | forest | N of Amon Rûdh; eaves on Orc road; Amon Obel within | (as above) | 21,22
35. **Vale of Narog** | valley | W of Amon Rûdh, in shadow | "the Vale of Narog lay deep in the shadows between" | 21
36. **Nan Elmoth** | forest | Eöl's dwelling | "leave to dwell in Nan Elmoth" | 21
37. **Nargothrond / Doors of Felagund / Nulukkizdîn** | city | on R. Narog; caves first delved by Petty-Dwarves; bridge built from its Doors | "the caves of Nargothrond were discovered by them" | 21,22
38. **Minas Tirith (of Finrod)** | isle-tower | in long defile of Sirion, on ancient road | "past the isle where Minas Tirith of Finrod had stood" | 21
39. **Malduin** | river | land between it and Sirion on the road | "through the land between Malduin and Sirion" | 21
40. **Talath Dirnen / Guarded Plain** | plain | between Narog and Teiglin | "burned the Talath Dirnen, the Guarded Plain, between Narog and Teiglin" | 21
41. **Dor-Cúarthol (Land of Bow and Helm)** | region | between Teiglin and W march of Doriath | "all the region between Teiglin and the west march of Doriath" | 21
42. **Brithiach** | ford of Sirion | Beleg & Húrin cross it toward Dimbar | "he crossed over the Brithiach and journeyed through Dimbar" | 21,22
43. **Taur-nu-Fuin** | forest | Orcs' route; high slopes run down from it to Anfauglith | "the high slopes that ran down to the barren dunes of Anfauglith" | 21
44. **Lothlann** | plain | E; storm passed away over it | "the storm was passed away eastward over Lothlann" | 21
45. **Eithel Ivrin / Pools of Ivrin** | springs/lake | source of Narog, beneath Mts of Shadow | "the springs whence Narog rose beneath the Mountains of Shadow" | 21 (also 23)
46. **Narog** | river | Gwindor & Túrin go S along its banks to Nargothrond; bridge over it | "journeyed southward along the banks of Narog" | 21,22
47. **Ginglith** | river | Tumhalad lies between it and Narog | "the field of Tumhalad, between Ginglith and Narog" | 21
48. **Tumhalad** | field | between Ginglith and Narog | (as above) | 21
49. **Nenning / Falas** | river/coast | W limit of cleared land | "westward to the Nenning and the desolate Falas" | 21
50. **Meres of Twilight (Aelin-uial)** | wetland/ferries | hidden ferries; above Falls of Sirion | "hidden ferries at the Meres of Twilight, and they passed over Sirion" | 21,22
51. **Amon Ethir (Hill of Spies)** | hill | a league before Nargothrond's doors; Glaurung's head lay on it | "Amon Ethir, the Hill of Spies…a league before the doors of Nargothrond" | 21
52. **Esgalduin** | river | guarded bridge near its inflowing, at Doriath fences | "the guarded bridge nigh to the inflowing of Esgalduin" | 21
53. **Haudh-en-Elleth** | mound | near Crossings of Teiglin; Finduilas's grave | "laid her in a mound near that place, and named it Haudh-en-Elleth" | 21
54. **Ephel Brandir** | stockade | on Amon Obel, high in forest | "Ephel Brandir upon Amon Obel" | 21
55. **Dimrost / Nen Girith** | falls | where Celebros falls toward Teiglin | "Dimrost…where the tumbling stream of Celebros fell towards Teiglin" | 21
56. **Celebros** | stream | falls toward Teiglin at Nen Girith | (as above) | 21
57. **Cabed-en-Aras** | gorge | on Teiglin; narrow enough a deer might leap; Glaurung crosses; renamed Cabed Naeramarth | "the river ran in a deep and narrow gorge that a hunted deer might overleap" | 21,22
58. **Cabed Naeramarth (Leap of Dreadful Doom)** | gorge | =Cabed-en-Aras renamed; Túrin's mound & Stone; Tol Morwen | "it was named Cabed Naeramarth" | 21,22
59. **Echoriath / Encircling Mountains** | mountains | ring Gondolin; Húrin at their "dark feet" in Dimbar | "came to the dark feet of the Echoriath" | 22 (also 23)
60. **Way of Escape / Dry River** | blocked gate | old Gondolin entrance; arched gate buried | "the Dry River was blocked, and the arched gate was buried" | 22
61. **Tol Morwen** | isle/stone | Stone stands in water beyond new coasts | "still Tol Morwen stands alone in the water beyond the new coasts" | 22
62. **Sarn Athrad (Ford of Stones)** | ford | over Gelion; on Dwarf-road to Doriath; ambush site | "passing over Gelion at Sarn Athrad, the Ford of Stones" | 22
63. **Aros & Gelion** | rivers | perilous lands between them; Dwarves flee over Aros | "the perilous lands between Aros and Gelion" | 22
64. **Region** | forest | Dwarves flee eastward through it | "fled eastwards through Region" | 22
65. **Adurant / Ered Lindon** | river/mts | Adurant southernmost stream falling from Ered Lindon to Gelion; Tol Galen in it | "the River Adurant, southernmost of the streams that falling from Ered Lindon flowed down to join with Gelion" | 22
66. **Lanthir Lamath** | waterfall | beside Dior's house (Ossiriand); Elwing born there | "the waterfall of Lanthir Lamath beside her father's house" | 22
67. **River Ascar / Rathlóriel** | river | N of Tol Galen; treasure drowned; renamed | "the treasure of Doriath was drowned in the River Ascar…named anew, Rathlóriel" | 22
68. **Blue Mountains / Nogrod & Belegost** | mts/cities | Dwarves' cities "far off"; Nogrod host marches W over Gelion | "returned at last to their city far off in the Blue Mountains" | 22 (also 20)
69. **Caves of Androth** | caves | in Mithrim hills; Tuor's dwelling | "the caves of Androth where they dwelt" | 23
70. **Annon-in-Gelydh (Gate of the Noldor)** | gate | W across Dor-lómin; tunnel beneath mts | "found Annon-in-Gelydh, the Gate of the Noldor…when they dwelt in Nevrast" | 23
71. **Cirith Ninniach (Rainbow Cleft)** | cleft | tunnel issues into it; water runs W to sea | "issued into Cirith Ninniach, the Rainbow Cleft, through which a turbulent water ran towards the western sea" | 23
72. **Belegaer (Great Sea)** | sea | seen from Nevrast | "looking upon Belegaer the Great Sea" | 23
73. **Vinyamar / Mount Taras** | halls/mountain | Vinyamar beneath Mt Taras, on Nevrast shore | "the deserted halls of Vinyamar beneath Mount Taras" | 23
74. **Orfalch Echor** | ravine | climbing road into Gondolin; barred by seven gates | "the mighty ravine of Orfalch Echor, barred by seven gates" | 23
75. **Tumladen** | vale | green vale amid encircling hills; Gondolin's plain | "the fair vale of Tumladen, set as a green jewel amid the encircling hills" | 23
76. **Amon Gwareth** | rocky height | Gondolin stands on it; secret way issues N of it | "far off upon the rocky height of Amon Gwareth Gondolin the great" | 23
77. **Araman** | coast | where words spoken to departing Noldor | "spoken before the departing Noldor on the coast of Araman long ago" | 23
78. **Anach–upper Sirion land** | mountainous region | where Hidden Kingdom lay; Morgoth's thought bent on it | "the mountainous land between Anach and the upper waters of Sirion" | 23
79. **Cirith Thoronath (Eagles' Cleft)** | pass | beneath highest peaks; on N escape route; precipice R, fall L | "on the right hand it was walled by a precipice, and on the left a dreadful fall leapt into emptiness" | 23
80. **Vale of Sirion** | valley | fugitives descend into it, then S | "came down into the Vale of Sirion; and fleeing southward…to Nan-tathren" | 23
81. **Arvernien** | coast | Elven-folk dwell nigh its coasts | "nigh to the coasts of Arvernien, under the shadow of Ulmo's hand" | 23

---

## B) MEASUREMENTS (verbatim + chapter)

1. "an army ten thousand strong" (Turgon's Gondolin host) — 20
2. "on the fourth day of the war, there began Nirnaeth Arnoediad" — 20
3. "on the fifth day as night fell…still far from Ered Wethrin" — 20
4. "at the third hour of morning, the trumpets of Maedhros were heard" — 20
5. "as the sun westered on the sixth day…Huor fell" — 20
6. "Seventy times he uttered that cry" (Húrin) — 20
7. "Círdan built seven swift ships" — 20
8. "For nine years he dwelt in Thingol's halls" (Túrin) — 21
9. "when three years had passed, Túrin returned again to Menegroth" — 21
10. "when a year had passed since Túrin fled from Doriath" — 21
11. "Túrin went with him a bowshot from the camp" — 21
12. "league upon league away on the skirts of the sky…the Mountains of Shadow" — 21
13. "four hundred and ninety-five years had passed since the rising of the Moon" — 21
14. "for forty leagues and more had he journeyed without rest" — 21
15. "after three days' journeying they came to Amon Ethir" — 21
16. "a league before the doors of Nargothrond" (Amon Ethir) — 21
17. "when three years were passed since the sack of Nargothrond" — 21
18. "For twenty-eight years he had been captive in Angband" (Húrin) — 22
19. "when Tuor was sixteen years old" — 23
20. "For three years he endured that thraldom" — 23
21. "as an outlaw for four years" — 23
22. "Orfalch Echor, barred by seven gates" — 23
23. "seven great swans flying south" — 23
24. "when he had dwelt there for seven years Turgon did not refuse him…the hand of his daughter" — 23
25. "five hundred years and three since the coming of the Noldor to Middle-earth" (Eärendil's birth) — 23
26. "in the year when Eärendil was seven years old" (Gondolin's fall) — 23
27. "smote the rocky slopes of Amon Gwareth thrice ere it pitched into the flames" (Maeglin's fall) — 23
28. Non-numeric width descriptor: "a deep and narrow gorge that a hunted deer might overleap" (Cabed-en-Aras) — 21

---

## C) ITINERARIES (from → via → to)

**Ch.20**
- Beren & Lúthien: Doriath → beyond R. Gelion → Ossiriand → Tol Galen (isle in Adurant).
- Battle plan: Maedhros (E, over Anfauglith) + Fingon (W, from passes of Hithlum) → assault Angband from E and W; signal = beacon in Dorthonion.
- Morgoth's W force: over sands of Anfauglith → toward Hithlum; front drawn up "before the stream of Sirion, from…Eithel Sirion to the inflowing of Rivil at the Fen of Serech."
- Fingon's onset: from hills E of Ered Wethrin → over Anfauglith → walls of Angband (Gwindor to the Gate).
- Retreat: Fingon's host over the sands (still far from Ered Wethrin by 5th day).
- Turgon: from Gondolin, from the S (Pass of Sirion) → up to the battle.
- Maedhros: from the east → assailed enemy's rear → after rout, escaped "towards Mount Dolmed in the east."
- Turgon's withdrawal: fought southward → passed down Sirion → vanished into the mountains (Ecthelion/Glorfindel on flanks; Dor-lómin men rearguard).
- Húrin & Huor: withdrew behind Fen of Serech (Rivil before them) → last stand → Húrin dragged to Angband → chair of stone on Thangorodrim.
- Aftermath: Morgoth's force over Hithlum & Nevrast → down Brithon & Nenning → Falas → Brithombar & Eglarest.
- Círdan's remnant: Havens → by sea S to Isle of Balar (+ foothold at Mouths of Sirion). Turgon's 7 ships → West; one foundered → Voronwë ashore in Nevrast.

**Ch.21**
- Rían: Hithlum → Haudh-en-Ndengin (dies).
- Túrin: Dor-lómin → over the mountains → borders of Doriath → Menegroth.
- Túrin's flight: Menegroth → through Girdle of Melian → woods west of Sirion (outlaws) → south of Teiglin → westward out of Sirion's vale → Amon Rûdh (Bar-en-Danwedh).
- Orc invasion road: Taur-nu-Fuin → Pass of Anach → Dimbar → long defile of Sirion (past isle of Minas Tirith) → land between Malduin and Sirion → eaves of Brethil → Crossings of Teiglin → Guarded Plain.
- Beleg's pursuit: Amon Rûdh → N toward Crossings of Teiglin → over Brithiach → through Dimbar → toward Pass of Anach → Taur-nu-Fuin → high slopes down to Anfauglith (Orc-dell within sight of Thangorodrim).
- Post-Beleg: Gwindor leads Túrin W over Sirion → Eithel Ivrin → S along banks of Narog → Nargothrond.
- Glaurung's assault: over Anfauglith → N vales of Sirion → under Ered Wethrin (defiles Eithel Ivrin) → Nargothrond realm → burns Talath Dirnen (between Narog & Teiglin). Battle: Elves penned in Tumhalad (between Ginglith & Narog).
- Túrin's return & flight N: back over bridge into Nargothrond → out on the northward road → through lands between Narog & Teiglin → pools of Ivrin → passes of Dor-lómin (40+ leagues) → Dor-lómin (Brodda's hall) → outlaws' refuge in southern mts of Dor-lómin → back to Sirion's vale → down from Ered Wethrin → S down Teiglin → Crossings of Teiglin → Haudh-en-Elleth → Ephel Brandir (Amon Obel).
- Morwen/Nienor riding: Menegroth → banks of Sirion → hidden ferries at Meres of Twilight → over Sirion → (3 days) → Amon Ethir (a league from Nargothrond). Glaurung comes forth, "passed east over Narog," then back to Nargothrond.
- Nienor: Amon Ethir → led NE toward Doriath fences beyond Sirion (guarded bridge near Esgalduin inflow) → Orc attack → fled N → Crossings of Teiglin → Haudh-en-Elleth (found by Turambar).
- Níniel borne: → Dimrost/Nen Girith (Celebros→Teiglin) → Ephel Brandir (Amon Obel).
- Glaurung's final march: Nargothrond → borders of Brethil → "west shores of Teiglin" → Cabed-en-Aras.
- Turambar: Ephel Brandir → Nen Girith → down into Cabed-en-Aras ravine (crossed) → slays Glaurung.
- Níniel: Nen Girith → down toward Crossings → beheld Haudh-en-Elleth → fled S along river → Cabed-en-Aras → leapt (Cabed Naeramarth).
- Túrin: → Haudh-en-Elleth → Cabed-en-Aras → cast on Gurthang; buried in high mound with Stone.

**Ch.22**
- Húrin released: Angband → over Anfauglith → Hithlum → up into mts → down from Ered Wethrin → over Brithiach → Dimbar → dark feet of Echoriath (blocked Way of Escape); calls to Gondolin.
- Then: back to Brithiach → along eaves of Brethil → Crossings of Teiglin → place of Glaurung's burning / Cabed Naeramarth (Morwen dies; grave "on the west side of the stone").
- Then: over Teiglin → S down ancient road to Nargothrond (Amon Rûdh seen "far off to the eastward") → banks of Narog → over fallen bridge-stones → broken Doors of Felagund (slays Mîm).
- Then: eastward → Meres of Twilight above Falls of Sirion → taken at western marches of Doriath → Menegroth → (gives Nauglamír) → out → cast himself into the western sea.
- Dwarf trade route: Ered Lindon → over Gelion at Sarn Athrad → ancient road → Doriath (through lands between Aros & Gelion).
- Dwarves flee after slaying Thingol: Menegroth → eastward through Region → over Aros (mostly slain); two → Nogrod (Blue Mts).
- Nogrod host: Nogrod → over Gelion → westward through Beleriand → over Aros → Doriath → over great bridge → Menegroth (sack).
- Beren's ambush: Tol Galen → N to R. Ascar → Sarn Athrad ambush; Dwarves flee E → long slopes beneath Mount Dolmed → driven into Ered Lindon by Shepherds of the Trees. Treasure drowned in Ascar (→Rathlóriel); Beren → Tol Galen.
- Dior: Lanthir Lamath → Menegroth. Later coffer carried from Ossiriand → Menegroth.
- Fëanorians' assault (mid-winter) → Thousand Caves. Elwing's escape: Doriath → mouths of Sirion by the sea.

**Ch.23**
- Tuor: caves of Androth → westward across Dor-lómin → Annon-in-Gelydh → dark tunnel beneath mts → Cirith Ninniach → Nevrast (sees Belegaer).
- Tuor follows swans S along the sea-shore → Vinyamar (beneath Mt Taras) → shore (Ulmo).
- Tuor & Voronwë: Vinyamar → eastward under eaves of Mts of Shadow → Pools of Ivrin (pass Túrin going N) → hidden door of Gondolin → tunnel → inner gate → up Orfalch Echor (7 gates) → great gate → across Tumladen → Gondolin (Amon Gwareth).
- Assault: Morgoth's host "over the northern hills where the height was greatest and the watch least vigilant," at night → beneath the walls ("red light mounted the hills in the north and not in the east").
- Escape: Idril's secret way (issues "northward of Amon Gwareth") → long open road from tunnel-mouth to foothills → climb "towards the north and the highest parts of the mountains and the nighest to Angband" → Cirith Thoronath (ambush + Balrog; Glorfindel's duel on a pinnacle, both fall) → over the mountains → down into Vale of Sirion → southward → Nan-tathren.
- Then: Nan-tathren → southwards down the river to the sea → mouths of Sirion (join Elwing). Later Tuor & Idril → Eärrámë → into the West.

---

## D) ODDITIES / AMBIGUITIES

1. **Illustration caption "Taur-na-Fuin (Fangorn Forest)"** (line 10033) wrongly equates Taur-nu-Fuin with Fangorn — extraneous editorial caption, not narrative geography. [ambig]
2. **Caption spelling variants:** "Tumladin" (line 11426) vs narrative "Tumladen"; "Cristhorn" (caption) vs "Cirith Thoronath" (text); "Glórund" (caption 10314) vs "Glaurung"; "Taur-na-Fuin" vs "Taur-nu-Fuin." Same features, differing forms.
3. **Two Gondolin entrances:** Húrin (Ch.22) finds the "old Way of Escape" — Dry River blocked, arched gate buried; Tuor (Ch.23) enters by "the hidden door" + "Orfalch Echor (seven gates)," which is only blocked up *after* his entry. Whether these are the same portal, and the relative chronology, is left unclear. [ambig]
4. **Absent expected features:** No "Firth of Drengist" or "Lammoth" is named — Cirith Ninniach's water merely "ran towards the western sea." At Nan-tathren the text credits only the Sirion ("the power of Ulmo yet ran in the great river"); the Narog–Sirion confluence is **not stated** in these lines. [note]
5. **Amon Ethir distance:** given as "a league before the doors of Nargothrond," yet the party reaches it "after three days' journeying" — the three days spans the whole trek from the Meres-of-Twilight crossing, not the final league. [clarify]
6. **Amon Rûdh bearing flips with vantage:** "far off…westward" from Túrin's camp near Doriath's west march (Ch.21) but "far off to the eastward" from Húrin on the Nargothrond road (Ch.22) — consistent geometry, opposite viewpoints.
7. **"the Gorgoroth"** (Ch.21, by Anach/Taur-nu-Fuin) is Ered Gorgoroth of Beleriand, not the Mordor plateau of the same name — internal to this text, but a name-collision worth flagging.
8. **Níniel's death-water:** Brandir reports she "cast herself into Teiglin," while the narrative places her leap at Cabed-en-Aras/Cabed Naeramarth — the same gorge (Cabed-en-Aras is on Teiglin), so consistent, not contradictory.