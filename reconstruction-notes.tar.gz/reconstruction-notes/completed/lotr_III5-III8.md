Extraction complete for lines 22529–25965 (III.5–III.8). All geographic/spatial statements with exact quotes, by chapter:

## III.5 THE WHITE RIDER

**Tracking ground (Fangorn eaves):** Battle-knoll near forest edge; Orc carried hobbit(s): "carried to this point by an Orc. Blood was spilled there, a few paces away." Hobbit-prints found "near the bank of the Entwash"; at forest edge "beneath the bole of a great tree on the very edge of the wood more prints." Marks "two days old"; "at this point the hobbits left the waterside."

**Treebeard's Hill:** "They came at length to the steep abrupt end of Treebeard's Hill, and looked up at the rock-wall with its rough steps leading to the high shelf." Orientation: "The shelf faced southward and eastward; but only on the east was the view open. There he could see the heads of the trees descending in ranks towards the plain."

**Hindsight route (Legolas):** "We could have all come here safe together, if we had left the Great River on the second or third day and struck west."

**Timeline data:** Gandalf: "There was a darkness over the valleys of the Emyn Muil"; Legolas saw the eagle "four days ago, above the Emyn Muil"; hobbits climbed the hill "the day before yesterday"; Treebeard "came here two days ago and bore them away to his dwelling far off by the roots of the mountains"; Gandalf saw Treebeard "four days ago."

**Moria vertical geography (Gandalf's tale):** abyss under Durin's Bridge — "Deep is the abyss... and none has measured it" (Gimli); "it has a bottom, beyond light and knowledge... the uttermost foundations of stone"; tunnels "Far, far below the deepest delvings of the Dwarves"; Endless Stair: "From the lowest dungeon to the highest peak it climbed, ascending in unbroken spiral in many thousand steps, until it issued at last in Durin's Tower carved in the living rock of Zirakzigil, the pinnacle of the Silvertine. There upon Celebdil was a lonely window in the snow" — equates Zirakzigil = Silvertine = Celebdil; Balrog's fall "broke the mountain-side"; tower afterward "crumbled into dust." Gwaihir then bore Gandalf to Lothlórien ("Bear me to Lothlórien!... Thus it was that I came to Caras Galadhon").

**Foreshadow (Galadriel's message):** "The Dead watch the road that leads to the Sea."

**Shadowfax:** "yesterday he was far away in the south of this land" (south of Rohan).

**Ride from Fangorn:** They descend "down the bank of the Entwash"; Shadowfax "waded the river, and then led them away due south into a flat land, treeless and wide." KEY Eastemnet/Westemnet statement: "He is steering a straight course now for the halls of Théoden under the slopes of the White Mountains. It will be quicker so. The ground is firmer in the Eastemnet, where the chief northward track lies, across the river, but Shadowfax knows the way through every fen and hollow." (So they ride the boggy west side of Entwash; Eastemnet lies across the river and carries the chief northward track.) Terrain: "meads and riverlands... many hidden pools, and broad acres of sedge waving above wet and treacherous bogs."

**Gap of Rohan:** At sunset day 1: "'There lies the Gap of Rohan,' said Gandalf. 'It is now almost due west of us. That way lies Isengard.'" Smoke of war seen there.

## III.6 THE KING OF THE GOLDEN HALL

**Ride duration Fangorn→Edoras:** through sunset/night, "a few hours' rest," on "under the cold moon," arrival at dawn — roughly late morning to next dawn, one continuous ride. At dawn "Red shafts of light leapt above the black walls of the Emyn Muil far away upon their left" (Emyn Muil visible east while heading south).

**White Mountains/Harrowdale mouth:** "Before them stood the mountains of the South: white-tipped and streaked with black." "the widest of these glens opened like a long gulf among the hills. Far inward they glimpsed a tumbled mountain-mass with one tall peak; at the mouth of the vale there stood like a sentinel a lonely height. About its feet there flowed, as a thread of silver, the stream that issued from the dale; upon its brow... a glimmer of gold."

**Edoras & Meduseld:** Legolas: "I see a white stream that comes down from the snows... Where it issues from the shadow of the vale a green hill rises upon the east. A dike and mighty wall and thorny fence encircle it... in the midst, set upon a green terrace, there stands aloft a great hall of Men... thatched with gold." Gandalf: "Edoras those courts are called... and Meduseld is that golden hall."

**Snowbourn course (stream unnamed here):** "It ran down swiftly into the plain, and beyond the feet of the hills turned across their path in a wide bend, flowing away east to feed the Entwash far off in its reed-choked beds." Willows along it; "Over the stream there was a ford between low banks." Climate: "Already in this southern land they were blushing red at their finger-tips, feeling the approach of spring" (willows, early spring).

**Barrows:** "we are come to the great barrows where the sires of Théoden sleep." Aragorn: "Seven mounds upon the left, and nine upon the right." Simbelmynë: "Upon their western sides the grass was white as with a drifted snow"; "Evermind they are called, simbelmynë... they blossom in all the seasons of the year, and grow where dead men rest." Age: Legolas — "Five hundred times have the red leaves fallen in Mirkwood... since then" (hall ~500 years old); "the high hall which Brego son of Eorl built."

**Edoras interior:** "a broad path, paved with hewn stones, now winding upward, now climbing in short flights of well-laid steps... Beside the way in a stone channel a stream of clear water flowed... at the crown of the hill... a high platform above a green terrace, at the foot of which a bright spring gushed from a stone carved in the likeness of a horse's head... Up the green terrace went a stair of stone." Hall: dais "at the far end of the house... facing north towards the doors" (doors at north end); "eastern windows, high under the deep eaves."

**Eorl tapestry:** "Thus he rode out of the North to the Battle of the Field of Celebrant" (Field of Celebrant reference).

**Mundburg:** guards admit "those that come from Mundburg in the land of Gondor" (Rohan's name for the Gondor city).

**View from porch:** "they could see beyond the stream the green fields of Rohan fading into distant grey"; weather: "the storm that had come out of the East was receding, rolling away southward to the sea"; "far away the river glittered like a shimmering glass" [ambig: Snowbourn's bend or Entwash].

**Long east view:** "Over the sundering leagues of land... beyond dark mountains to the Land of Shadow"; Legolas "caught a glint of white: far away perchance the sun twinkled on a pinnacle of the Tower of Guard. And further still, endlessly remote and yet a present threat, there was a tiny tongue of flame" (Minas Tirith pinnacle and a distant flame seen — poetically — from Edoras).

**Timeline:** Wormtongue: "It is not yet five days since the bitter tidings came that Théodred your son was slain upon the West Marches." Muster: "let them be ready in the saddle at the gate ere the second hour from noon!" Host: "More than a thousand were there mustered."

**Dunharrow (first mentions):** Gandalf: "Lead your people swiftly to the Hold of Dunharrow in the hills!" Théoden: "in Dunharrow the people may long defend themselves, and if the battle go ill, thither will come all who escape."

**Ford at Edoras:** Shadowfax "away down by the ford, like a shadow among the willows."

## III.7 HELM'S DEEP

**Departure/route:** "The sun was already westering as they rode from Edoras... There was a beaten way, north-westward along the foot-hills of the White Mountains, and this they followed, up and down in a green country, crossing small swift streams by many fords. Far ahead and to their right the Misty Mountains loomed."

**KEY DISTANCE:** "Forty leagues and more it was, as a bird flies, from Edoras to the fords of the Isen."

**Day 1:** "They had ridden for some five hours and were far out upon the western plain, yet more than half their journey lay still before them." Camp, no fires; dawn horns, "within an hour they took the road again." Climate: "it was hot for the season of the year"; storm "moving out of the East."

**Wizard's Vale bearing:** "away in the North-west there seemed to be another darkness brooding about the feet of the Misty Mountains, a shadow that crept down slowly from the Wizard's Vale."

**Legolas's sight:** eyes "can tell a sparrow from a finch a league off"; toward Isengard: "Many miles lie between... great shapes far away upon the bank of the river... it marches slowly down stream."

**Thrihyrne:** Day 2 sunset: "the steep faces of the peaks of Thrihyrne: now very near they stood on the northernmost arm of the White Mountains, three jagged horns staring at the sunset."

**Ceorl's war report:** "We were driven back yesterday over the Isen with great loss; many perished at the crossing... Saruman has armed the wild hillmen and herd-folk of Dunland beyond the rivers... Erkenbrand of Westfold has drawn off those men he could gather towards his fastness in Helm's Deep."

**Course change:** Gandalf: "Ride to Helm's Deep! Go not to the Fords of Isen, and do not tarry in the plain!... Await me at Helm's Gate!" — "The host turned away now from the road to the Fords of Isen and bent their course southward." Enemy "hurrying southward from the Fords of Isen... making for Helm's Deep."

**Helm's Deep site:** "Still some miles away, on the far side of the Westfold Vale, a great bay in the mountains, lay a green coomb, out of which a gorge opened in the hills. Men of that land called it Helm's Deep... Ever steeper and narrower it wound inward from the north under the shadow of the Thrihyrne, till the crowhaunted cliffs rose like mighty towers on either side" (gorge mouth opens north).

**Hornburg:** "At Helm's Gate, before the mouth of the Deep, there was a heel of rock thrust outward by the northern cliff. There upon its spur stood high walls of ancient stone, and within them was a lofty tower. Men said that in the far-off days of the glory of Gondor the sea-kings had built here this fastness with the hands of giants."

**Wall/stream system:** "A wall, too, the men of old had made from the Hornburg to the southern cliff, barring the entrance to the gorge. Beneath it by a wide culvert the Deeping-stream passed out. About the feet of the Hornrock it wound, and flowed then in a gully through the midst of a wide green gore, sloping gently down from Helm's Gate to Helm's Dike. Thence it fell into the Deeping-coomb and out into the Westfold Vale."

**Helm's Dike (KEY numbers):** Éomer: "Not far ahead now lies Helm's Dike, an ancient trench and rampart scored across the coomb, two furlongs below Helm's Gate." Théoden: "It is a mile long or more, and the breach in it is wide." Breach location: "where the stream from above passed out, and the road beside it ran down from the Hornburg."

**Garrison/refuge:** Gamling: "Maybe, we have a thousand fit to fight on foot"; "Behind us in the caves of the Deep are three parts of the folk of Westfold... great store of food, and many beasts and their fodder." Éomer: "There are caves in Helm's Deep where hundreds may lie hid; and secret ways lead thence up on to the hills." Théoden: "Trust not to secret ways... Saruman has long spied out this land."

**Approach:** "Before the causeway that crossed the stream they dismounted. In a long file they led their horses up the ramp and passed within the gates of the Hornburg."

**DEEPING WALL SPEC (KEY):** "The Deeping Wall was twenty feet high, and so thick that four men could walk abreast along the top, sheltered by a parapet over which only a tall man could look. Here and there were clefts in the stone through which men could shoot. This battlement could be reached by a stair running down from a door in the outer court of the Hornburg; three flights of steps led also up on to the wall from the Deep behind; but in front it was smooth... at the top they hung over like a sea-delved cliff."

**Postern:** "a small postern-door that opened in an angle of the burg-wall on the west, where the cliff stretched out to meet it. On that side a narrow path ran round towards the great gate, between the wall and the sheer brink of the Rock."

**Battle spatial events:** Orcs "crept like rats through the culvert"; defenders "blocked up the inner end of the culvert, until only a narrow outlet remained" — stream "spread slowly in cold pools from cliff to cliff"; blasting fire: "a gaping hole was blasted in the wall... they have lit the fire of Orthanc beneath our feet." "A broad stairway climbed from the Deep up to the Rock and the rear-gate of the Hornburg." Caves' air: "wholesome there because of the outlets through fissures in the rock far above." Weather: storm past midnight, "Branched lightning smote down upon the eastward hills," rain; later clearing, "the lightning flickered still, far off among the mountains in the South."

**Fortress reputation:** "Is it not said that no foe has ever taken the Hornburg, if men defended it?"; Aragorn: "More hope we have to defend you in the Hornburg than in Edoras, or even at Dunharrow in the mountains."

**Huorn wood (dawn):** "Where before the green dale had lain... there now a forest loomed... Between the Dike and the eaves of that nameless wood only two open furlongs lay." Coomb geometry: "Upon the east too sheer and stony was the valley's side; upon the left, from the west, their final doom approached" — Gandalf + Erkenbrand with "a thousand men on foot" descend from a western ridge; enemy fled under the trees "and from that shadow none ever came again."

**Dunland history:** Gamling: "Not in half a thousand years have they forgotten their grievance that the lords of Gondor gave the Mark to Eorl the Young."

## III.8 THE ROAD TO ISENGARD

**Gimli on Aglarond/Glittering Caves (extent):** "the caverns of Helm's Deep are vast and beautiful... immeasurable halls, filled with an everlasting music of water that tinkles into pools, as fair as Kheled-zâram in the starlight... gems and crystals and veins of precious ore glint in the polished walls... columns of white and saffron and dawn-rose... Still lakes mirror them... There is chamber after chamber... hall opening out of hall, dome after dome, stair beyond stair; and still the winding paths lead on into the mountains' heart." Gandalf names them "the Glittering Caves of Aglarond."

**KEY DISTANCE Helm's Deep↔Isengard:** "'About fifteen leagues, as the crows of Saruman make it,' said Gandalf: 'five from the mouth of Deeping-coomb to the Fords; and ten more from there to the gates of Isengard.'"

**Road junction:** "at the bottom of the Coomb, where the road from Helm's Deep branched, going one way east to Edoras, and the other north to the Fords of Isen." Through the Huorn wood "the road ran on, and the Deeping-stream beside it."

**Ents:** "As tall as trolls they were, twelve feet or more in height... They came swiftly from the North, walking like wading herons in their gait... their legs in their long paces beat quicker than the heron's wings." "Fangorn Forest, which in your tongue you call the Entwood."

**Timing to Fords:** "They had ridden for some four hours from the branching of the roads when they drew near to the Fords" (easy pace, evening).

**Fords of Isen:** "Long slopes ran swiftly down to where the river spread in stony shoals between high grassy terraces... The road dipped between rising turf-banks, carving its way through the terraces to the river's edge, and up again upon the further side. There were three lines of flat stepping-stones across the stream, and between them fords for horses, that went from either brink to a bare eyot in the midst." River dry: "The beds of the stream were almost dry, a bare waste of shingles and grey sand"; Éomer: "has he devoured the springs of Isen too?"; later "Maybe he is boiling all the waters of Isen, and that is why the river runs dry." Mid-eyot burial: "in the midst of the eyot a mound was piled, ringed with stones, and set about with many spears" — "Here lie all the Men of the Mark that fell near this place." (River reflows late that night: "the Isen flowed and bubbled in its bed again.")

**Gandalf's dispositions:** some men sent "with Grimbold of Westfold to join Erkenbrand"; Elfhelm "with many Riders to Edoras."

**Isengard highway (KEY):** "There was an ancient highway that ran down from Isengard to the crossings. For some way it took its course beside the river, bending with it east and then north; but at the last it turned away and went straight towards the gates of Isengard; and these were under the mountain-side in the west of the valley, sixteen miles or more from its mouth." Terrain beside road "firm and level, covered for many miles about with short springing turf."

**Night leg:** "by midnight the Fords were nearly five leagues behind. Then they halted... They were come to the feet of the Misty Mountains, and the long arms of Nan Curunír stretched down to meet them." Smoke: "out of the deep shadow of the dale rose a vast spire of smoke and vapour"; "One would say that all the Wizard's Vale was burning."

**Huorns pass north:** "over the ground there crept a darkness blacker than the night. On both sides of the river it rolled towards them, going northward... vanished between the mountain's arms."

**Death Down:** "a mile below the Dike a huge pit had been delved in the earth, and over it stones were piled into a hill... The Death Down it was afterwards called, and no grass would grow there." The trees "returned at night, and had gone far away to the dark dales of Fangorn."

**Nan Curunír:** "They had passed into Nan Curunír, the Wizard's Vale. That was a sheltered valley, open only to the South. Once it had been fair and green, and through it the Isen flowed, already deep and strong before it found the plains; for it was fed by many springs and lesser streams among the rain-washed hills." Now: "Beneath the walls of Isengard there still were acres tilled by the slaves of Saruman; but most of the valley had become a wilderness of weeds and thorns... No trees grew there... burned and axe-hewn stumps of ancient groves."

**White Hand pillar:** highway becomes "a wide street, paved with great flat stones... Deep gutters, filled with trickling water, ran down on either side"; "a tall pillar... carved and painted in the likeness of a long White Hand. Its finger pointed north" (nails found red on return past it).

**ISENGARD RING SPEC (KEY):** "A great ring-wall of stone, like towering cliffs, stood out from the shelter of the mountain-side, from which it ran and then returned again. One entrance only was there made in it, a great arch delved in the southern wall. Here through the black rock a long tunnel had been hewn, closed at either end with mighty doors of iron... a plain, a great circle, somewhat hollowed like a vast shallow bowl: a mile it measured from rim to rim. Once it had been green and filled with avenues, and groves of fruitful trees, watered by streams that flowed from the mountains to a lake." Dwellings "cut and tunnelled back into the walls upon their inner side"; "Thousands could dwell there"; "Shafts were driven deep into the ground; their upper ends were covered by low mounds and domes of stone... The shafts ran down by many slopes and spiral stairs to caverns far under; there Saruman had treasuries, store-houses, armouries, smithies, and great furnaces." "To the centre all the roads ran between their chains."

**ORTHANC SPEC (KEY):** "A peak and isle of rock it was, black and gleaming hard: four mighty piers of many-sided stone were welded into one, but near the summit they opened into gaping horns, their pinnacles sharp as the points of spears... Between them was a narrow space, and there upon a floor of polished stone, written with strange signs, a man might stand five hundred feet above the plain. This was Orthanc, the citadel of Saruman... in the Elvish speech orthanc signifies Mount Fang, but in the language of the Mark of old the Cunning Mind." Built by "the builders of old, who smoothed the Ring of Isengard" ("mighty works the Men of Westernesse had wrought there of old"; Isengard's lords were "the wardens of Gondor upon the West"). Isengard as "only a little copy, a child's model or a slave's flattery" of "Barad-dûr, the Dark Tower."

**Arrival state (past noon, day after battle):** "the doors lay hurled and twisted on the ground"; "The ring beyond was filled with steaming water... all the roads were drowned. Far off... loomed the island rock... the tower of Orthanc stood. Pale waters lapped about its feet."

**Pursuit total (Gimli, rhetorical):** "Two hundred leagues, through fen and forest, battle and death, to rescue you!"

**Treebeard's position:** "Away on the north side"; "ride to the northern wall they will find Treebeard there"; "We must go round about, but it is not far." Quickbeam "by the rock, near the foot of the stair."

**Other timeline anchors:** Gandalf at Isengard "at nightfall yesterday"; muster proclaimed at Edoras "on the third day after the full moon"; Gandalf: "Look for me in Edoras, ere the waning of the moon!"; departure from Hornburg near sunset, arrival Isengard "The hour of noon had passed" next day.