I've read all three chunks (lines 6438–9107, Chapters 15–19). Here is the extracted spatial evidence.

# A) GAZETTEER

1. **Tumladen/Gondolin** | hidden vale + city | east of upper Sirion, in a mountain ring; entered by underground water-way; contains island-hill | "lay east of the upper waters of Sirion, in a ring of mountains tall and sheer" | Ch.15
2. **Underground way** | subterranean river-passage | waters flow out to join Sirion's streams; Turgon's found entrance to the vale | "waters that flowed out to join the streams of Sirion; and this way Turgon found" | Ch.15
3. **Island-hill / Amon Gwareth** | rock hill in vale | stands in green plain amid mountains; vale was formerly a lake | "the island-hill... of hard smooth stone; for the vale had been a great lake" | Ch.15
4. **Nevrast / Vinyamar** | coastal region + halls | beside the sea; Turgon's former home, left desolate | "leave his halls in Vinyamar beside the sea" | Ch.15
5. **Ered Wethrin (Shadowy Mtns)** | mountains | Turgon's host passed under its shadows en route to Gondolin | "under the shadows of Ered Wethrin, and they came unseen to Gondolin" | Ch.15
6. **Nargothrond** | underground fortress | on river Narog; Finrod's "deep places" | "Finrod Felagund wrought in the deep places of Nargothrond" | Ch.15
7. **Echoriath (Encircling Mtns)** | mountains | encircle Gondolin; contain ore-lodes | "the Echoriath (which are the Encircling Mountains)" | Ch.16
8. **Anghabar** | iron mine | "in the north of the Echoriath" | "the mine of Anghabar in the north of the Echoriath" | Ch.16
9. **Caragdûr** | precipice | on north side of Gondolin's hill; Eöl cast down here | "a precipice of black rock upon the north side of the hill of Gondolin" | Ch.16
10. **Ford of Brithiach** | ford on Sirion | branch point: north→Hithlum, south→Doriath; near Gondolin's secret path | "the Ford of Brithiach in the River Sirion" | Ch.16
11. **Dimbar** | land | east of Brithiach, along Doriath's north-march | "east from the Brithiach through Dimbar and along the north-march of this kingdom" | Ch.16
12. **Bridge of Esgalduin** | bridge | on eastward road, past Dimbar, before Fords of Aros | "until you pass the Bridge of Esgalduin and the Fords of Aros" | Ch.16
13. **Fords of Aros / Arossiach** | river fords | between Esgalduin bridge and Himring; near Nan Elmoth (Dwarf-road) | "the Fords of Aros, and come to the lands that lie behind the Hill of Himring" | Ch.16
14. **Hill of Himring** | fortified hill | Celegorm/Curufin's lands lie behind it; Maedhros dwells there | "the lands that lie behind the Hill of Himring" | Ch.16
15. **Ered Gorgoroth / Mountains of Terror** | mountains | haunted valleys between it and Doriath's north fences | "between the haunted valleys of Ered Gorgoroth and the north fences of Doriath" | Ch.16
16. **Nan Dungortheb** | evil region | by Ered Gorgoroth; creatures of Ungoliant in ravines | "the evil region of Nan Dungortheb" | Ch.16
17. **Himlad** | land | "between Aros and Celon"; Celegorm/Curufin dwelt | "the land of Himlad between Aros and Celon" | Ch.16
18. **Celon** | river ("slender stream") | south bound of Himlad; Nan Elmoth beyond; east of Doriath | "crossed the slender stream of Celon into the land of Himlad" | Ch.16
19. **Nan Elmoth** | dark forest | south of Himlad across Celon; Eöl's home; near northern Dwarf-road | "passed over Celon; and before she was aware she was enmeshed in Nan Elmoth" | Ch.16
20. **Thargelion** | land | east; Caranthir's country | "riding with Caranthir east in Thargelion" | Ch.16
21. **Forest of Region** | forest in Doriath | Eöl's home before Girdle set | "the Forest of Region where he dwelt" | Ch.16
22. **Blue Mountains / Ered Lindon** | mountains | Dwarf-traffic descends; two roads across East Beleriand; Nogrod/Belegost in its east | "two roads across East Beleriand, and the northern way, going towards the Fords of Aros" | Ch.16
23. **Pass of Aglon** | pass | Curufin came "south from the Pass"; forced in Bragollach | "the scouts of Aglon had marked the riding" | Ch.16/18
24. **Outer Gate / Seven Gates / Dark Guard** | Gondolin entrance | under the mountains, reached via Dry River | "the Outer Gate of Gondolin and the Dark Guard under the mountains" | Ch.16
25. **Dry River** | dry riverbed | the secret path into Gondolin | "found the Dry River and the secret path" | Ch.16
26. **Dwarf-road** | road | crosses Gelion at Sarn Athrad | "taking the Dwarf-road he crossed Gelion at the ford of Sarn Athrad" | Ch.17
27. **Sarn Athrad** | ford on Gelion | on Dwarf-road | "crossed Gelion at the ford of Sarn Athrad" | Ch.17
28. **Ascar** | river | "upper streams of Ascar," crossed turning south toward Ossiriand; angle w/ Gelion holds Haladin stockade | "turning south over the upper streams of Ascar" | Ch.17
29. **Ossiriand** | land | reached south over Ascar; Green-elves; Thalos within/above | "he came into the north of Ossiriand" | Ch.17
30. **Thalos** | river/springs | valley below its springs (Bëor's camp) | "below the springs of Thalos" | Ch.17
31. **Gelion** | river | crossed at Sarn Athrad; Men cross "over Gelion" to Estolad; "between the arms of Gelion" | "they removed over Gelion" | Ch.17
32. **Estolad** | encampment-land | "east banks of the Celon south of Nan Elmoth, near to the borders of Doriath" | (same) | Ch.17
33. **Dorthonion** | highland forest | ruled by Finarfin's house; Bëor's folk settle; Ladros within; rose southward into moors | "The people of Bëor came to Dorthonion" | Ch.17
34. **Ladros** | country in Dorthonion | given to house of Bëor | "in Dorthonion the lordship... and the country of Ladros" | Ch.17
35. **Dor-lómin** | land | granted Hador by Fingolfin | "gave to him the lordship of Dor-lómin" | Ch.17
36. **Hithlum** | region | Malach dwelt there; behind Ered Wethrin; horsemen; fastness | "some came to Hithlum" | Ch.17/18
37. **Southern slopes of Ered Wethrin** | vales | Magor's folk passed "down Sirion" to dwell there | "the vales of the southern slopes of Ered Wethrin" | Ch.17
38. **Talath Dirnen (Guarded Plain)** | plain | "beyond Teiglin"; between Sirion and Narog; watched by Nargothrond | "the woods of Talath Dirnen beyond Teiglin" | Ch.17/19
39. **Teiglin** | river | Brethil "between Teiglin and Sirion"; Crossings of Teiglin guarded | "the Crossings of Teiglin" | Ch.17
40. **Forest of Brethil** | forest | between Teiglin and Sirion; claimed by Thingol though outside Girdle; southward | "the Forest of Brethil, between Teiglin and Sirion" | Ch.17
41. **Tûr Haretha / Haudh-en-Arwen** | barrow | "in the heights of the forest" (Brethil) | (same) | Ch.17
42. **Ard-galen** | plain | "from the hill-forts of the Noldor to the feet of Thangorodrim"; burned, renamed | "the wide plain of Ard-galen stretched... to the feet of Thangorodrim" | Ch.18
43. **Anfauglith / Dor-nu-Fauglith** | burned desert | former Ard-galen | "its name was changed, and it was called Anfauglith, the Gasping Dust" | Ch.18
44. **Thangorodrim** | mountains | at edge of Ard-galen; flame-rivers ran from it; descried from Angrod/Aegnor's regions | "rivers of flame that ran down... from Thangorodrim" | Ch.18
45. **Mountains of Iron / Iron Mtns** | mountains | belched fires; archers pursued Orcs into them | "pursued them even into the Iron Mountains" | Ch.18
46. **Fen of Serech** | fen | near Pass of Sirion; Rivil's Well above it | "surrounded with small company in the Fen of Serech" | Ch.18/19
47. **Pass of Sirion** | pass | western; Barahir fought "further westward, near" it | "in the fighting further westward, near to the Pass of Sirion" | Ch.18
48. **Eithel Sirion / Barad Eithel** | fortress | in Ered Wethrin; Hador/Galdor fell before its walls; held for Fingon | "Before the walls of Eithel Sirion fell Hador" | Ch.18
49. **Lothlann** | plain | Fëanor's riders overwhelmed there; Glaurung came | "overwhelmed the riders of the people of Fëanor upon Lothlann" | Ch.18
50. **Maglor's Gap** | gap | Glaurung passed through; between arms of Gelion | "passed through Maglor's Gap, and destroyed all the land between the arms of Gelion" | Ch.18
51. **Mount Rerir** | mountain | fortress on "west slopes"; in Thargelion; Lake Helevorn near | "the fortress upon the west slopes of Mount Rerir" | Ch.18
52. **Lake Helevorn** | lake | in Thargelion; defiled | "ravaged all Thargelion... and they defiled Lake Helevorn" | Ch.18
53. **Ramdal** | place | passed "in the south" | "passed Ramdal in the south" | Ch.18
54. **Amon Ereb** | hill | south; watch maintained w/ Green-elves' aid | "Upon Amon Ereb they maintained a watch" | Ch.18
55. **Taur-im-Duinath** | southern wilds | Orcs came not there | "nor to Taur-im-Duinath and the wilds of the south" | Ch.18
56. **Crissaegrim** | peaks | Thorondor's eyrie; sheer walls near Dimbar | "his eyrie among the peaks of the Crissaegrim" | Ch.18
57. **Mount of Fingolfin** | mountain-top | "looked from the north upon the hidden valley of Gondolin" | (same) | Ch.18
58. **Taur-nu-Fuin / Deldúwath** | dark forest | "northward slopes" of Dorthonion; east of the western pass | "the forest of the northward slopes of that land... called... Taur-nu-Fuin" | Ch.18
59. **Minas Tirith / Tol Sirion → Tol-in-Gaurhoth** | tower on isle | in Sirion, western pass, "about the sources of Sirion"; Sauron's; no creature passes the vale unseen | "the fair isle of Tol Sirion became accursed... Tol-in-Gaurhoth" | Ch.18/19
60. **Firth of Drengist** | firth/inlet | Círdan's ships sailed up it into Hithlum's plains; Falas-elves came "from the west" | "the ships of Círdan sailed... up the Firth of Drengist" | Ch.18
61. **Mouths of Sirion / Isle of Balar** | coast + isle | Gondolindrim built ships there | "to the mouths of Sirion and the Isle of Balar" | Ch.18
62. **Tarn Aeluin** | lake | "in the east of those highlands" of Dorthonion; wild heaths; Barahir's lair | "in the east of those highlands there lay a lake, Tarn Aeluin" | Ch.19
63. **Rivil's Well** | spring | "above the Fen of Serech"; Orc camp | "at Rivil's Well above the Fen of Serech" | Ch.19
64. **Twilight Meres / Fens of Sirion** | wetlands | Beren crossed leaving Doriath, before Falls | "the region of the Twilight Meres, and the Fens of Sirion" | Ch.19
65. **Falls of Sirion** | falls | Sirion plunges underground; hills above overlook Talath Dirnen | "the Falls of Sirion, where the river plunged underground" | Ch.19
66. **Narog** | river | Talath Dirnen "between Sirion and Narog"; Nargothrond on it; source at Ivrin | "stretching between Sirion and Narog" | Ch.19
67. **Taur-en-Faroth (High Faroth)** | highlands | "rose above Nargothrond" | "the highlands of Taur-en-Faroth that rose above Nargothrond" | Ch.19
68. **Ginglith** | river | joins Narog north of Nargothrond; flood less there (crossing point) | "where Ginglith joined Narog, the flood was less" | Ch.19
69. **Falls of Ivrin** | source of Narog | beneath Shadowy Mtns | "beside Narog to his source in the Falls of Ivrin" | Ch.19
70. **Western pass (to Angband)** | pass | "between Ered Wethrin and the highlands of Taur-nu-Fuin" | (same) | Ch.19
71. **Neldoreth** | beech-forest | "the northern half of the kingdom" (Doriath); Esgalduin's glades; Hírilorn | "that was a beech-forest and the northern half of the kingdom" | Ch.19
72. **Hírilorn** | great three-trunked beech | near gates of Menegroth | "Not far from the gates of Menegroth stood the greatest of all the trees" | Ch.19
73. **Esgalduin** | river | glades in Neldoreth; sources over Taur-nu-Fuin's east side; falls in a dark valley | "she danced... in the glades beside Esgalduin" | Ch.19
74. **Gate of Angband** | gate | "an arch wide and dark at the foot of the mountain"; drear dale before it | "above it reared a thousand feet of precipice" | Ch.19
75. **Sirion (adjacency note)** | river | west of Doriath (vs. Celon east); Orcs "came down Sirion in the west and Celon in the east" | (same) | Ch.18

# B) MEASUREMENTS (verbatim + context + chapter)

- "after two and fifty years of secret toil" — building of Gondolin | Ch.15
- "the host of Turgon came never forth again until the Year of Lamentation after three hundred and fifty years and more" | Ch.15
- "when two hundred years had passed since Gondolin was full-wrought" — Aredhel asks leave | Ch.16
- "his father gave him no name until he was twelve years old" — Maeglin | Ch.16
- Eöl "found his wife and his son but two days gone" | Ch.16
- "It is not two days since they passed over the Arossiach" — Curufin to Eöl | Ch.16
- "When three hundred years and more were gone since the Noldor came to Beleriand" — Finrod meets Men | Ch.17
- "when after a year had passed Felagund wished to return" — with Bëor | Ch.17
- Malach "dwelt in Hithlum for fourteen years" | Ch.17
- "after some fifty years many thousands had entered the lands of the Kings" — Edain migration | Ch.17
- "Bereg led a thousand of the people of Bëor away southwards" | Ch.17
- "seven days later, as the Orcs made their last assault" — Haladin siege before Caranthir came | Ch.17
- "Bëor the Old died when he had lived three and ninety years, for four and forty of which he had served King Felagund" | Ch.17
- "four hundred years and five and fifty since the coming of Fingolfin" — dating Bragollach | Ch.18
- "the sixth generation of Men after Bëor and Marach were not yet come to full manhood" | Ch.18
- Hador fell "being then sixty and six years of age" | Ch.18
- "For nigh on two years after the Dagor Bragollach the Noldor still defended the western pass" | Ch.18
- Huor went to battle "though he was but thirteen years old" | Ch.18
- Húrin and Huor "dwelt as guests in the King's house for well nigh a year" (Gondolin) | Ch.18
- "When seven years had passed since the Fourth Battle, Morgoth renewed his assault" | Ch.18
- "for four years more Beren wandered still upon Dorthonion" | Ch.19
- Beren "came back to the lair of the outlaws on the second morning" | Ch.19
- Angband's Gate: "above it reared a thousand feet of precipice" | Ch.19
- Huan permitted "thrice only ere his death to speak with words" (non-spatial) | Ch.19

# C) ITINERARIES (ordered legs)

1. **Turgon founds Gondolin (Ch.15):** Nevrast → discovers Tumladen via the deep underground way (waters joining Sirion) → returns to Nevrast → builds city (52 yrs) → people pass "under the shadows of Ered Wethrin" → Gondolin.
2. **Aredhel leaves Gondolin (Ch.16):** Gondolin → Ford of Brithiach on Sirion → (refuses north/Hithlum, turns south) → Doriath denied → road between Ered Gorgoroth and Doriath's north fences → near Nan Dungortheb (companions lost) → crosses Esgalduin then Aros → Himlad → south over Celon → Nan Elmoth.
3. **Aredhel & Maeglin flee to Gondolin (Ch.16):** Nan Elmoth (north eaves) → cross Celon → Himlad → Fords of Aros → westward along Doriath's fences → Brithiach (abandon horses) → secret path → Outer Gate → Seven Gates → Amon Gwareth.
4. **Eöl's pursuit (Ch.16):** Nan Elmoth → east then into Himlad → waylaid near Fords by Curufin (down from Pass of Aglon) → crosses Fords of Aros → hard westward → Brithiach → finds Dry River + secret path → Gondolin Guard.
5. **Finrod finds Men (Ch.17):** east of Sirion (hunting) → alone toward Ered Lindon → Dwarf-road → crosses Gelion at Sarn Athrad → south over upper Ascar → north of Ossiriand → valley below springs of Thalos (Bëor's camp).
6. **Bëor's people relocate (Ch.17):** Ossiriand → over Gelion → lands of Amrod/Amras, east banks of Celon south of Nan Elmoth near Doriath = Estolad.
7. **Haladin first march (Ch.17):** eastern slopes → (Green-elf unfriendship) turned north → Thargelion (Caranthir's country).
8. **Marach's people (Ch.17):** over the mountains → down Dwarf-road → country south and east of Baran's dwellings.
9. **Edain northward migration (Ch.17):** Estolad → long road north → Bëor's folk to Dorthonion; Aradan's folk west (some Hithlum); Magor "down Sirion" to southern slopes of Ered Wethrin.
10. **Bereg's group (Ch.17):** Estolad → southwards (1,000 of Bëor's people); separate like-minded folk → back over mountains into Eriador.
11. **Orc raid + Haleth's first march (Ch.17):** raid passes east over Ered Lindon by Dwarf-road passes → southern woods of Caranthir → Haldad's stockade in angle between Ascar and Gelion → Caranthir "from the north" relieves → Haleth leads survivors to Estolad.
12. **Haleth's westward march (Ch.17):** Estolad → over Celon and Aros → land between Mountains of Terror and Girdle of Melian → crosses Brithiach → Talath Dirnen beyond Teiglin / Brethil between Teiglin and Sirion.
13. **Celegorm & Curufin retreat, Bragollach (Ch.18):** Pass of Aglon (forced) → fled "south and west by the marches of Doriath" → Nargothrond.
14. **Glaurung/Orc eastern conquest (Ch.18):** broke leaguer → Lothlann → through Maglor's Gap → land between arms of Gelion → fortress on west slopes of Mount Rerir → all Thargelion (Lake Helevorn defiled) → over Gelion into East Beleriand. Caranthir → passed Ramdal in the south → Amon Ereb.
15. **Emeldir's escape (Ch.18):** Dorthonion → mountains "that lay behind" → perilous paths → Brethil; some on over mountains to Dor-lómin.
16. **Fingolfin's ride (Ch.18):** Hithlum → "over Dor-nu-Fauglith like a wind amid the dust" → Angband's gates.
17. **Thorondor bears Fingolfin's body (Ch.18):** Angband gate → mountain-top "that looked from the north upon the hidden valley of Gondolin."
18. **Húrin & Huor to Gondolin (Ch.18):** Brethil battle → cut off, pursued to Ford of Brithiach → escape over Brithiach into Dimbar → hills beneath Crissaegrim (bewildered) → eagles bear them "beyond the Encircling Mountains" to Tumladen/Gondolin → (return) eagles set them in Dor-lómin before dawn.
19. **Gondolin's mariners (Ch.18):** Gondolin → mouths of Sirion + Isle of Balar → build ships → sail into uttermost West (fail).
20. **Círdan's relief of Hithlum (Ch.18):** ships up Firth of Drengist → Falas-elves strike Morgoth's host "from the west"; Eldar's archers pursue Orcs "into the Iron Mountains."
21. **Barahir's outlaws (Ch.18/19):** Dorthonion → "barren highland above the forest" → Tarn Aeluin (east of the highlands).
22. **Beren's dream-warning + vengeance (Ch.19):** far afield spying → sped through night → lair on second morning (Tarn Aeluin) → Orc camp at Rivil's Well above Fen of Serech → escaped.
23. **Beren's descent into Doriath (Ch.19):** Dorthonion (flees winter) → high regions of Gorgoroth (descries Doriath) → southward down Ered Gorgoroth precipices → wilderness of Dungortheb → Doriath's borders → through Melian's Girdle/mazes → Neldoreth beside Esgalduin (meets Lúthien).
24. **Beren to Nargothrond (Ch.19):** Doriath → Twilight Meres + Fens of Sirion → hills above Falls of Sirion → looks west across Talath Dirnen (between Sirion and Narog) to Taur-en-Faroth → hunters lead him "northward and westward," cross where Ginglith joins Narog, turn "again southward" → gates of Nargothrond.
25. **Felagund & Beren to Angband (Ch.19):** Nargothrond → beside Narog to source at Falls of Ivrin → beneath Shadowy Mtns (slay Orcs, disguise) → western pass "between Ered Wethrin and the highlands of Taur-nu-Fuin" → captured → Tol-in-Gaurhoth pit.
26. **Lúthien's escape + Sauron's isle (Ch.19):** Hírilorn house (Neldoreth) → escapes Doriath → found by Huan "near to the western eaves of Doriath" → Nargothrond → Huan leads her "north" out → bridge of Sauron's isle (Tol-in-Gaurhoth).
27. **Celegorm & Curufin flee Nargothrond (Ch.19):** Nargothrond → "north" through Dimbar, along Doriath's north marches, toward Himring (shunning Nan Dungortheb + Mountains of Terror) → meet Beren/Lúthien in Brethil → afterward ride east.
28. **Beren's second departure to Angband (Ch.19):** Doriath → "northward... to the Pass of Sirion" → skirts of Taur-nu-Fuin (looks across Anfauglith to Thangorodrim); Lúthien+Huan overtake, having turned aside to Sauron's isle for the fell-disguises → through Taur-nu-Fuin → drear dale before Gate of Angband.
29. **Inside Angband (Ch.19):** through Gate → "down the labyrinthine stairs" → nethermost hall (Morgoth's throne) → flee up → Gate (Carcharoth bites off hand).
30. **Eagle rescue (Ch.19):** Angband's valley → over Dor-nu-Fauglith → over Taur-nu-Fuin → above Tumladen (Lúthien sees Gondolin below) → set down "upon the borders of Doriath" (the dell); eagles return to Crissaegrim.
31. **Carcharoth's rampage (Ch.19):** North/Angband → "over Taur-nu-Fuin upon its eastern side" → "down from the sources of Esgalduin" → into woods of Doriath.
32. **Hunting of the Wolf (Ch.19):** Menegroth → over River Esgalduin → "turned east and north," following the river → dark valley where Esgalduin "fell in a torrent over steep falls" (Carcharoth found/slain; rocks choke the falls).

# D) ODDITIES / AMBIGUITIES

- **Two Gondolin entrances.** Ch.15 gives an underground water-way ("deep way under the mountains") as Turgon's route in; Ch.16 names the entrance the "Dry River and the secret path"; Ch.18 has eagles bear Húrin/Huor "beyond the Encircling Mountains" (i.e. over, by air). Whether the "deep way under the mountains" = the "Dry River" is not stated. [ambig]
- **Himlad's bounds.** Called "between Aros and Celon" (Ch.16); Aredhel enters it from the west by crossing "Esgalduin and Aros," and leaves it southward "over Celon" into Nan Elmoth; Estolad is on "east banks of the Celon south of Nan Elmoth" (Ch.17). Internally consistent (Aros = north/west side, Celon = south side), but the two rivers' exact roles are only inferable. [ambig]
- **One plain, three names.** Ard-galen (Ch.18) is renamed Anfauglith "the Gasping Dust" (Ch.18) yet Fingolfin rides "over Dor-nu-Fauglith" and Húrin crosses "the sands of Anfauglith" (both Ch.18), and eagles pass "over Dor-nu-Fauglith" (Ch.19) — the same burned plain under interchangeable names.
- **Mount of Fingolfin vs. Crissaegrim.** Thorondor's eyrie is in "the Crissaegrim" (Ch.18), and he lays Fingolfin on a "mountain-top that looked from the north upon the hidden valley of Gondolin" (Ch.18); the two are presumably the same range but not equated in the text. [ambig]
- **Rivil's Well placement.** Beren finds the Orc camp "at Rivil's Well above the Fen of Serech" (Ch.19), i.e. up in the north near the Pass of Sirion — a considerable move from his father's lair at Tarn Aeluin in east Dorthonion; the text implies a long pursuit but gives no distance. [ambig]
- **Bereg's dispersal.** "Bereg led a thousand of the people of Bëor away southwards," yet separately his like-minded folk "went back over the mountains into Eriador" (Ch.17) — two directions (south vs. east-over-mountains); whether these are one group or two is unclear. [ambig]
- **Spelling variants (same places):** "Dor-lómin" ~ "Dorlómin"; "Anfauglith" ~ "Dor-nu-Fauglith"; "Ered Lindon" ~ "Blue Mountains" ~ (implicitly) "Ered Luin" (the text uses Ered Lindon / Blue Mountains only).
- **Esgalduin's geography.** Its glades are in Neldoreth in central/north Doriath (Ch.19), yet its "sources" are placed beyond Taur-nu-Fuin's eastern side (Ch.19), and Carcharoth descends "from the sources of Esgalduin" into Doriath, while the Wolf-hunt goes "east and north" from Menegroth up the river to falls in a dark valley — consistent with sources lying far to the north, though no distance is given. [ambig]