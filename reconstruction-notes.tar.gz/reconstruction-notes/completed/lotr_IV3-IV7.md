Extraction complete — full span read (lines 29376–32436). Findings below.

# IV.3 THE BLACK GATE IS CLOSED

**Mordor's wall-structure (key world-geometry passage):**
- "Upon the west of Mordor marched the gloomy range of Ephel Dúath, the Mountains of Shadow, and upon the north the broken peaks and barren ridges of Ered Lithui, grey as ash." — two ranges meet at NW corner.
- "being indeed but parts of one great wall about the mournful plains of Lithlad and of Gorgoroth, and the bitter inland sea of Núrnen amidmost" — Mordor = ringed plains; Lithlad + Gorgoroth plains; Núrnen an inland sea "amidmost".
- "they swung out long arms northward; and between these arms there was a deep defile. This was Cirith Gorgor, the Haunted Pass, the entrance to the land of the Enemy." High cliffs on either side.
- "thrust forward from its mouth were two sheer hills, black-boned and bare. Upon them stood the Teeth of Mordor, two towers strong and tall" — built by "Men of Gondor in their pride" after Sauron's first overthrow; decayed; re-garrisoned by Sauron; windows "staring north and east and west". (Not named Narchost/Carchost in this span.)
- "Across the mouth of the pass, from cliff to cliff, the Dark Lord had built a rampart of stone. In it there was a single gate of iron" — the Morannon; flanking hills "bored into a hundred caves and maggot-holes" holding an orc host.

**Measured distance:** "a crow, maybe, would have flown but a furlong from their hiding-place to the black summit of the nearer tower" — hobbits' hollow lies ~1 furlong (straight flight) from nearer Tooth.

**Hobbits' position:** "a rocky hollow beneath the outstretched shadow of the northmost buttress of Ephel Dúath"; the hollow "delved in the side of a low hill, at some little height above a long trenchlike valley" between it and the mountain-wall; "In the midst of the valley stood the black foundations of the western watch-tower."

**Acoustic geography:** trumpets from the watch-towers answered from "hidden holds and outposts in the hills"; "further still, remote but deep and ominous, there echoed in the hollow land beyond the mighty horns and drums of Barad-dûr" — Barad-dûr audible from the Morannon; interior called "the hollow land".

**Three roads converge on the Gate:** "one winding back northwards; another dwindling eastwards into the mists that clung about the feet of Ered Lithui; and a third that ran towards him [Frodo]". The third turns "Westward... skirting the shoulders of the mountains, and went off southwards into the deep shadows that mantled all the western sides of Ephel Dúath... into the narrow land between the mountains and the Great River" — i.e. Ithilien is a "narrow land" between Ephel Dúath and Anduin.

**Gollum's road-lore (the Harad road):** following the road west of Ephel Dúath one comes "to a crossing in a circle of dark trees. On the right a road went down to Osgiliath and the bridges of the Anduin; in the middle the road went on southwards." Of the south road: "they say it goes a hundred leagues, until you can see the Great Water that is never still." Beyond: "further still there are more lands... the Yellow Face is very hot there, and there are seldom any clouds, and the men are fierce and have dark faces" — hot, cloudless far South [hearsay]. Southron soldiers "have come out of the South beyond the Great River's end: they came up that road."

**Left-hand (third) road:** "At once it begins to climb up, up, winding and climbing back towards the tall shadows" — to the old fortress = Minas Ithil/"Tower of the Moon" that "Isildur the son of Elendil built"; "the mountains are lower there, and the old road goes up and up, until it reaches a dark pass at the top, and then it goes down, down, again – to Gorgoroth" — pass over Ephel Dúath is the lowest crossing, descending straight into Gorgoroth.

**Strategic hydrography:** "He has conquered all the country west of the Shadowy Mountains down to the River, and He holds the bridges" — Anduin bridges (Osgiliath) in enemy hands; attack expected in the North ("He will come out of the Black Gate one day... That is the only way big armies can come").

**Gollum's secret way (preview of Cirith Ungol):** "A little path leading up into the mountains; and then a stair, a narrow stair... And then more stairs. And then... a tunnel, a dark tunnel; and at last a little cleft, and a path high above the main pass." Narrator: "Its name was Cirith Ungol."

**Timing:** "The moon was now three nights from the full"; night-flight south past the Towers ("For many miles the red eye seemed to stare at them") until "they had turned the dark northern shoulder of the lower mountains and were heading southwards."

# IV.4 OF HERBS AND STEWED RABBIT

**Key measured leg:** "By his reckoning it was nearly thirty leagues from the Morannon to the Cross-roads above Osgiliath, and he hoped to cover that distance in four journeys" — note "Cross-roads above Osgiliath". First night: "They had then walked almost eight leagues, and the hobbits could not have gone any further."

**Road condition:** "The road had been made in a long lost time, and for perhaps thirty miles below the Morannon it had been newly repaired"; southward "the wild encroached"; "It dwindled at last to a country cart-road little used; but it did not wind: it held on its own sure course" — straight Númenórean engineering, arched stream-crossings, broken pillars.

**Landscape gradient:** first "tumbled heathland, grown with ling and broom and cornel... knots of tall pine-trees", air like "the uplands of the Northfarthing far away"; then "the northern marches of that land that Men once called Ithilien, a fair country of climbing woods and swift-falling streams". After the second night they exit "a long cutting, deep, and sheer-sided" through a stony ridge; "the mountains were now much further off, receding eastward in a long curve"; westward "gentle slopes ran down into dim hazes far below".

**Ithilien climate charter (key passage):** "not until now in this more sheltered region had the hobbits felt the change of clime. Here Spring was already busy about them... Ithilien, the garden of Gondor now desolate kept still a dishevelled dryad loveliness." And: "South and west it looked towards the warm lower vales of Anduin, shielded from the east by the Ephel Dúath and yet not under the mountain-shadow, protected from the north by the Emyn Muil, open to the southern airs and the moist winds from the Sea far away."

**Vegetation catalogue:** "small woods of resinous trees, fir and cedar and cypress"; "groves and thickets... of tamarisk and pungent terebinth, of olive and of bay; and there were junipers and myrtles; and thymes... sages of many kinds... marjorams and new-sprouting parsleys"; saxifrages, stonecrops, primeroles, anemones, filbert-brakes, asphodel, lily-flowers; larches "green-fingered"; briar, eglantine, clematis. Water: "falling streams halted in cool hollows on their journey down to Anduin"; a lake "in the broken ruins of an ancient stone basin", spilling "over a stony lip at the far end". Scars: orc refuse-pits, wantonly hewn trees with "the fell sign of the Eye", fire-ring of charred bones.

**Rangers' geography:** Mablung and Damrod, "Rangers of Ithilien", descended from folk who lived there "before it was overrun"; they "crossed the Anduin secretly (how or where, they would not say) to harry the Orcs... between the Ephel Dúath and the River." **Measured:** "'It is close on ten leagues hence to the east-shore of Anduin,' said Mablung, 'and we seldom come so far afield.'" — ambush site (northern Ithilien, above the road's "cloven way") is ~10 leagues from Anduin's east shore.

**Harad lore:** "In those days our bounds were away south beyond the mouths of Anduin, and Umbar, the nearest of their realms, acknowledged our sway" — Umbar = nearest Harad realm, south of Anduin-mouths. Southrons now march "up the ancient roads... that craft of Gondor made." Mûmak of Harad stampedes; "his kin that live still in latter days are but memories of his girth."

# IV.5 THE WINDOW ON THE WEST

**Dates/durations:** Faramir left Minas Tirith six days before ("when I set out six days ago" no Company member had arrived). Boromir's horn heard "Five days ere I set out on this venture, eleven days ago at about this hour of the day... from the northward"; audible "anywhere within the bounds of Gondor, as the realm was of old". Funeral-boat vision "on the third night after", at midnight, "by the waters of Anduin... nigh Osgiliath, which our enemies now partly hold". Boromir "has passed down the River to the Sea."

**Horn shards' find-spots:** "one was found among the reeds where watchers of Gondor lay, northwards below the infalls of the Entwash; the other was found spinning on the flood" — Gondorian watchers stationed below Entwash-mouth.

**Boromir's intended land route:** "no boat could have been carried over the stony hills from Tol Brandir; and Boromir purposed to go home across the Entwash and the fields of Rohan."

**Henneth Annûn distance:** "a secret place we have, somewhat less than ten miles from here" (from ambush slope). Route: skirting the bathing-pool, "crossed the stream, climbed a long bank, and passed into green-shadowed woodlands that marched ever downwards and westwards"; later "the land began to fall more steeply... turned aside again, to the right, and came quickly to a small river in a narrow gorge: it was the same stream that trickled far above out of the round pool"; westward view "lowlands and broad meads, and glinting far off... the wide waters of the Anduin." Blindfolded "last mile": steeply descending single-file path between stone walls, stream-noise on the right, then "carried down, down many steps, and round a corner" into spray.

**Henneth Annûn itself:** wet doorstep of "a rough-hewn gate of rock", "in front a thin veil of water was hung... It faced westward." "This is the Window of the Sunset, Henneth Annûn, fairest of all the falls of Ithilien, land of many fountains." Engineering: "At one time the water flowed down through this cave and out of the arch, but its course was changed further up the gorge, by workmen of old, and the stream sent down in a fall of doubled height over the rocks far above." "There are now but two ways out: that passage yonder... and through the Window-curtain into a deep bowl filled with knives of stone." Cave holds "great store of arms and victuals"; two or three hundred men gather.

**Gondor-history geography (Faramir's discourse):** Stewards reckon from Mardil; Eärnur "last of the line of Anárion" never returned. Stewards recruited "from the sturdy folk of the sea-coast, and from the hardy mountaineers of Ered Nimrais". **Rohan cession:** "in the days of Cirion the Twelfth Steward (and my father is the six and twentieth)... at the great Field of Celebrant they destroyed our enemies that had seized our northern provinces. These are the Rohirrim... and we ceded to them the fields of Calenardhon that are since called Rohan; for that province had long been sparsely peopled." They guard "our northern marches and the Gap of Rohan." Rohirrim kin "dwell still far in the North"; descended from the Three Houses' folk "as went not over Sea into the West."
- Gandalf's range: "Mithrandir among the Elves, Tharkûn to the Dwarves; Olórin I was in my youth in the West... in the South Incánus, in the North Gandalf; to the East I go not."
- Dagorlad: Gandalf questioned "concerning the Great Battle that was fought upon Dagorlad in the beginning of Gondor". Isildur "went away from Gondor, never to be seen among mortal men again."
- Frodo's stated route-goal: "I was going to find a way into Mordor... I was going to Gorgoroth. I must find the Mountain of Fire and cast the thing into the gulf of Doom."

# IV.6 THE FORBIDDEN POOL

**Timing:** "night is drawing to an end, and the full moon is setting" — full moon ~3 nights after "three nights from the full" (consistent).

**Head of the falls:** up "many wet steps" to "a small flat landing cut in the stone" lit by "a long deep shaft"; two stairs, the left "wound its way up like a turret-stair" to "a wide flat rock without rail or parapet. At their right, eastwards, the torrent fell, splashing over many terraces", then a hewn channel plunging "sheer over the edge" on the left — outfall faces west.

**Long-range view W from above Henneth Annûn:** "Pale mists shimmered in the great vale below... beneath which rolled the cool night-waters of the Anduin. A black darkness loomed beyond, and in it glinted... white as the teeth of ghosts, the peaks of Ered Nimrais, the White Mountains of the realm of Gondor, tipped with everlasting snow." Faramir: "Moonset over Gondor. Fair Ithil... glances upon the white locks of old Mindolluin" — Mindolluin snow-capped, visible across Anduin. **Climate note:** "everlasting snow" on Ered Nimrais peaks.

**The pool:** waters "pour into a foaming bowl, and then swirl darkly about a deep oval basin in the rocks... out again through a narrow gate" into level reaches. Secrecy law: "Only to come here and look on the pool bears the penalty of death."

**Gondor's shrunken east bound:** "We of Gondor do not ever pass east of the Road in these days... nor has any of us set foot upon the Mountains of Shadow. Of them we know only old report" — the N–S Road is the de-facto frontier.

**Minas Morgul lore:** "that city was once a strong place, proud and fair, Minas Ithil, the twin sister of our own city"; taken by the Nine ("Nine Lords... issued forth from the gates of horror"); now "a place of sleepless malice, full of lidless eyes"; the vale filled "with decay". Frodo on the pass: "the path climbs... up into the mountains on the northern side of that vale where the old city stands. It goes up to a high cleft and so down to – that which is beyond." Faramir names it: "It is called Cirith Ungol"; "there is some dark terror that dwells in the passes above Minas Morgul."

**Jurisdiction:** Frodo declared "free in the realm of Gondor to the furthest of its ancient bounds" for a year and a day.

# IV.7 JOURNEY TO THE CROSS-ROADS

**Hydrology warning:** "do not drink of any stream that flows from Imlad Morgul, the Valley of Living Death."

**Gift:** staves of "the fair tree lebethron, beloved of the woodwrights of Gondor"; "The men of the White Mountains use them."

**Faramir's parting route-counsel:** "Go straight on [south], for thus you will have the cover of the woodland for many miles. On your west is an edge where the land falls into the great vales, sometimes suddenly and sheer... Keep near to this edge and the skirts of the forest."

**Measured leg:** "before the fall of night they halted, weary, for they had walked seven leagues or more from Henneth Annûn" (day 1 of 2 to the Cross-roads region; Sam is "hundreds of miles from Bag End").

**Second day terrain:** forest opens — "Great ilexes of huge girth... hoary ash-trees, and giant oaks"; "long launds of green grass dappled with celandine and anemones"; woodland-hyacinth acres.

**Forest-end vista over Morgul Vale mouth:** "A deep dim valley lay before them"; woods continue south beyond it. "To the right the Mountains of Gondor glowed, remote in the West... To the left lay darkness: the towering walls of Mordor; and out of that darkness the long valley came, falling steeply in an ever-widening trough towards the Anduin. At its bottom ran a hurrying stream... beside it on the hither side a road went winding down." Gollum: "This is the road from the Tower of the Moon, Master, down to the ruined city by the shores of the River" — Minas Morgul–Osgiliath road runs along "the voice of Morgulduin, the polluted stream that flowed from the Valley of the Wraiths". Far west in mist: "the high dim tops and broken pinnacles of old towers forlorn" [Osgiliath ruins].

**Climb to the Cross-roads:** eastward "up the dark sloping land... climbing steadily"; over "a great hog-back of land" thick with gorse (walkable beneath: "So tall were the spiny thickets that the hobbits could walk upright under them") and whortleberry. **Darkness of Mordor begins:** "no day came, only a dead brown twilight... In the East there was a dull red glare under the lowering cloud: it was not the red of dawn"; rumbling ground-tremors. Then "turning south... across a long broken slope that leaned up towards the mountains".

**The Cross-roads:** "the Southward Road, winding its way about the outer feet of the mountains, until presently it plunged into the great ring of trees"; inside, trees "stood in a great roofless ring, open in the middle... In the very centre four ways met. Behind them lay the road to the Morannon; before them it ran out again upon its long journey south; to their right the road from old Osgiliath came climbing up, and crossing, passed out eastward into darkness: the fourth way, the road they were to take." The Osgiliath road runs "almost as straight as a stretched ribbon down, down, into the West"; setting sun falls toward "the yet unsullied Sea".

**King's statue:** "a huge sitting figure, still and solemn as the great stone kings of Argonath"; head replaced "in mockery" by a rough stone painted with "one large red eye"; the true head by the roadside crowned by "a trailing plant with flowers like small white stars", with "yellow stonecrop" in the stone hair.

**Itinerary summary for this span:** Night 1 from Morannon-hollow: ~8 leagues S (of planned 4-journey, ~30-league trek to Cross-roads); day lie-up in heather; Night 2: on the road into N Ithilien; Day 3: lake camp, Southron ambush, evening to Henneth Annûn (<10 miles); Night 4 at Henneth Annûn (full moon sets at dawn); Day 4: depart, 7+ leagues S by nightfall; short night-halt in holm-oak; pre-dawn climb E over gorse hog-back; lie-up under thorns through the "dead brown twilight" day; after ~1 hour's evening march S, reach Cross-roads at nightfall. Faramir's scouts report the land "empty" up to within sight of the Morannon — "A waiting silence broods above the Nameless Land."