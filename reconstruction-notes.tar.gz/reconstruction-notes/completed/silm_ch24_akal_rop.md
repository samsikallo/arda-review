I have read all three chunks (lines 11594–13835). Below is the extracted geographic/spatial evidence, attributed by section: **[C24]** = Of the Voyage of Eärendil and the War of Wrath; **[Akal]** = Akallabêth; **[RoP]** = Of the Rings of Power and the Third Age.

---

## A) GAZETTEER
`# | Name | type | spatial relations | verbatim quote (≤20 words) | section`

**— Chapter 24 —**
1. Sirion's mouths / Havens of Sirion | river-mouth settlement | Eärendil's people dwelt there; Elwing sat there | "lord of the people that dwelt nigh to Sirion's mouths" | C24
2. Hither Lands | region | = Middle-earth; Eärendil's shore-voyages | "his voyages about the shores of the Hither Lands" | C24
3. Isle of Balar | island | Círdan dwelt there; refuge from sacked havens | "dwelt on the Isle of Balar with those of his people who escaped" | C24
4. Brithombar and Eglarest | havens | sacked; survivors fled to Balar | "escaped from the sack of the Havens of Brithombar and Eglarest" | C24
5. Nimbrethil | birchwood | timbers of Vingilot hewn there | "hewn in the birchwoods of Nimbrethil" | C24
6. Beleriand (coast) | coast | Eärendil turned homeward toward it | "turned homeward towards the coast of Beleriand" | C24
7. Enchanted Isles | isles | on route west; passed | "they came to the Enchanted Isles and escaped their enchantment" | C24
8. Shadowy Seas | sea | on route west, after Enchanted Isles | "they came into the Shadowy Seas and passed their shadows" | C24
9. Tol Eressëa / Lonely Isle | island | seen before Eldamar; looks both ways; whence one may reach Valinor | "the Lonely Isle, that looks both west and east; whence they might come even to Valinor" | C24
10. Bay of Eldamar | bay | anchorage on immortal shores; Teleri saw ship "out of the East" | "at the last they cast anchor in the Bay of Eldamar" | C24
11. Calacirya | pass/vale | Eärendil entered it alone, going up from shore | "he went up alone into the land, and came into the Calacirya" | C24
12. Valimar / Valinor | city/realm | inland; Elvenfolk gathered there at festival | "wellnigh all the Elvenfolk were gone to Valimar" | C24
13. Taniquetil | mountain | halls of Manwë atop | "gathered in the halls of Manwë upon Taniquetil" | C24
14. Tirion | city | on green hill of Túna; walls kept watch | "few were left to keep watch upon the walls of Tirion" | C24
15. Túna | green hill | Tirion stands on it; Eärendil climbed it | "Eärendil climbed the green hill of Túna and found it bare" | C24
16. Alqualondë / Haven of the Swans | haven | by sea-margin; Telerin fleets lay there | "she came near to Alqualondë, where lay the Telerin fleets" | C24
17. Shore of Aman / leaguer of Aman | coast | boundary mortals dare not pass | "dare to pass the leaguer of Aman" | C24
18. White tower (Elwing's) | tower | "northward upon the borders of the Sundering Seas" [ambig which shore] | "built for her a white tower northward upon the borders of the Sundering Seas" | C24
19. Door of Night | portal | at "uttermost rim of the world"; Vingilot passed through into heaven; Morgoth thrust through | "it passed through the Door of Night and was lifted up even into the oceans of heaven" | C24
20. Walls of the World / Timeless Void | boundary | Morgoth cast beyond, guard set | "thrust through the Door of Night beyond the Walls of the World, into the Timeless Void" | C24
21. Anfauglith | plain | Morgoth's marshalled power too great to fit | "Anfauglith could not contain it; and all the North was aflame with war" | C24
22. Angband | fortress-pits | winged dragons issued from | "out of the pits of Angband there issued the winged dragons" | C24
23. Thangorodrim | towers | broken when Ancalagon fell on them | "he fell upon the towers of Thangorodrim, and they were broken in his ruin" | C24

**— Akallabêth —**
24. Eressëa / Avallónë | isle/haven | nearest city to Valinor; first sight for mariners; easternmost Undying Land | "of all cities the nearest to Valinor... the first sight that the mariner beholds" | Akal
25. Andor / Elenna / Anadûnê / Númenórë | island-realm | between M-e and Valinor, sundered by wide sea, nearer Valinor | "neither part of Middle-earth nor of Valinor... yet it was nearer to Valinor" | Akal
26. Meneltarma | mountain | "in the midst of the land"; hallowed summit; tombs at feet | "in the midst of the land was a mountain tall and steep... the Meneltarma, the Pillar of Heaven" | Akal
27. Andúnië | city/haven | "in the midst of its western coasts"; faced sunset | "called Andúnië because it faced the sunset" | Akal
28. Tombs of the Kings | tombs | "at the feet of the mountain" (Meneltarma) | "At the feet of the mountain were built the tombs of the Kings" | Akal
29. Armenelos | city | on a hill "hard by" the tombs; Elros's citadel; Nimloth in courts | "hard by upon a hill was Armenelos, fairest of cities" | Akal
30. Rómenna | harbour | eastern; chief dwelling of Faithful in later days | "the chief dwelling of the Faithful... was thus nigh to the harbour of Rómenna" | Akal
31. Oromet (hill) | hill | "nigh to Andúnië"; tower of King Minastir on it | "the ancient tower of King Minastir upon the hill of Oromet nigh to Andúnië" | Akal
32. Pelargir | haven | Elf-friends' haven, "above the mouths of Anduin the Great" | "their haven was Pelargir above the mouths of Anduin the Great" | Akal
33. Land of Gil-galad / north | realm | Elf-friends came to it; northern coasts | "seeking the northern coasts where they might speak still with the Eldar" | Akal
34. Mordor | land | fortified by Sauron; Barad-dûr built there | "he had fortified the land of Mordor and had built there the Tower of Barad-dûr" | Akal
35. Barad-dûr | tower | Sauron's; he came from it to Ar-Pharazôn | "Even from his mighty tower of Baraddûr he came" | Akal
36. Umbar | haven | landing-place of Ar-Pharazôn's fleet; Númenórean haven | "came at last to that place that was called Umbar, where was the mighty haven" | Akal
37. Hill (Ar-Pharazôn's) | hill | reached after seven days' march inland from Umbar | "he came to a hill... he sat him down in the midst of the land" | Akal
38. Great rift / chasm | sea-chasm | opened "between Númenor and the Deathless Lands"; Númenor "nigh to the east of" it | "a great chasm opened in the sea between Númenor and the Deathless Lands" | Akal
39. Caves of the Forgotten | caves | where Ar-Pharazôn's men buried under falling hills of Aman | "buried under falling hills... imprisoned in the Caves of the Forgotten" | Akal
40. Mar-nu-Falmar / Atalantë | drowned land | = Númenor after downfall | "Mar-nu-Falmar that was whelmed in the waves, Akallabêth the Downfallen" | Akal
41. Straight Road / Straight Way | invisible road | bridge through Ilmen to Tol Eressëa, maybe Valinor | "the old road and the path of the memory of the West still went on... a mighty bridge invisible" | Akal

**— Rings of Power —**
42. Lindon | land | formerly Beleriand remnant; Gil-galad's realm; Elrond there | "That country had of old been named Lindon by the Noldor" | RoP
43. Ered Luin (Mountains of Lune) | mountains | walls broken in east/Ossiriand; gap toward south | "the walls of Ered Luin were broken, and a great gap was made in them towards the south" | RoP
44. Gulf of Lhûn / River Lhûn | gulf/river | sea flowed into gap; Lhûn fell by new course | "Into that gulf the River Lhûn fell by a new course... the Gulf of Lhûn" | RoP
45. Mithlond / Grey Havens | havens | "upon the shores of the Gulf of Lhûn"; good harbourage; ships to Straight Road | "the Elves built their havens, and named them Mithlond" | RoP
46. Eregion / Hollin | realm | Noldor realm "beyond the Ered Luin"; "nigh to" Khazad-dûm | "Eregion was nigh to the great mansions of the Dwarves that were named Khazad-dûm" | RoP
47. Khazad-dûm / Hadhodrond / Moria | Dwarf-mansions | west-gate linked to Ost-in-Edhil by highroad | "the highroad ran to the west gate of Khazad-dûm" | RoP
48. Ost-in-Edhil | city | city of the Elves in Eregion; highroad west to Moria | "From Ost-in-Edhil, the city of the Elves, the highroad ran to the west gate" | RoP
49. Mountain of Fire / Land of Shadow | volcano/land | where Sauron forged One Ring (=Orodruin/Mordor) | "Sauron forged it in the Mountain of Fire in the Land of Shadow" | RoP
50. Imladris / Rivendell | refuge/valley | founded by Elrond after Eregion fell; "fair valley" | "the stronghold and refuge of Imladris, that Men called Rivendell, was founded by Elrond" | RoP
51. Misty Mountains | mountains | Gil-galad's power passed beyond them; Last Alliance crossed | "passed beyond the Misty Mountains and the Great River" | RoP
52. Great River / Anduin | river | flows out of Rhovanion to Bay of Belfalas | "the Great River Anduin, that flows out of Rhovanion into the western sea in the Bay of Belfalas" | RoP
53. Greenwood the Great | forest | later Mirkwood; Thranduil's realm | "the name of that forest was Greenwood the Great" | RoP
54. Annúminas | city | Elendil's chief city, beside Lake Nenuial | "his chief city was at Annúminas beside the water of Lake Nenuial" | RoP
55. Lake Nenuial | lake | Annúminas beside it | (same as above) | RoP
56. Eriador | region | Elendil's realm; rivers Lhûn and Baranduin | "his people dwelt in many places in Eriador about the courses of the Lhûn and the Baranduin" | RoP
57. Fornost / North Downs | city/downs | Númenóreans dwelt there | "At Fornost upon the North Downs also the Númenóreans dwelt" | RoP
58. Cardolan; Rhudaur (hills) | regions | Númenóreans dwelt | "in Cardolan, and in the hills of Rhudaur" | RoP
59. Emyn Beraid | tower-hills | towers "still look towards the sea"; Elostirion tallest | "the towers of Emyn Beraid still look towards the sea" | RoP
60. Amon Sûl | hill/tower | tower raised; palantír set | "towers they raised upon Emyn Beraid and upon Amon Sûl" | RoP
61. Elostirion | tower | tallest of Emyn Beraid towers; seeing-stone; Elendil gazed west, saw Avallónë | "the Seeing Stone of Emyn Beraid was set in Elostirion, the tallest of the towers" | RoP
62. Gondor | realm | southern kingdom of Isildur/Anárion | "a realm in those lands that were after called Gondor" | RoP
63. Arnor | realm | Northern Kingdom | "the Northern Kingdom was named Arnor" | RoP
64. Bay of Belfalas | bay | Anduin's mouth flows into it | (quote at #52) | RoP
65. Osgiliath | city | chief city of Gondor; Great River flows through midst; great bridge | "The chief city of this southern realm was Osgiliath, through the midst of which the Great River flowed" | RoP
66. Minas Ithil | tower-city | eastward on shoulder of Mountains of Shadow; threat to Mordor; Isildur's house | "Minas Ithil... eastward upon a shoulder of the Mountains of Shadow as a threat to Mordor" | RoP
67. Minas Anor | tower-city | westward at feet of Mount Mindolluin; Anárion's house | "to the westward Minas Anor... at the feet of Mount Mindolluin, as a shield" | RoP
68. Mount Mindolluin | mountain | Minas Anor at its feet; later seedling found in its snows | "at the feet of Mount Mindolluin" | RoP
69. Argonath; Aglarond; Erech | works | built "in the land" of Gondor | "at the Argonath, and at Aglarond, and at Erech" | RoP
70. Isengard / Angrenost | circle-fortress | circle enclosing Orthanc | "in the circle of Angrenost, which Men called Isengard" | RoP
71. Orthanc | pinnacle-tower | "of unbreakable stone" in Isengard | "they made the Pinnacle of Orthanc of unbreakable stone" | RoP
72. Ephel Dúath / Mountains of Shadow | mountains | Mordor "beyond" them; "marched with Gondor upon the east" | "his ancient kingdom of Mordor beyond the Ephel Dúath, the Mountains of Shadow" | RoP
73. Gorgoroth (valley) | valley | Barad-dûr built "above" it; filled with ash | "above the valley of Gorgoroth was built his fortress... Barad-dûr" | RoP
74. Orodruin / Amon Amarth / Mount Doom | volcano | "in that land"; nigh to Barad-dûr | "there was a fiery mountain in that land that the Elves named Orod-ruin" | RoP
75. Haradrim lands | region | "wide lands south of Mordor beyond the mouths of Anduin" | "the Haradrim... dwelt in the wide lands south of Mordor beyond the mouths of Anduin" | RoP
76. Dagorlad | plain | "the Battle Plain, which lies before the gate of the Black Land" | "upon the host of Sauron on Dagorlad, the Battle Plain" | RoP
77. Gladden Fields / Loeg Ningloron | marsh | Isildur's death; "between the Greenwood and the Great River" | "in his camp between the Greenwood and the Great River, nigh to Loeg Ningloron" | RoP
78. Minas Morgul (was Minas Ithil) | tower-city | Nazgûl's; "ever at war with Minas Anor in the west" | "it was called Minas Morgul... ever at war with Minas Anor in the west" | RoP
79. Minas Tirith (was Minas Anor) | tower-city | guarded passage of River; west of Anduin lands protected | "named anew Minas Tirith, the Tower of Guard" | RoP
80. Rohan / Calenardhon | land | "green land"; formerly part of Gondor | "the green land of Rohan, which before was named Calenardhon" | RoP
81. Falls of Rauros / Gates of Argonath | falls/gates | northward defences beyond them | "northward, beyond the Falls of Rauros and the Gates of Argonath" | RoP
82. Lothlórien / Lórien | hidden land | "between Celebrant and Anduin"; Galadriel; Ring of Adamant | "Lothlórien, the hidden land between Celebrant and Anduin" | RoP
83. Dol Guldur | dark hill | "in the south of the forest" (Mirkwood); Sauron's abode | "he took up his abode in the south of the forest... the Sorcerer of Dol Guldur" | RoP
84. Land of the Periannath | region | Halflings' land, "in the west of Eriador" | "the Little People, the Halflings, who dwelt in the west of Eriador" | RoP
85. Black Gates of Mordor | gate | Heir of Isildur led host there (War of Ring) | "led the host of the West to the Black Gates of Mordor" | RoP

*Note: **Eldalondë** and **Lond Daer** are NOT mentioned in these lines. Havens/harbours actually named: Umbar, Pelargir, Rómenna, Andúnië, Mithlond/Grey Havens, and the unnamed haven "about the mouths of Anduin."*

---

## B) MEASUREMENTS (verbatim + section)
- "he was the thirteenth King" (Tar-Atanamir) [Akal]
- "the Realm of Númenor had endured for more than two thousand years" [Akal]
- "Elros lived five hundred years, and ruled the Númenóreans four hundred years and ten" [Akal]
- "the eleventh King of Númenor" (Tar-Minastir) [Akal]
- "the twentieth king took the sceptre" (Adûnakhôr) [Akal]
- "Ar-Gimilzôr the twenty-third king" [Akal]
- "Silmarien, daughter of Tar-Elendil the fourth king of Númenor" [Akal]
- "Gimilkhâd died two years before his two hundredth year" [Akal]
- "four and twenty Kings and Queens had ruled the Númenóreans before" [Akal]
- "For seven days he journeyed with banner and trumpet" (Ar-Pharazôn from Umbar) [Akal]
- "ere three years had passed he had become closest to the secret counsels of the King" (Sauron) [Akal]
- Temple: "the walls were fifty feet in thickness, and the width of the base was five hundred feet across the centre, and the walls rose from the ground five hundred feet" [Akal]
- "the land lay under a cloud for seven days" (burning of Nimloth) [Akal]
- "Nine ships there were: four for Elendil, and for Isildur three, and for Anárion two" [Akal]
- "on the nine and thirtieth day since the passing of the fleets" (the Downfall) [Akal]
- "over the leagues of the Sea" / "came at last over leagues of sea" (voyage to Andor) [Akal]
- "they laid siege to it for seven years" (Barad-dûr, Last Alliance) [RoP]
- "the third and twentieth of the line of Meneldil" (Telemnar) [RoP]
- "the seventh king that followed Valandil" (Eärendur) [RoP]
- "well nigh a third of that age of the world had passed" (Mirkwood darkens) [RoP]
- "the nine and thirtieth heir in the right line from Isildur" (Aragorn) [RoP]

---

## C) ITINERARIES (ordered legs + section)

**1. Eärendil's successful voyage to Aman [C24]:** coast of Beleriand / Sirion's mouths → West → waters "no vessels save those of the Teleri had known" → Enchanted Isles (escaped) → Shadowy Seas (passed shadows) → sighted Tol Eressëa (tarried not) → anchored **Bay of Eldamar** → landed on immortal shores → went up alone into land → **Calacirya** → climbed green hill of **Túna** → entered empty **Tirion** → turned back "shoreward" → summoned to **Valimar/Valinor**.

**2. Vingilot to the sky [C24]:** borne "through Valinor to the uttermost rim of the world" → through **Door of Night** → "lifted up even into the oceans of heaven."

**3. Host of the Valar [C24]:** Teleri sailed ships "east over the sea" bearing host of Valinor → "march... to the north of Middle-earth" → **Beleriand** ablaze → Great Battle on **Anfauglith**/"all the North."

**4. Edain to Númenor [Akal]:** set sail following the Star → "over leagues of sea" → sighted **Andor** → "went up out of the sea."

**5. Ar-Pharazôn's expedition east [Akal]:** set sail "with his host into the East" → sails "up out of the sunset" → **Umbar** → seven days' march inland → a hill "in the midst of the land"; Sauron came from **Barad-dûr**.

**6. The Great Armada to Aman [Akal]:** fleets on west of Númenor → wind "arose in the east" wafted them → "sailed into forbidden seas" → "encompassed Avallónë and all the isle of Eressëa" → "came even to Aman... the coasts of Valinor" → encamped "about Túna."

**7. Amandil's embassy [Akal]:** small ship by night → "steered first eastward, and then went about and passed into the west" → never heard of again.

**8. Elendil's survivors east [Akal/RoP]:** nine ships driven by great wind "roaring from the west" → after many days cast on shores of Middle-earth. Split: (a) **Elendil** cast up in **Lindon** → up **River Lhûn** → beyond **Ered Luin** → realm in **Eriador**, chief city **Annúminas** by Lake Nenuial. (b) **Isildur & Anárion** borne "southwards" → up **Anduin** → realm of **Gondor** (Osgiliath, Minas Ithil east / Minas Anor west).

**9. Last Alliance muster [RoP]:** marched "east into Middle-earth" → halted at **Imladris** → "crossed the Misty Mountains by many passes" → "marched down the River Anduin" → **Dagorlad** (battle) → passed into **Mordor** → besieged Barad-dûr seven years → Gorgoroth (Anárion slain).

**10. Isildur's last march [RoP]:** from **Minas Anor** (planted Tree) → "marched north from Gondor by the way that Elendil had come" → camp "between the Greenwood and the Great River, nigh to Loeg Ningloron, the Gladden Fields" → ambushed → fled to River, plunged in, Ring lost, slain by arrows. (Valandil & wife left safe in Imladris.)

**11. Elrond's departure [RoP]:** "sailed out of Mithlond, until the seas of the Bent World fell away beneath it... passed into the Ancient West."

---

## D) WORLD-STRUCTURE QUOTES (verbatim, ≤40 words)

**Drowning of Beleriand [C24]:** "the northern regions of the western world were rent asunder, and the sea roared in through many chasms, and there was confusion and great noise; and rivers perished or found new paths... and Sirion was no more."

**Drowning of Beleriand [RoP, fuller detail]:** "Beleriand was broken and laid waste; and northward and westward many lands sank beneath the waters of the Great Sea. In the east, in Ossiriand, the walls of Ered Luin were broken, and a great gap was made in them towards the south, and a gulf of the sea flowed in."

**Position of Andor/Númenor [Akal]:** "A land was made for the Edain to dwell in, neither part of Middle-earth nor of Valinor, for it was sundered from either by a wide sea; yet it was nearer to Valinor. It was raised by Ossë out of the depths of the Great Water."

**Visibility of Avallónë from Númenor [Akal]:** "they would look out and descry far off in the west a city white-shining on a distant shore, and a great harbour and a tower... only the keenest eyes among them that could see this vision, from the Meneltarma."

**The Ban [Akal]:** "the Lords of Valinor forbade them to sail so far westward that the coasts of Númenor could no longer be seen."

**Changing the world / chasm [Akal]:** "he changed the fashion of the world; and a great chasm opened in the sea between Númenor and the Deathless Lands, and the waters flowed down into it... and the world was shaken."

**Removal of Aman [Akal]:** "the land of Aman and Eressëa of the Eldar were taken away and removed beyond the reach of Men for ever."

**Destruction of Númenor's position [Akal]:** "it was nigh to the east of the great rift, and its foundations were overturned, and it fell and went down into darkness, and is no more."

**World made round / new lands [Akal]:** "Ilúvatar cast back the Great Seas west of Middle-earth, and the Empty Lands east of it, and new lands and new seas were made; and the world was diminished, for Valinor and Eressëa were taken from it into the realm of hidden things."

**New coasts [Akal]:** "all the coasts and seaward regions of the western world suffered great change and ruin... the seas invaded the lands, and shores foundered, and ancient isles were drowned, and new isles were uplifted; and hills crumbled and rivers were turned into strange courses."

**World made round (confirmed) [Akal]:** "the kings of Men knew that the world was indeed made round, and yet the Eldar were permitted still to depart and to come to the Ancient West and to Avallónë, if they would."

**The Straight Road [Akal]:** "a Straight Road must still be, for those that were permitted to find it... the old road and the path of the memory of the West still went on, as it were a mighty bridge invisible that... traversed Ilmen... until it came to Tol Eressëa."

**"All roads are now bent." [Akal]** — mariners' saying after circumnavigating the round world.

---

## E) ODDITIES / AMBIGUITIES

1. **Beleriand's drowning told twice** — [C24] gives a general rending ("Sirion was no more"); [RoP] gives specific geography (Ered Luin gap toward south, Gulf of Lhûn, Ossiriand). Complementary, not contradictory, but differ in scope.
2. **Thangorodrim "broken" narrated twice** — [C24] by Ancalagon's fall; [RoP] "When Thangorodrim was broken and Morgoth overthrown" (summary). Same event.
3. **Name collision "Celeborn"** — [Akal] "Celeborn, the White Tree that grew in the midst of Eressëa" vs. **Celeborn of Doriath**, Galadriel's husband [C24, RoP]. Same name, tree vs. person. [ambig]
4. **Elwing's white tower** — "northward upon the borders of the Sundering Seas" is unanchored to a named coast; context (far-sighted Elves of the Lonely Isle see her) implies near Tol Eressëa, but not stated. [ambig]
5. **Barad-dûr's founding date** — [Akal] says Sauron "already in the days of Tar-Minastir, the eleventh King... had built there the Tower of Barad-dûr," tied to "when the One Ring was forged and there was war... in Eriador." [RoP] narrates ring-forging/Eregion war without a Númenórean regnal date; the two must be cross-referenced for a timeline. [ambig on exact synchronization]
6. **Meneltarma isle** — explicitly legendary/uncertain: "Among the Exiles many believed that the summit... rose again above the waves"; mariners "found it not." Mark as belief, not established geography.
7. **Avallónë "nearest to Valinor"** [Akal 24] vs. "easternmost of the Undying Lands" [Akal] — consistent (easternmost = nearest to Númenor/Men), but note "nearest to Valinor" describes proximity of the *haven* to Valinor within Aman, a different axis than its easternmost-facing-Men position.
8. **Recurring "nine and thirtieth"** — the Downfall falls on "the nine and thirtieth day"; Aragorn is "the nine and thirtieth heir." Coincidence of number, not a spatial contradiction.
9. **"nearer to Valinor" yet Ban forbids seeing past own coasts** — Andor is stated nearer Valinor, yet Númenóreans could only glimpse Avallónë from Meneltarma/a lawful ship; the actual sea-distance to Aman is never numerically given. [ambig — no league count for the Númenor–Aman gap]
10. **Direction of Isildur's ambush** — Orcs "lay in wait in the Misty Mountains" yet struck his camp "between the Greenwood and the Great River" (i.e., east of the mountains, in the Vales of Anduin near Gladden). Slight tension between "in the Misty Mountains" and the camp's stated position east of them. [ambig]