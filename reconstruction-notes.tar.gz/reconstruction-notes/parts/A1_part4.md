# A1 Part 4 — Geographic/Spatial Evidence: Book I Ch 11–12, Book II Ch 1
Source: C_lotr.txt lines 8619–11354. Chapters: "A Knife in the Dark" (KID), "Flight to the Ford" (FF), "Many Meetings" (MM). Only statements from this text; [ambig] marks uncertainty. Line refs are to the txt file.

## CH 11 — A KNIFE IN THE DARK

### Crickhollow / Buckland (opening scene)
- Simultaneity: "As they prepared for sleep in the inn at Bree, darkness lay on Buckland; a mist strayed in the dells and along the river-bank" (8621). Buckland has dells and a river-bank (the Brandywine).
- Crickhollow house: has a door, gate, lane outside, garden, back door, fields beyond (8622–8651).
- "When he reached the nearest house, more than a mile away, he collapsed" (8651) — nearest neighbour to Crickhollow >1 mile.
- Attack timing: "The cold hour before dawn was passing" (8638).
- Horn-call of Buckland "had not been sounded for a hundred years, not since the white wolves came in the Fell Winter, when the Brandywine was frozen over" (8663–8665). Climate datum: Brandywine froze in Fell Winter, ~100 years before.
- Riders' escape: "the Black Riders rode like a gale to the North-gate... They rode down the guards at the gate and vanished from the Shire" (8671–8675). Buckland has a North-gate with guards; Buckland counted as "the Shire" here.

### Bree departure
- Ponies stolen from inn stables; only one horse actually stolen, others driven off, "found wandering in different corners of the Bree-land" (8776–8778).
- Merry's ponies "made their way to the Downs in search of Fatty Lumpkin. So they came under the care of Tom Bombadil" (8780) — the Downs within pony-range of Bree; later sent back to Butterbur ("five good beasts").
- Economics: Bill Ferny's pony cost "twelve silver pennies... at least three times the pony's value in those parts"; Butterbur gave Merry "another eighteen pence"; "thirty silver pennies was a sore blow" (8767–8773).
- "In the end there was more than three hours' delay" ... "It was close on ten o'clock before they at last got off" (8752, 8806).
- Onlookers: "Most of the inhabitants of Bree and Staddle, and many even from Combe and Archet, were crowded in the road" (8811).
- Bill Ferny's house: "a dark ill-kept house behind a thick hedge: the last house in the village" near "the further gate" (8836–8837). Escort "turned back at the South-gate" (8864) — the further (east/south) gate of Bree = South-gate.

### Road east of Bree; Bree-land layout
- "Passing through, they kept on along the Road for some miles. It bent to the left, curving back into its eastward line as it rounded the feet of Bree-hill, and then it began to run swiftly downwards into wooded country" (8865–8867).
- "To their left they could see some of the houses and hobbit-holes of Staddle on the gentler south-eastern slopes of the hill; down in a deep hollow away north of the Road there were wisps of rising smoke that showed where Combe lay; Archet was hidden in the trees beyond" (8867–8871). So: Staddle on SE slopes of Bree-hill; Combe in a deep hollow N of the Road; Archet in trees beyond Combe.
- "After the Road had run down some way, and had left Bree-hill standing tall and brown behind, they came on a narrow track that led off towards the North" (8872–8873).
- Strider's plan: "to go towards Archet at first, but to bear right and pass it on the east, and then to steer as straight as he could over the wild lands to Weathertop Hill. In that way they would... cut off a great loop of the Road, which further on bent southwards to avoid the Midgewater Marshes" (8882–8892). ROAD SHAPE: loops south to avoid Midgewater.

### Chetwood and Midgewater Marshes
- Day 1: wandering course in Chetwood woods ("woods in the valley... leafy"; many crossing paths). Day 2: "began to steer a steady course eastwards" (8913).
- "On the third day out from Bree they came out of the Chetwood. The land had been falling steadily, ever since they turned aside from the Road, and they now entered a wide flat expanse of country" (8914–8917). "They were far beyond the borders of the Bree-land, out in the pathless wilderness, and drawing near to the Midgewater Marshes" (8917–8918).
- Marsh terrain: damp, boggy, pools, "wide stretches of reeds and rushes filled with the warbling of little hidden birds"; "no permanent trail even for Rangers to find through their shifting quagmires"; clouds of midges (8919–8928). Pippin: "Midgewater! There are more midges than water!" (8929).
- Neekerbreekers: "abominable creatures haunting the reeds... evil relatives of the cricket... thousands" (8940–8943).
- Day 4 ("The next day, the fourth, was little better" 8945). Night of day 4: "far away there came a light in the eastern sky: it flashed and faded many times... not the dawn, for that was still some hours off" — Strider: "like lightning that leaps up from the hill-tops" (8948–8955). [Later tied to Gandalf on Weathertop Oct 3.]
- Day 5: "They had not gone far on the fifth day when they left the last straggling pools and reed-beds of the marshes behind them. The land before them began steadily to rise again" (8959–8961). So marsh crossing occupied ~days 3–5.

### First sight of Weathertop; the Weather Hills approach
- "Away in the distance eastward they could now see a line of hills. The highest of them was at the right of the line and a little separated from the others. It had a conical top, slightly flattened at the summit" (8961–8963). Weathertop = highest, at right (south) end of line seen from the west, slightly separated, conical flattened top.
- Strider: "That is Weathertop... The Old Road, which we have left far away on our right, runs to the south of it and passes not far from its foot. We might reach it by noon tomorrow, if we go straight towards it" (8964–8967). Road passes S of Weathertop near its foot; ~1.5 days from marsh edge.
- "It commands a wide view all round" (8977).
- Plan: "go as straight eastward from here as we can, to make for the line of hills, not for Weathertop. There we can strike a path I know that runs at their feet; it will bring us to Weathertop from the north and less openly" (8992–8995). Path at western feet of the hills; approach from north.
- Day 5 evening: "they came to a stream that wandered down from the hills to lose itself in the stagnant marshland, and they went up along its banks" — camp "under some stunted alder-trees by the shores of the stream" (9003–9006). A west-flowing stream from the hills dies in Midgewater. "the bleak and treeless backs of the hills" ahead (9008). Moon waxing.
- Day 6: frost in air. "The hills drew nearer. They made an undulating ridge, often rising almost to a thousand feet, and here and there falling again to low clefts or passes leading into the eastern land beyond. Along the crest of the ridge the hobbits could see what looked to be the remains of green-grown walls and dikes, and in the clefts there still stood the ruins of old works of stone" (9022–9027). ELEVATION: hills often almost 1000 ft; ruins of walls/dikes/forts; passes lead east.
- "By night they had reached the feet of the westward slopes, and there they camped. It was the night of the fifth of October, and they were six days out from Bree" (9032–9034). DATE ANCHOR: night Oct 5 = 6 days out (departure Sept 30).

### The hidden path and Amon Sûl lore
- Day 7 (Oct 6): "In the morning they found... a track plain to see. They turned right and followed it southwards" (9035–9036). Track hidden "both of the hill-tops above and of the flats to the west", dives into dells, hugs steep banks, "lines of large boulders and hewn stones that screened the travellers almost like a hedge" (9037–9042).
- Strider: "There is no barrow on Weathertop, nor on any of these hills. The Men of the West did not live here; though in their latter days they defended the hills for a while against the evil that came out of Angmar. This path was made to serve the forts along the walls. But long before, in the first days of the North Kingdom, they built a great watch-tower on Weathertop, Amon Sûl they called it. It was burned and broken, and nothing remains of it now but a tumbled ring, like a rough crown on the old hill's head. Yet once it was tall and fair. It is told that Elendil stood there watching for the coming of Gil-galad out of the West, in the days of the Last Alliance" (9047–9055). HISTORY: no barrows; Angmar defense era forts; Amon Sûl watch-tower of the first days of the North Kingdom; Elendil watched westward from it.
- Gil-galad lay: "the last whose realm was fair and free / between the Mountains and the Sea" (9062–9063); "into darkness fell his star / in Mordor where the shadows are" (9070–9071).
- Approach to summit: "It was already mid-day when they drew near the southern end of the path, and saw... a grey-green bank, leading up like a bridge on to the northward slope of the hill" (9092–9095).

### Weathertop summit and dell
- "On the western flank of Weathertop they found a sheltered hollow, at the bottom of which there was a bowl-shaped dell with grassy sides" (9100–9101).
- Climb: "After half an hour's plodding climb Strider reached the crown of the hill; Frodo and Merry followed, tired and breathless. The last slope had been steep and rocky" (9103–9104).
- Summit: "a wide ring of ancient stone-work, now crumbling or covered with age-long grass. But in the centre a cairn of broken stones had been piled. They were blackened as if with fire... the grass was scorched" (9105–9109).
- VIEW: "they saw all round below them a wide prospect, for the most part of lands empty and featureless, except for patches of woodland away to the south, beyond which they caught here and there the glint of distant water [ambig: unnamed water S of the Road]; Beneath them on this southern side there ran like a ribbon the Old Road, coming out of the West and winding up and down, until it faded behind a ridge of dark land to the east. Nothing was moving on it. Following its line eastward with their eyes they saw the Mountains: the nearer foothills were brown and sombre; behind them stood taller shapes of grey, and behind those again were high white peaks glimmering among the clouds" (9110–9124). Misty Mountains visible E from Weathertop: 3 bands (brown foothills, grey, white peaks).
- "There is no water and no shelter" on the summit (9126). But near the dell: "Not far away they found a spring of clear water in the hillside" (9203–9204).
- G-rune stone on the cairn: "G3... a sign that Gandalf was here on October the third: that is three days ago now" (9144–9145). Also "the light that we saw three nights ago in the eastern sky" tied to attack on Gandalf here (9153–9155). Confirms current date Oct 6.
- Gandalf's pace: "Even if he was a day or two behind us at Bree, he could have arrived here first. He can ride very swiftly" (9128–9130).

### KEY DISTANCE STATEMENTS (Strider, on the summit)
- "I don't know if the Road has ever been measured in miles beyond the Forsaken Inn, a day's journey east of Bree" (9161–9162). FORSAKEN INN: a day's journey east of Bree; Road unmeasured beyond it.
- "But I know how long it would take me on my own feet, with fair weather and no ill fortune: twelve days from here to the Ford of Bruinen, where the Road crosses the Loudwater that runs out of Rivendell. We have at least a fortnight's journey before us, for I do not think we shall be able to use the Road" (9165–9174). Weathertop→Ford: 12 days (Strider alone, on foot); ≥ fortnight for the party off-Road. Loudwater "runs out of Rivendell"; Ford = where Road crosses Loudwater.
- Riders sighted below: "two black specks were moving slowly along it, going westward; and... three others were creeping eastward" (9182–9184) — five on the Road "beyond the foot of the hill".
- Road proximity: enemies "on the Road, only a few miles away" from the dell (9227–9228).
- Strategic geography: "All we could do would be to go right out of our way back north on this side of the line of hills, where the land is all much the same as it is here. The Road is watched, but we should have to cross it, if we tried to take cover in the thickets away to the south. On the north side of the Road beyond the hills the country is bare and flat for miles" (9236–9241). Thickets lie S of the Road; N of Road beyond the hills = bare flat country for miles.
- Region's emptiness: "The lands ahead were empty of all save birds and beasts... Rangers passed at times beyond the hills... trolls might stray down at times out of the northern valleys of the Misty Mountains. Only on the Road would travellers be found, most often dwarves" (9280–9286).
- Food: "we have used more than we ought, if we have two weeks still to go, and perhaps more" (9289–9290).

### Tale of Tinúviel (world-structure/First Age geography, as told)
- "the Great Enemy, of whom Sauron of Mordor was but a servant, dwelt in Angband in the North"; "the Elves of the West coming back to Middle-earth"; Beren "came over the Mountains of Terror into the hidden Kingdom of Thingol in the forest of Neldoreth"; "the enchanted river Esgalduin"; "The Sundering Seas between them lay"; the Wolf "from the gates of Angband"; the pair passed "beyond the confines of this world"; Eärendil "sailed his ship out of the mists of the world into the seas of heaven with the Silmaril upon his brow. And of Eärendil came the Kings of Númenor, that is Westernesse" (9425–9459).
- Attack: five figures; "felt, rather than saw, a shadow rise" over "the lip of the little dell, on the side away from the hill" (9498); Ring vision: "five tall figures: two standing on the lip of the dell, three advancing"; king with crown, knife (9523–9533). Frodo wounded in left shoulder; cries "O Elbereth! Gilthoniel!"

## CH 12 — FLIGHT TO THE FORD

### Aftermath and plan
- Slashed cloak: "A foot above the lower hem there was a slash" (9607–9608).
- Athelas: "this plant does not grow in the bare hills; but in the thickets away south of the Road I found it"; "a healing plant that the Men of the West brought to Middle-earth... it grows now sparsely and only near places where they dwelt or camped of old; and it is not known in the North, except to some of those who wander in the Wild" (9625–9633).
- Departure (Oct 7): "They started off in a southerly direction. This would mean crossing the Road, but it was the quickest way to more wooded country" (9664–9665). Fuel needed.
- ROAD SHAPE: "his plan to shorten their journey by cutting across another great loop of the Road: east beyond Weathertop it changed its course and took a wide bend northwards" (9668–9670).
- "They made their way slowly and cautiously round the south-western slopes of the hill, and came in a little while to the edge of the Road... even as they were hurrying across they heard far away two cries" (9671–9674).
- Land S of Road: "sloped away southwards, but it was wild and pathless; bushes and stunted trees grew in dense patches with wide barren spaces in between. The grass was scanty, coarse, and grey" (9675–9679). Cheerless land.

### Days southward/eastward; sighting the rivers
- "Four days passed, without the ground or the scene changing much, except that behind them Weathertop slowly sank, and before them the distant mountains loomed a little nearer" (9690–9693).
- "At the end of the fifth day the ground began once more to rise slowly out of the wide shallow valley into which they had descended. Strider now turned their course again north-eastwards" (9703–9705).
- Day 6: "on the sixth day they reached the top of a long slow-climbing slope, and saw far ahead a huddle of wooded hills. Away below them they could see the Road sweeping round the feet of the hills; and to their right a grey river gleamed pale in the thin sunshine. In the distance they glimpsed yet another river in a stony valley half-veiled in mist" (9706–9710). Wooded hills ahead (NE); Road sweeps round their feet; grey river (Hoarwell) to the right; second river (Loudwater) in stony misty valley in distance.

### Hoarwell/Mitheithel, Greyflood, Last Bridge — KEY QUOTES
- Strider: "We have now come to the River Hoarwell, that the Elves call Mitheithel. It flows down out of the Ettenmoors, the troll-fells north of Rivendell, and joins the Loudwater away in the South. Some call it the Greyflood after that. It is a great water before it finds the Sea. There is no way over it below its sources in the Ettenmoors, except by the Last Bridge on which the Road crosses" (9712–9717). HYDROLOGY: Hoarwell rises in Ettenmoors (troll-fells N of Rivendell); joins Loudwater away in the South; combined = Greyflood; reaches the Sea; sole crossing below sources = Last Bridge.
- "That is Loudwater, the Bruinen of Rivendell... The Road runs along the edge of the hills for many miles from the Bridge to the Ford of Bruinen. But I have not yet thought how we shall cross that water" (9719–9722). Road hugs hill-edge for many miles Bridge→Ford.
- Day 7, early morning: down to the Road; rain here "two days before" washed out tracks (9724–9729).
- "after a mile or two they saw the Last Bridge ahead, at the bottom of a short steep slope" (9735–9736).
- Beryl: "I found it in the mud in the middle of the Bridge... a beryl, an elf-stone" (9743–9745). "They crossed the Bridge in safety, hearing no sound but the water swirling against its three great arches" (9749–9750). BRIDGE: three great arches.
- "A mile further on they came to a narrow ravine that led away northwards through the steep lands on the left of the Road. Here Strider turned aside" (9750–9752). Turn-off: 1 mile east of Last Bridge, northwards.

### The hill country N of the Road (trolls' country; name "Trollshaws" NOT used in text)
- "a sombre country of dark trees winding among the feet of sullen hills... As they went forward the hills about them steadily rose. Here and there upon heights and ridges they caught glimpses of ancient walls of stone, and the ruins of towers: they had an ominous look" (9752–9758).
- Frodo recalls "Bilbo's account of his journey and the threatening towers on the hills north of the Road, in the country near the Trolls' wood" (9760–9762).
- Strider: "Trolls do not build. No one lives in this land. Men once dwelt here, ages ago; but none remain now. They became an evil people... they fell under the shadow of Angmar. But all were destroyed in the war that brought the North Kingdom to its end... a shadow still lies on the land" (9767–9772). Rivendell "many more things... are remembered in Rivendell"; Strider "dwelt there once" (9781–9783).
- "The hills now began to shut them in. The Road behind held on its way to the River Bruinen, but both were now hidden from view. The travellers came into a long valley; narrow, deeply cloven, dark and silent. Trees with old and twisted roots hung over cliffs, and piled up behind into mounting slopes of pine-wood" (9786–9790).
- "They had been two days in this country when the weather turned wet. The wind began to blow steadily out of the West and pour the water of the distant seas on the dark heads of the hills in fine drenching rain" (9795–9798). CLIMATE: west wind carries sea-rain.
- "The next day the hills rose still higher and steeper before them, and they were forced to turn away northwards out of their course. Strider... they were nearly ten days out from Weathertop, and their stock of provisions was beginning to run low. It went on raining" (9800–9804).
- Camp: "a stony shelf with a rock-wall behind them, in which there was a shallow cave, a mere scoop in the cliff" (9805–9806).
- Strider's survey: "We have come too far to the north... If we keep on as we are going we shall get up into the Ettendales far north of Rivendell. That is troll-country, and little known to me. We could perhaps find our way through and come round to Rivendell from the north; but it would take too long... So somehow or other we must find the Ford of Bruinen" (9830–9837). ETTENDALES: far north of Rivendell; troll-country; a possible northern approach to Rivendell exists.
- "They found a passage between two hills that led them into a valley running south-east... towards the end of the day they found their road again barred by a ridge of high land; its dark edge... broken into many bare points like teeth of a blunted saw" (9839–9843). Climbed to "a narrow saddle between two higher points" (9850). Night cold on the high ridge; fire "under the gnarled roots of an old pine, that hung over a shallow pit: it looked as if stone had once been quarried there" (9879–9881).
- Next morning: survey "from the height to the east of the pass": "If they went on, down the further side of the ridge, they would have the Mountains on their left. Some way ahead Strider had caught a glimpse of the Loudwater again, and he knew that, though it was hidden from view, the Road to the Ford was not far from the River and lay on the side nearest to them" (9890–9897). Road on the near (NW) side of Loudwater, close to it; heading SE with Mountains on the left.

### Troll path, troll-hole, stone trolls, Bilbo's trail
- Pippin finds a path "that climbed with many windings out of the woods below and faded away on the hill-top behind... a path made by strong arms and heavy feet. Here and there old trees had been cut or broken down, and large rocks cloven or heaved aside" (9911–9919).
- Troll-hole: path "ran on over a level strip under the face of a low cliff... In the stony wall there was a door hanging crookedly ajar upon one great hinge... a cave or rock-chamber behind... on the floor lay many old bones... some great empty jars and broken pots" — "certainly a troll-hole, but... long forsaken" (9930–9944).
- Path "broad enough for four or five hobbits to walk abreast" (9950–9951).
- Stone trolls: "Down in a clearing in the woods not far below... three large trolls. One was stooping, and the other two stood staring at him" (9954–9962). "These must be the very three that were caught by Gandalf, quarrelling over the right way to cook thirteen dwarves and one hobbit" (9966–9973); bird's nest behind one troll's ear; midday meal in the glade "under the shadow of the trolls' large legs" (9989).
- "In the afternoon they went on down the woods. They were probably following the very track that Gandalf, Bilbo, and the dwarves had used many years before. After a few miles they came out on the top of a high bank above the Road. At this point the Road had left the Hoarwell far behind in its narrow valley, and now clung close to the feet of the hills, rolling and winding eastward among woods and heather-covered slopes towards the Ford and the Mountains" (10079–10084). ROAD: leaves Hoarwell's narrow valley behind; clings to hill-feet, winding E toward Ford and Mountains.
- Trolls' gold stone: "Not far down the bank Strider pointed out a stone in the grass... dwarf-runes and secret marks... the stone that marked the place where the trolls' gold was hidden" (10085–10089).
- "they climbed down the bank, and turning left went off as fast as they could" (10097–10098) — left = eastward on the Road. "A cold wind flowed down to meet them from the mountains ahead" (10099–10100).

### Glorfindel
- Hiding spot: hazel patch; "they could see the Road, faint and grey in the failing light, some thirty feet below them" (10114–10115).
- "This is Glorfindel, who dwells in the house of Elrond" (10144–10145). "I was sent from Rivendell to look for you... He had not [reached Rivendell] when I departed; but that was nine days ago" (10146–10150). Glorfindel left Rivendell 9 days before this meeting; Gandalf not yet arrived then.
- Elrond's intelligence: "Some of my kindred, journeying in your land beyond the Baranduin,* learned that things were amiss" — footnote: "* The Brandywine River" (10156–10157, 10198). Baranduin = Brandywine. Elves journeying beyond the Baranduin sent messages; "Elrond sent out north, west, and south" riders (10162).
- "It was my lot to take the Road, and I came to the Bridge of Mitheithel, and left a token there, nigh on seven days ago. Three of the servants of Sauron were upon the Bridge, but they withdrew and I pursued them westward. I came also upon two others, but they turned away southward. Since then I have searched for your trail. Two days ago I found it, and followed it over the Bridge; and today I marked where you descended from the hills again" (10165–10171). Also: "There are five behind us... Where the other four may be, I do not know. I fear that we may find the Ford is already held against us" (10173–10176).

### Final legs to the Ford
- Night march after meeting: "On he led them, into the mouth of darkness... Not until the grey of dawn did he allow them to halt" (10226–10228); slept "a few yards from the road-side" (10233).
- "They had rested rather less than five hours when they took to the Road again... only allowed two brief halts during the day's march. In this way they covered almost twenty miles before nightfall, and came to a point where the Road bent right and ran down towards the bottom of the valley, now making straight for the Bruinen" (10253–10258). PACE: ~20 miles/day; Road bends right, descends valley toward Bruinen.
- Next morning: "There were many miles yet to go between them and the Ford" (10270–10271). "The Road was still running steadily downhill, and there was now in places much grass at either side" (10274–10275).
- "In the late afternoon they came to a place where the Road went suddenly under the dark shadow of tall pine-trees, and then plunged into a deep cutting with steep moist walls of red stone. Echoes ran along... There at the bottom of a sharp incline they saw before them a long flat mile, and beyond that the Ford of Rivendell. On the further side was a steep brown bank, threaded by a winding path; and behind that the tall mountains climbed, shoulder above shoulder, and peak beyond peak, into the fading sky" (10276–10287). FORD APPROACH: pine-shadow → red-stone cutting → sharp incline → "a long flat mile" → Ford; far side steep brown bank with winding path; mountains beyond.
- Ambush: five Riders emerge from the cutting behind; "out from the trees and rocks away on the left four other Riders came flying. Two rode towards Frodo; two galloped madly towards the Ford" (10317–10320). Total NINE at the water's edge (10350–10351).
- "it was useless to try to escape over the long uncertain path from the Ford to the edge of Rivendell" (10354–10355). Rivendell's edge lies beyond a long path from the Ford.
- Frodo's defiance: "Go back to the Land of Mordor, and follow me no more!" (10361).
- Flood: "the river below him rise... a plumed cavalry of waves... white riders upon white horses with frothing manes. The three Riders that were still in the midst of the Ford were overwhelmed" (10378–10383); the rest driven into the flood by maddened horses (10395–10397).

## CH 1 (Book II) — MANY MEETINGS

### Date/time anchors
- "In the house of Elrond, and it is ten o'clock in the morning... the morning of October the twenty-fourth" (10417–10418).
- Gandalf: "I heard news of them only after I left you in June" (10483–10484).
- Frodo: "I have had a month of exile and adventure" (10519).
- Frodo's reckoning: "I can't bring the total up to October the twenty-fourth. It ought to be the twenty-first. We must have reached the Ford by the twentieth" (10522–10524).
- Gandalf: "four nights and three days, to be exact. The Elves brought you from the Ford on the night of the twentieth, and that is where you lost count" (10535–10536). Splinter found "last night" (10542; = night Oct 23).
- "that splinter, which you bore for seventeen days" (10553–10554). (Oct 6 wound → Oct 23 removal = 17 days.)
- Council: "there is a Council early tomorrow" (11346; = Oct 25).

### Ford battle detail (Gandalf's account)
- "Close to the Ford there is a small hollow beside the road masked by a few stunted trees. There they hastily kindled fire" (10645–10646).
- "Elrond commanded it [the flood]... The river of this valley is under his power, and it will rise in anger when he has great need to bar the Ford. As soon as the captain of the Ringwraiths rode into the water the flood was released" (10665–10668). Gandalf "added a few touches": waves as "great white horses with shining white riders"; "many rolling and grinding boulders" (10668–10671).
- "There is great vigour in the waters that come down from the snows of the Misty Mountains" (10673–10674). Bruinen fed by Misty Mountains snow.
- "Your friends crossed after the flood had passed and they found you lying on your face at the top of the bank... Elrond's folk met them, carrying you slowly towards Rivendell" (10659–10663).
- Three Riders swept by first assault; others hurled in by their horses (10652–10654); horses perished, Ringwraiths crippled but not destroyed.

### Rivendell — position, house, valley, climate
- "Frodo was now safe in the Last Homely House east of the Sea. That house was, as Bilbo had long ago reported, 'a perfect house, whether you like food or sleep or story-telling...'" (10696–10698).
- House layout: "several passages and down many steps and out into a high garden above the steep bank of the river"; friends "sitting in a porch on the side of the house looking east. Shadows had fallen in the valley below, but there was still a light on the faces of the mountains far above. The air was warm. The sound of running and falling water was loud, and the evening was filled with a faint scent of trees and flowers, as if summer still lingered in Elrond's gardens" (10741–10748). CLIMATE: warm sheltered valley, summer lingers late (late Oct); waterfall(s) audible; mountains rise far above valley.
- "Evil things do not come into this valley... We are sitting in a fortress. Outside it is getting dark" (10752–10755). "the master of the Dark Tower of Mordor, whose power is again stretching out over the world" (10753–10754).
- Hall: Elrond at head of long table on a dais; Hall of Fire: "no tables, but a bright fire... between the carven pillars"; "There is always a fire here, all the year round, but there is little other light" (10945–10953).
- Bilbo's room: "It opened on to the gardens and looked south across the ravine of the Bruinen" (11333–11334). The house stands north of the Bruinen ravine [inferred from this sightline].
- Frodo next morning walks "along the terraces above the loud-flowing Bruinen" (11357–11358, chapter boundary line).
- Arwen: "Long she had been in the land of her mother's kin, in Lórien beyond the mountains, and was but lately returned to Rivendell" (11814–11816 approx; actual lines 10814–10816). LÓRIEN: beyond the mountains from Rivendell. Her brothers ride "with the Rangers of the North" (10818).
- Gandalf on Rivendell's people: "lords of the Eldar from beyond the furthest seas... those who have dwelt in the Blessed Realm live at once in both worlds" (10590–10597). "there is a power in Rivendell to withstand the might of Mordor, for a while: and elsewhere other powers still dwell. There is power, too, of another kind in the Shire" (10603–10605).
- Rangers: "the last remnant in the North of the great people, the Men of the West" (10513–10514); "The race of the Kings from over the Sea is nearly at an end" (10506–10507). Aragorn = "Dúnadan... Man of the West, Númenórean" (11083–11085).

### Wilderland news (Glóin) — GEOGRAPHY OF THE NORTH-EAST
- Beornings: "Grimbeorn the Old, son of Beorn, was now the lord of many sturdy men, and to their land between the Mountains and Mirkwood neither orc nor wolf dared to go" (10874–10876).
- "if it were not for the Beornings, the passage from Dale to Rivendell would long ago have become impossible. They are valiant men and keep open the High Pass and the Ford of Carrock. But their tolls are high" (10877–10880). ROUTE: Dale↔Rivendell passage via High Pass and Ford of Carrock, kept open by Beornings.
- Dale/Bardings: "Nowhere are there any men so friendly to us as the Men of Dale... The grandson of Bard the Bowman rules them, Brand son of Bain son of Bard. He is a strong king, and his realm now reaches far south and east of Esgaroth" (10887–10891).
- Erebor: Glóin "so far from the Lonely Mountain" (10865); "Dáin was still King under the Mountain... passed his two hundred and fiftieth year" (10903–10905). Balin, Ori, Óin missing — "It is largely on account of Balin that I have come to ask the advice of those that dwell in Rivendell" (10914–10916).
- Dwarf-works: "great labours in Dale and under the Mountain... the waterways of Dale... the fountains, and the pools... stone-paved roads of many colours... halls and cavernous streets under the earth with arches carved like trees; and the terraces and towers upon the Mountain's sides" (10918–10928). "the Desolation of Smaug" changed (10931).
- Bilbo's travels: left Hobbiton, "wandered off aimlessly, along the Road or in the country on either side... steered all the time towards Rivendell"; "after a rest I went on with the dwarves to Dale: my last journey... Then I came back here" (11005–11011). News reaches Rivendell "from over the Mountains, and out of the South, but hardly anything from the Shire" (11017–11018).

### Eärendil song (world-structure cosmography)
- Arvernien (Eärendil tarried there); boat "of timber felled in Nimbrethil" (11119–11122).
- Voyage: "he wandered far from northern strands"; "From gnashing of the Narrow Ice where shadow lies on frozen hills, from nether heats and burning waste"; "at last he came to Night of Naught"; driven "from west to east... homeward" (11144–11159).
- With the Silmaril: "from Otherworld beyond the Sea there strong and free a storm arose, a wind of power in Tarmenel"; "Through Evernight he back was borne on black and roaring waves that ran o'er leagues unlit and foundered shores that drowned before the Days began, until he heard on strands of pearl where ends the world the music long" (11168–11186). SUNKEN SHORES: lands drowned before the Days began.
- "He saw the Mountain silent rise where twilight lies upon the knees of Valinor, and Eldamar beheld afar beyond the seas... to Elvenhome the green and fair where keen the air, where pale as glass beneath the Hill of Ilmarin a-glimmer in a valley sheer the lamplit towers of Tirion are mirrored on the Shadowmere" (11187–11198). GEOGRAPHY OF THE WEST: the Mountain at Valinor's knees; Eldamar beyond the seas; Elvenhome; Hill of Ilmarin; Tirion's towers over the Shadowmere.
- "through the Calacirian to hidden land forlorn he went. He came unto the timeless halls... endless reigns the Elder King in Ilmarin on Mountain sheer" (11205–11210).
- New ship: "to sail the shoreless skies and come behind the Sun and light of Moon. From Evereven's lofty hills... his wings him bore... beyond the mighty Mountain Wall. From World's End then he turned away" (11232–11238).
- Return: "on high above the mists he came, a distant flame before the Sun, a wonder ere the waking dawn where grey the Norland waters run. And over Middle-earth he passed" (11242–11246); doomed "to pass, and tarry never more on Hither Shores where mortals are"; "the Flammifer of Westernesse" (11250–11257).
- Frodo's vision: "the firelit hall became like a golden mist above seas of foam that sighed upon the margins of the world" (11107–11109).
- Elvish hymn "A Elbereth Gilthoniel... nef aear, sí nef aearon" (11314–11320); "songs of the Blessed Realm" (11331–11332).

## CHRONOLOGY RECONSTRUCTION (this chunk)
- Night Sept 29/30 [ambig: date inferred from Oct 5 = "six days out"]: Crickhollow raid (before dawn) and Bree stable raid the same night.
- Sept 30 (day 1): leave Bree ~10:00; south round Bree-hill; north track toward Archet; Chetwood.
- Oct 1 (day 2): steady course eastward in/near Chetwood.
- Oct 2 (day 3): out of Chetwood; enter marsh-borders; miserable day.
- Oct 3 (day 4): in Midgewater; night: flashes in eastern sky (= attack on Gandalf at Weathertop, per G3 rune + Strider's guess).
- Oct 4 (day 5): out of marshes early; land rises; evening reach stream at hill-feet.
- Oct 5 (day 6): approach ridge (~1000 ft); camp at feet of westward slopes ("night of the fifth of October... six days out from Bree").
- Oct 6 (day 7): track south along west side of hills; midday: bank onto north slope of Weathertop; dell on western flank; half-hour climb to summit; ~evening: 5 Riders on Road; night: attack in dell; Frodo wounded.
- Oct 7: cross Road S of Weathertop into thickets.
- Oct 7–10: four days SE through scrubland, little change.
- Oct 11 (5th day out): ground rises; turn NE.
- Oct 12 (6th day): view of wooded hills, Hoarwell, distant Loudwater.
- Oct 13 (7th day): morning to Road; 1–2 miles to Last Bridge; cross; 1 mile on, turn north into ravine into hill country.
- Oct 14–15: two days in hill country; then rain (wind from West).
- Oct 16: hills higher; forced north; "nearly ten days out from Weathertop"; rain.
- Oct 17: Strider's survey (too far north — Ettendales ahead); SE valley; evening climb over saw-toothed ridge to saddle; cold night camp.
- Oct 18: survey east of pass; descend south side; troll path; troll-hole; stone-troll clearing (midday meal); afternoon few miles down to bank above Road; dusk: Glorfindel meets them (he left Rivendell 9 days before = Oct 9; token at Bridge "nigh on seven days ago" ≈ Oct 11–12; found trail Oct 16, followed over Bridge; night march begins.
- Oct 19: halt at dawn; <5 hrs rest; ~20 miles by nightfall; Road bends right toward Bruinen.
- Oct 20: morning start; late afternoon red-stone cutting; the flat mile; Ford crossing; flood; "The Elves brought you from the Ford on the night of the twentieth."
- Oct 20–24: Frodo unconscious "four nights and three days"; splinter removed night of Oct 23; wakes 10:00 Oct 24; feast + Hall of Fire that evening; Council next morning (Oct 25).
- Cross-check: Weathertop (Oct 6) → Ford (Oct 20) = 14 days; Strider had predicted "at least a fortnight" off-Road (exactly met) vs "twelve days" for himself alone.

## CONTRADICTIONS / ODDITIES (this chunk)
1. No hard contradictions found within this chunk. Notable tensions:
2. Strider's forecast vs actual: "twelve days from here to the Ford" (alone) and "at least a fortnight" (party) — actual party time Oct 6→20 = exactly 14 days, despite the wound, the lost days in the northern hills, and the final mounted dash. The "fortnight" is met to the day.
3. Glorfindel's timeline: left Rivendell Oct 9 (9 days before Oct 18), at the Last Bridge "nigh on seven days ago" (≈Oct 11–12); the party crossed the Bridge Oct 13 and found the beryl — consistent only if Glorfindel placed it Oct 11–12 and then patrolled W/S for days; "Two days ago I found it [the trail], and followed it over the Bridge" (Oct 16) — yet the party left the Road (and any trail) only 1 mile beyond the Bridge on Oct 13, and had wandered far north; how the mounted elf then took 2 more days to catch them is unexplained [oddity, not contradiction].
4. Bree gates: the text calls the eastern exit "the further gate" and then "the South-gate" (the escort turns back there) — consistent with a Road that leaves Bree southward before curving east round Bree-hill, but the naming can confuse ("further gate" vs the West-gate of Ch 9, which is another fork's chunk).
5. Weathertop's hills are described only as "a line of hills"/"these hills" here — the name "Weather Hills" does not occur in this chunk.
6. The "glint of distant water" seen far south of the Road from Weathertop is unnamed [ambig].
7. Buckland's status: Riders leaving Buckland via the North-gate "vanished from the Shire" — treats Buckland as part of the Shire.

## WORLD-STRUCTURE COLLECTED (this chunk)
- "the Last Homely House east of the Sea" (MM).
- Gil-galad's realm "between the Mountains and the Sea"; he fell "in Mordor" (KID).
- First Age: Great Enemy in Angband in the North; Mountains of Terror; Thingol's hidden kingdom in Neldoreth; river Esgalduin; Sundering Seas; "beyond the confines of this world" (KID).
- Eärendil: sailed "out of the mists of the world into the seas of heaven"; Kings of Númenor = Westernesse (KID); full cosmography in the Rivendell song: Arvernien, Nimbrethil, Narrow Ice, Night of Naught, Otherworld beyond the Sea, Tarmenel, Evernight, foundered shores "drowned before the Days began", strands of pearl "where ends the world", the Mountain at "the knees of Valinor", Eldamar, Elvenhome, Hill of Ilmarin, towers of Tirion on the Shadowmere, the Calacirian, Elder King in Ilmarin, "shoreless skies... behind the Sun and light of Moon", Evereven, "the mighty Mountain Wall", World's End, "grey the Norland waters", "Hither Shores where mortals are", "Flammifer of Westernesse" (MM).
- Eldar of Rivendell "from beyond the furthest seas"; the Blessed Realm; dwellers there "live at once in both worlds" (MM).
- Rangers = Men of the West, "Kings from over the Sea" (MM); Dúnadan = Númenórean (MM).
- Athelas brought to Middle-earth by the Men of the West; unknown in the North except near their old dwellings (FF).
- West wind pours "the water of the distant seas" as rain on the hills (FF).
- Mordor: the Dark Tower; black horses "born and bred to the service of the Dark Lord in Mordor" (MM); "the Land of Mordor" (FF).
- Wilderland frame: Beorning land between the Mountains and Mirkwood; High Pass + Ford of Carrock on the Dale–Rivendell passage; Dale/Esgaroth/Lonely Mountain; Brand's realm "far south and east of Esgaroth" (MM).
