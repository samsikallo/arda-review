# A1 Part 3 — Book I Ch 7–10 (In the House of Tom Bombadil; Fog on the Barrow-downs; At the Sign of the Prancing Pony; Strider)

Source: C_lotr.txt lines 6270–8618. All quotes verbatim from this file. No outside knowledge used. [ambig] = ambiguous in text.

## Book I, Ch 7 — In the House of Tom Bombadil

### Tom's house — structure and position
- Main room: "a long low room" with hearth; entered over "the wide stone threshold" (l.6273).
- Bedroom: "a low room with a sloping roof (a penthouse, it seemed, built on to the north end of the house)" (l.6364-65). Four mattresses. Windows "at either end of the room, one looking east and the other looking west" (l.6507-08).
- House sits below a hill-top: "nothing passes door and window here save moonlight and starlight and the wind off the hill-top" (Goldberry, l.6391-93; echoed l.6498-99).
- Position vs Barrow-downs: "the house of Tom Bombadil nestled under the very shoulder of those dreaded hills" (l.6628) — i.e., under the shoulder of the Barrow-downs. In Ch 8, Frodo recalls it as "the house down under the Hill" (l.7118), and Tom's provisions are "from 'down under Hill'" (l.6908).
- East window view (Frodo): kitchen-garden; "above and far beyond them the grey top of the hill loomed up against the sunrise" (l.6513-14) — a hill immediately E of house.
- West window view (Pippin): "down into a pool of mist. The Forest was hidden under a fog" (l.6519-20); "a fold or channel where the mist was broken...: the valley of the Withywindle. The stream ran down the hill on the left and vanished into the white shadows" (l.6521-24). Facing west, "on the left" = southwards [ambig: viewer-relative]. So Old Forest lies W/below the house; Withywindle valley is a fold in it; a stream descends the house's hill and runs into the Forest.
- Breakfast room "looked westward over the mist-clouded valley" (l.6548). "Thatched eaves" (l.6549). Path outside is chalk: "the white chalky path turn into a little river of milk and go bubbling away down into the valley" (l.6565-66).
- Flower-garden and "a clipped hedge silver-netted" near house on W side (l.6524-25).

### Goldberry
- "I am Goldberry, daughter of the River" (l.6294). Frodo: "Fair River-daughter!" (l.6314).
- Tom found her "in a wide pool, deep and clear, far down Withywindle; / there they open first in spring" (water-lily pool far down the Withywindle) (l.6422-24): "By that pool long ago I found the River-daughter, / fair young Goldberry sitting in the rushes" (l.6424-25). The River of which she is daughter = Withywindle [strongly implied by context; ambig].
- Tom goes there "Each year at summer's end" (l.6421); will not pass "Old Man Willow's house this side of spring-time" (l.6431).
- Her rain-song "told the tale of a river from the spring in the highlands to the Sea far below" (l.6556-57).

### Tom's domain and nature
- Goldberry: "He is the Master of wood, water, and hill" (l.6335-36). But "all this strange land" does NOT belong to him: "The trees and the grasses and all things growing or living in the land belong each to themselves. Tom Bombadil is the Master" (l.6338-44).
- Tom is "Eldest": "Tom was here before the river and the trees; Tom remembers the first raindrop and the first acorn. He made paths before the Big People, and saw the little People arriving. He was here before the Kings and the graves and the Barrow-wights. When the Elves passed westward, Tom was here already, before the seas were bent. He knew the dark under the stars when it was fearless – before the Dark Lord came from Outside" (l.6656-63).
- All paths in the Forest lead to the Withywindle: "We guessed you'd come ere long down to the water: all paths lead that way, down to Withywindle" (l.6412-13).

### Old Forest / Old Man Willow
- Old Forest "indeed ancient, a survivor of vast forgotten woods" (l.6596); fathers of trees "ageing no quicker than the hills" (l.6597).
- Great Willow: "his song and thought ran through the woods on both sides of the river" (l.6602-03); dominion over "nearly all the trees of the Forest from the Hedge to the Downs" (l.6605-06). => Forest extent bounded by the Hedge (W) and the Downs (E).

### Barrow-downs (Tom's tales)
- Tom's talk goes "leaping up the young stream, over bubbling waterfalls... wandering at last up on to the Downs" (l.6607-10) — the young stream (Withywindle headwaters) rises toward/on the Downs [ambig: implied source direction].
- Downs content: "the Great Barrows, and the green mounds, and the stone-rings upon the hills and in the hollows among the hills" (l.6610-11). "Green walls and white walls rose. There were fortresses on the heights. Kings of little kingdoms fought together" (l.6612-13); "towers fell, fortresses were burned"; "mounds covered them [dead kings and queens], and the stone doors were shut" (l.6617). Later "A shadow came out of dark places far away... Barrow-wights walked in the hollow places" (l.6619-21).
- Even in the Shire "the rumour of the Barrow-wights of the Barrow-downs beyond the Forest had been heard" (l.6624-25) — Barrow-downs are "beyond the Forest" from Shire viewpoint.
- Rain fell "on the bare heads of the Downs" (l.6563) — treeless downs; weather from the West ("The upper wind settled in the West", l.6562).

### Route advice (Tom)
- "make nearly due North from his house, over the western and lower slopes of the Downs: they might hope in that way to strike the East Road in a day's journey, and avoid the Barrows" (l.6767-69). **MEASUREMENT: house→East Road = a day's journey due N over western/lower slopes.**
- "pass barrows by on the west-side" (l.6780).
- Weather: "weather in that country was a thing that even Tom could not be sure of for long" (l.6763).

### Frodo's dream (vision, not literal journey geography)
- "a black wall of rock, pierced by a dark arch like a great gate... the rock-wall was a circle of hills, and that within it was a plain, and in the midst of the plain stood a pinnacle of stone, like a vast tower but not made by hands. On its top stood the figure of a man... A mighty eagle swept down and bore him away" (l.6454-66). Hoofs "galloping, galloping... from the East" (l.6468). [Unnamed in text here; a tower-plain-hill-ring locale.]

## Book I, Ch 8 — Fog on the Barrow-downs

### Departure and hilltop view
- Morning "cool, bright, and clean under a washed autumn sky of thin blue. The air came fresh from the North-west" (l.6804-05).
- Path "wound away from behind the house, and went slanting up towards the north end of the hill-brow under which it sheltered" (l.6809-10) — house shelters under a hill-brow; exit path climbs to its north end.
- View from hill-top (Goldberry's brow):
  - W: the Forest knoll "rising pale and green out of the dark trees in the West. In that direction the land rose in wooded ridges, green, yellow, russet under the sun, beyond which lay hidden the valley of the Brandywine" (l.6824-27).
  - S: "over the line of the Withywindle, there was a distant glint like pale glass where the Brandywine River made a great loop in the lowlands and flowed away out of the knowledge of the hobbits" (l.6828-35). => Withywindle line lies S of the viewpoint; Brandywine great loop beyond it, in lowlands.
  - N: "beyond the dwindling downs the land ran away in flats and swellings of grey and green and pale earth-colours, until it faded into a featureless and shadowy distance" (l.6836-37).
  - E: "the Barrow-downs rose, ridge behind ridge into the morning, and vanished out of eyesight into a guess... a guess of blue and a remote white glimmer blending with the hem of the sky... of the high and distant mountains" (l.6838-41). => Distant mountains (blue + white glimmer) visible/guessed far E from the Downs.
- "go jogging aside over the crumpled skirts of the downs towards the Road" (l.6844-45) — Road N via downs' skirts.

### Downs terrain and the saucer hill
- "no tree nor any visible water: it was a country of grass and short springy turf" (l.6866-67); hollow valleys and hill-tops alternate; "high lonely cries of strange birds".
- About mid-day: "a hill whose top was wide and flattened, like a shallow saucer with a green mounded rim" (l.6881). From it, N view: "the Downs were coming to an end. A long valley lay below them winding away northwards, until it came to an opening between two steep shoulders. Beyond, there seemed to be no more hills. Due north they faintly glimpsed a long dark line" (l.6886-89).
- Merry: "That is a line of trees... and that must mark the Road. All along it for many leagues east of the Bridge there are trees growing. Some say they were planted in the old days" (l.6890-92). **MEASUREMENT: trees line the East Road for many leagues east of the (Brandywine) Bridge** [Bridge unnamed here; = "the Bridge"].
- E from saucer hill: "on that side the hills were higher and looked down upon them; and all those hills were crowned with green mounds, and on some were standing stones, pointing upwards like jagged teeth out of green gums" (l.6896-99). => Eastern downs higher, mound-crowned.
- Centre of the saucer hollow: "a single stone, standing tall under the sun above, and at this hour casting no shadow... like a landmark, or a guarding finger, or more like a warning" (l.6901-03). They lunch against "the east side of the stone" (l.6905); stone unnaturally cool.

### Fog trap and the barrow
- They wake late: stone "cast a long pale shadow that stretched eastward" (l.6915-16); sun "just above the west wall of the hollow"; fog "north, south, and east" (l.6918); sun sets "into a white sea" W (l.6929); cold grey shadow "sprang up in the East behind" (l.6929-30).
- Plan: "down the long northward slope of the hill" (l.6942), steering "for the gate-like opening at the far northward end of the long valley" (l.6949); "Once... through the gap... keep on in anything like a straight line and they were bound in the end to strike the Road" (l.6950-52).
- Frodo anticipates "the gap in the hills, the north-gate of the Barrow-downs" (l.6961); instead meets "two huge standing stones" "leaning slightly towards one another like the pillars of a headless door" (l.6966-68) — not seen from the hill in the morning, and never found again later ("he saw no sign of the great stones standing like a gate", l.7325-26). [ambig/supernatural]
- Frodo hears cries "away eastward, on his left as he stood under the great stones" (l.6984-85); goes E "steeply uphill"; at the top "facing southwards... on a round hill-top, which he must have climbed from the north. Out of the east the biting wind was blowing. To his right there loomed against the westward stars a dark black shape. A great barrow stood there" (l.7012-14). => Great barrow on a round hill-top; from a S-facing position it is on his right (W side of hilltop) [ambig].
- Inside: "he was in a barrow" (l.7032); "a kind of passage which behind them turned a corner" (l.7090); treasure laid about; "across their three necks lay one long naked sword" (l.7060-61).
- Wight incantation: "In the black wind the stars shall die... till the dark lord lifts his hand over dead sea and withered land" (l.7084-87).
- Merry's implanted memory: "The men of Carn Dûm came on us at night, and we were worsted... the spear in my heart!" (l.7185-86). => Carn Dûm attackers connected with barrow dead.
- Tom's rescue: "A low door-like opening appeared at the end of the chamber beyond Frodo's feet; and there was Tom's head... framed against the light of the sun rising red behind him" (l.7138-40) => opening toward sunrise (E) [ambig].
- Banishment: wight sent "Out into the barren lands far beyond the mountains!... Where gates stand for ever shut, till the world is mended" (l.7148-51).
- Hobbits laid "on their backs upon the grass at the west side of the mound" (l.7169-70).
- Tom fetches ponies "running away southwards along the green hollow between their hill and the next" (l.7213-14). Wind "shifted round towards the south" (l.7221-22).
- Treasure left on mound-top "free to all finders, birds, beasts, Elves or Men, and all kindly creatures"; "so the spell of the mound should be broken and scattered and no Wight ever come back to it" (l.7278-81).
- Daggers "forged many long years ago by Men of Westernesse: they were foes of the Dark Lord, but they were overcome by the evil king of Carn Dûm in the Land of Angmar" (l.7302-05). => Carn Dûm is in the Land of Angmar. "still some go wandering, sons of forgotten kings walking in loneliness, guarding from evil things folk that are heedless" (l.7306-08).
- Time: "still fairly early by the sun, something between nine and ten" (l.7270); last meal had been "lunch beside the standing stone the day before" (l.7271-72).

### Ride to the Road; the dike; Tom's border
- From barrow: down the hill, "trotted quickly along the valley"; "they turned a shoulder of the Downs" and the mound was hidden (l.7320-24). "Before long they came to the northern gap and rode swiftly through, and the land fell away before them" (l.7326-27).
- "the Road was further away than they had imagined. Even without a fog, their sleep at mid-day would have prevented them from reaching it until after nightfall on the day before" (l.7334-37). => House→Road > 1 day at their pace with mid-day sleep; distance greater than it looked.
- The dark line was "not a line of trees but a line of bushes growing on the edge of a deep dike with a steep wall on the further side. Tom said that it had once been the boundary of a kingdom, but a very long time ago" (l.7337-39,7345). => Ancient kingdom-boundary dike + wall running S of and roughly parallel to the Road [ambig on orientation].
- "They climbed down and out of the dike and through a gap in the wall, and then Tom turned due north, for they had been bearing somewhat to the west. The land was now open and fairly level" (l.7347-49).
- Reach Road at sunset: "a line of tall trees ahead... they had come back to the Road... galloped their ponies over the last furlongs" (l.7351-53). "They were on the top of a sloping bank, and the Road... wound away below them. At this point it ran nearly from South-west to North-east, and on their right it fell quickly down into a wide hollow" (l.7354-57). Road "rutted... pools and pot-holes full of water" (l.7357-59).
- Frodo: "I suppose we haven't lost more than two days by my short cut through the Forest!" (l.7361-63). **MEASUREMENT: Forest/Downs shortcut cost ≤2 days vs the Road.**
- Tom: "Out east my knowledge fails. Tom is not master of Riders from the Black Land far beyond his country" (l.7376-77).
- Tom's directions: "four miles along the Road you'll come upon a village, Bree under Bree-hill, with doors looking westward. There you'll find an old inn that is called The Prancing Pony. Barliman Butterbur is the worthy keeper" (l.7388-96). **MEASUREMENT: rejoin-point→Bree = 4 miles.**
- "Tom's country ends here: he will not pass the borders" (l.7402) — Tom's border at/near this Road point.
- Merry: "There are hobbits in Bree... My people ride out there now and again" (l.7413-15). Sam compares to "The Green Dragon away back home" (l.7411).
- Approach: "plodded slowly downhill and up again"; "Before them rose Bree-hill barring the way, a dark mass against misty stars; and under its western flank nestled a large village" (l.7423-24).

## Book I, Ch 9 — At the Sign of the Prancing Pony

### Bree-land overview (narrator)
- "Bree was the chief village of the Bree-land, a small inhabited region, like an island in the empty lands round about. Besides Bree itself, there was Staddle on the other side of the hill, Combe in a deep valley a little further eastward, and Archet on the edge of the Chetwood. Lying round Bree-hill and the villages was a small country of fields and tamed woodland only a few miles broad" (l.7431-35). **Staddle = other side of Bree-hill [from Bree]; Combe = deep valley a little further E; Archet = edge of the Chetwood; whole country only a few miles broad.**
- Bree-men "descendants of the first Men that ever wandered into the West of the middle-world" (l.7441-42); survived Elder Days; "when the Kings returned again over the Great Sea they had found the Bree-men still there" (l.7443-44).
- "In those days no other Men had settled dwellings so far west, or within a hundred leagues of the Shire" (l.7447-48). **MEASUREMENT: no other settled Men within 100 leagues of the Shire.**
- Rangers "roamed at will southwards, and eastwards even as far as the Misty Mountains; but they were now few" (l.7453-54).
- Bree-hobbits: "the oldest settlement of Hobbits in the world, one that was founded long before even the Brandywine was crossed and the Shire colonized. They lived mostly in Staddle though there were some in Bree itself, especially on the higher slopes of the hill, above the houses of the Men" (l.7459-63).
- "though their little land was not much further than a day's riding east of the Brandywine Bridge, the Hobbits of the Shire now seldom visited it" (l.7475-76). **MEASUREMENT: Bree-land ≈ a day's riding E of Brandywine Bridge.** Bree-hobbits sometimes went "as far as Buckland, or the Eastfarthing" (l.7474).
- "There was Bree-blood in the Brandybucks by all accounts" (l.7488-89).

### Village of Bree layout
- "some hundred stone houses of the Big Folk, mostly above the Road, nestling on the hillside with windows looking west" (l.7490-92).
- Defences: "On that side, running in more than half a circle from the hill and back to it, there was a deep dike with a thick hedge on the inner side. Over this the Road crossed by a causeway; but where it pierced the hedge it was barred by a great gate. There was another gate in the southern corner where the Road ran out of the village. The gates were closed at nightfall; but just inside them were small lodges for the gatekeepers" (l.7492-98). => West-gate (causeway entry) + South-gate (Road exit); dike+hedge >half-circle anchored on the hill both ends.
- Inn position: "Down on the Road, where it swept to the right to go round the foot of the hill, there was a large inn" (l.7499-7500). => Road bends (rightward, for an eastbound traveller) around the S foot of Bree-hill; inn at the bend.
- Crossroads: "Bree stood at an old meeting of ways; another ancient road crossed the East Road just outside the dike at the western end of the village" (l.7501-03). "The Northern Lands had long been desolate, and the North Road was now seldom used: it was grass-grown, and the Bree-folk called it the Greenway" (l.7508-10). => Greenway = the old North Road, crossing the East Road just W of Bree's dike.
- Saying: "Strange as News from Bree... in the Eastfarthing... when news from North, South, and East could be heard in the inn" (l.7505-07).
- Inn clientele: "travellers (mostly dwarves) as still journeyed on the East Road, to and from the Mountains" (l.7520-21). => Dwarf traffic E–W on the East Road to/from "the Mountains".
- Arrival: "came at last to the Greenway-crossing and drew near the village. They came to the West-gate and found it shut" (l.7523-24).
- The inn building: "It had a front on the Road, and two wings running back on land partly cut out of the lower slopes of the hill, so that at the rear the second-floor windows were level with the ground" (l.7583-85); "three storeys and many windows" (l.7570); wide arch to courtyard between wings; hobbit rooms "in the north wing... On the ground floor" (l.7644-46).
- Butterbur's traffic report: "a party that came up the Greenway from down South last night... a travelling company of dwarves going West come in this evening" (l.7640-43).
- Southern trouble: "There was trouble away in the South, and it seemed that the Men who had come up the Greenway were on the move, looking for lands where they could find some peace" (l.7736-39); "more and more people would be coming north" (l.7742-43).
- Shire detail: collapse of "the roof of the Town Hole in Michel Delving: Will Whitfoot, the Mayor, and the fattest hobbit in the Westfarthing" (l.7756-58).
- "several Underhills from Staddle" (l.7716-17).
- Strider described: "known round here as Strider. Goes about at a great pace on his long shanks" (l.7781-82). Bree saying: "there's no accounting for East and West... meaning the Rangers and the Shire-folk" (l.7783-84).
- Frodo's cover: "interested in history and geography"; collecting "information about hobbits living outside the Shire, especially in the eastern lands" (l.7721-25).
- (The Man-in-the-Moon inn song, l.7859-7934, is a Shire song, not Middle-earth geography; noted and skipped.)

## Book I, Ch 10 — Strider

- Strider's eavesdropping position: "I was behind the hedge this evening on the Road west of Bree, when four hobbits came out of the Downlands" (l.8087-89). => Hedge runs along Road W of Bree; the Downs region called "the Downlands".
- Riders in Bree: "Black horsemen have passed through Bree. On Monday one came down the Greenway, they say; and another appeared later, coming up the Greenway from the south" (l.8112-14). [Greenway carries N–S Rider traffic; "down" = from N, "up...from the south" = from S.]
- Strider's knowledge: "I know all the lands between the Shire and the Misty Mountains, for I have wandered over them for many years" (l.8160-61).
- "You will never get to Rivendell now on your own" (l.8203-04).
- Gandalf's letter heading: "THE PRANCING PONY, BREE. Midyear's Day, Shire Year, 1418" (l.8364). "get out of the Shire before the end of July at latest" (l.8367). "Make for Rivendell" (l.8377). Butterbur: "Three months back he walked right into my room" (l.8246). => Gandalf at Bree on Midyear's Day 1418, ~3 months before this night.
- Riders' inquiries: "they've been asking the same question all the way to Archet" (l.8290-91).
- "They come from Mordor... From Mordor, Barliman, if that means anything to you" (l.8318-19); Butterbur pales — "the worst news that has come to Bree in my time" (l.8321-22). "Against the Shadow in the East" (l.8326).
- Plan & Weathertop: "I know one or two ways out of Bree-land other than the main road. If once we shake off the pursuit, I shall make for Weathertop... It is a hill, just to the north of the Road, about half way from here to Rivendell. It commands a wide view all round... Gandalf will make for that point, if he follows us. After Weathertop our journey will become more difficult" (l.8472-80). **MEASUREMENT: Weathertop = hill just N of the Road, ~halfway Bree→Rivendell.**
- Strider–Gandalf meetings: "I came west with him in the spring... We last met on the first of May: at Sarn Ford down the Brandywine" (l.8483-87). => Sarn Ford is on/down the Brandywine. Gandalf's plan: "you would be starting for Rivendell in the last week of September" (l.8488-89).
- Rangers watch: "I have often kept watch on the borders of the Shire in the last few years" (l.8484-85); "I have been watching the East Road anxiously" (l.8498-99). News via "the Elven-folk of Gildor" (l.8496).
- Eriador named: Riders "will not openly attack a house... not while all the long leagues of Eriador still lie before us" (l.8570-72). => The Bree→Rivendell journey crosses "the long leagues of Eriador".
- Merry's stroll: Rider's shadow "seemed to make off up the Road, eastward" (l.8534); Merry followed "as far as the last house on the Road" (l.8536). Nob: "I went down to West-gate, and then back up towards South-gate. Just nigh Bill Ferny's house I thought I could see something in the Road" (l.8547-48). => Bill Ferny's house on the Road between West-gate and South-gate, nearer South-gate [ambig].
- Riders "had words with Harry at West-gate on Monday" (l.8575-76).
- Hobbit rooms: "windows looking north and close to the ground" (l.8581-82).
- Night sky: "The Sickle was swinging bright above the shoulders of Bree-hill"; footnote: "The Hobbits' name for the Plough or Great Bear" (l.8599-8600, 8607). => Great Bear seen over Bree-hill from the inn.
- Times: supper ≈ "three quarters of an hour's steady going" (Ch 9, l.7685); "ponies are ready by eight o'clock" (l.8038-39); "Breakfast at six-thirty" (l.8349); Merry "stayed indoors for an hour" (l.8525).

## Itinerary summary (this chunk)
1. Tom's house (1 full rest day: rain day of tales) — Ch 7.
2. Morning: leave house, path behind house N to hill-brow; N through Downs valleys; mid-day at saucer-rim hill with standing stone; unintended sleep till sunset; fog; night: down northward valley toward N gap; trapped at great barrow instead (Frodo climbed its hill from N). — Ch 8.
3. Next morning: rescued; breakfast between nine and ten; ride N from barrow, through the northern gap, cross old boundary dike, then due N over open level land; reach East Road at sunset (point where Road runs SW–NE); 4 miles E along Road; arrive Bree after dark (stars out). — Ch 8/9.
4. Night at The Prancing Pony; plan next morning: breakfast 6:30, ponies 8:00; intended route: leave Bree-land by byways, make for Weathertop (~halfway to Rivendell). — Ch 9/10.

## Contradictions & oddities (this chunk)
- Merry misidentifies the dike's bushes as the Road's tree-line: "That is a line of trees... must mark the Road" (Ch 8) vs "not a line of trees but a line of bushes... a deep dike" (Ch 8). The real Road lay further N than the hilltop view suggested.
- Tom's "strike the East Road in a day's journey" (Ch 7) vs narrator: even fog aside, mid-day sleep "would have prevented them from reaching it until after nightfall on the day before" (Ch 8) — a day's journey is tight/optimistic at pony pace with stops.
- The two "headless door" standing stones at the (false) gap: unseen from above in the morning, unfindable afterwards (Ch 8) — a geographic feature that appears/disappears [supernatural/ambig].
- Frodo atop the barrow-hill faces S with the barrow "to his right" against "the westward stars", yet Tom later lays the hobbits "at the west side of the mound" and the door opening faces the sunrise — internally consistent but directions are viewer-relative and dreamlike [ambig].
- Weathertop "about half way from here to Rivendell" (Ch 10) — key ratio for any map; compare with mileages stated elsewhere (other chunks).

## World-structure statements (this chunk)
- "times when the world was wider, and the seas flowed straight to the western Shore" (Ch 7, l.6638-39).
- Tom: "When the Elves passed westward, Tom was here already, before the seas were bent" (Ch 7, l.6660-61). "before the Dark Lord came from Outside" (l.6662-63).
- Goldberry's rain-song: river "from the spring in the highlands to the Sea far below" (Ch 7).
- Bree-men "the first Men that ever wandered into the West of the middle-world"; "the Kings returned again over the Great Sea" (Ch 9).
- Blades of "Men of Westernesse"; enemy "the evil king of Carn Dûm in the Land of Angmar" (Ch 8).
- Wight-song: "over dead sea and withered land" (Ch 8).
- Wight banished "far beyond the mountains... Where gates stand for ever shut, till the world is mended" (Ch 8).
- "Riders from the Black Land far beyond his country" (Ch 8); "They come from Mordor"; "the Shadow in the East" (Ch 10).
- The Sickle = Hobbit name for Plough/Great Bear (Ch 10 footnote).
