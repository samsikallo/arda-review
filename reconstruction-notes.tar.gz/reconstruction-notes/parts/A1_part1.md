# Part 1 notes — Prologue; Book I Ch 1 "A Long-expected Party"; Book I Ch 2 "The Shadow of the Past"
Source: C_lotr.txt lines 918–3633. All quotes verbatim; line numbers from file.

## PROLOGUE §1 Concerning Hobbits

### Peoples, sizes
- Hobbit height: "ranging between two and four feet of our measure" (954); "They seldom now reach three feet" (960). Bandobras Took "was four foot five and able to ride a horse" (962–963).
- Hobbit lands then = now: "the North-West of the Old World, east of the Sea" (999). "the shape of all lands has been changed" since the Third Age (997).

### Migrations (geographic sequence)
- Earliest known home: "they dwelt in the upper vales of Anduin, between the eaves of Greenwood the Great and the Misty Mountains" (1015–1016).
- They "moved westward" and made a "crossing of the mountains into Eriador" (1017–1018). Reason: multiplying of Men, and "a shadow that fell on the forest, so that it became darkened and its new name was Mirkwood" (1019–1020).
- Three breeds and terrain preferences: Harfoots "preferred highlands and hillsides" (1025); Stoors "preferred flat lands and riversides" (1027); Fallohides "lovers of trees and of woodlands" (1029).
- Harfoots: "long lived in the foothills of the mountains. They moved westward early, and roamed over Eriador as far as Weathertop while the others were still in Wilderland" (1030–1033).
- Stoors: "lingered long by the banks of the Great River Anduin"; "came west after the Harfoots and followed the course of the Loudwater southwards; and there many of them long dwelt between Tharbad and the borders of Dunland before they moved north again" (1036–1040). → Loudwater flows toward Tharbad/Dunland region (southwards course followable from a Misty Mountains crossing).
- Fallohides: "a northerly branch"; "They crossed the mountains north of Rivendell and came down the River Hoarwell" (1041–1045). → Hoarwell rises in/beyond mountains north of Rivendell; is descendible into Eriador.
- Eriador's extent: "the westlands of Eriador, between the Misty Mountains and the Mountains of Lune" (1056–1057). Dúnedain remnant there; "the lands of their North Kingdom were falling far and wide into waste" (1059–1060).

### Bree
- "one of the first [settlements] to become important still endured... this was at Bree and in the Chetwood that lay round about, some forty miles east of the Shire" (1063–1065). MEASUREMENT: Bree ~40 miles east of the Shire.

### Westron's range
- Common Speech "current through all the lands of the kings from Arnor to Gondor, and about all the coasts of the Sea from Belfalas to Lune" (1070–1072).

### Founding of the Shire
- T.A. 1601: Fallohide brothers Marcho and Blanco "set out from Bree; and having obtained permission from the high king at Fornost,* they crossed the brown river Baranduin with a great following of Hobbits" (1078–1081). Footnote: king was Argeleb II; the Northern line "came to an end with Arvedui three hundred years later" (1094–1095).
- "They passed over the Bridge of Stonebows, that had been built in the days of the power of the North Kingdom" (1081–1083).
- Land taken: "all the land beyond to dwell in, between the river and the Far Downs" (1083–1084). Conditions: "keep the Great Bridge in repair, and all other bridges and roads, speed the king's messengers" (1085–1086).
- Shire-reckoning Year One = "the year of the crossing of the Brandywine (as the Hobbits turned the name)" (1088–1089). Add 1600 to S.R. for T.A. dates (1096–1097).
- Hobbit bowmen sent to "the last battle at Fornost with the Witch-lord of Angmar... in that war the North Kingdom ended" (1104–1107).
- Land previously: "long been deserted... it had before been well tilled, and there the king had once had many farms, cornlands, vineyards, and woods" (1115–1118).

### SHIRE DIMENSIONS (key)
- "Forty leagues it stretched from the Far Downs to the Brandywine Bridge, and fifty from the northern moors to the marshes in the south." (1119–1120). → E–W 40 leagues (Far Downs↔Brandywine Bridge); N–S 50 leagues (northern moors↔southern marshes).

### Shire interior, climate, sites
- Battle of Greenfields, S.R. 1147, "the only one that had ever been fought within the borders of the Shire" (1134–1136).
- Climate: "Even the weathers had grown milder, and the wolves that had once come ravening out of the North in bitter white winters were now only a grandfather's tale" (1137–1139).
- "the museum at Michel Delving. The Mathom-house it was called" (1141–1142).
- Dwellings: smials in hills; "in the flats and the low-lying districts... began to build above ground" (1172–1173); "hilly regions and the older villages, such as Hobbiton or Tuckborough, or in the chief township of the Shire, Michel Delving on the White Downs" (1173–1175). → Michel Delving on White Downs = chief township.
- Marish: farmhouse-building "began among the inhabitants of the Marish down by the Brandywine. The Hobbits of that quarter, the Eastfarthing..." (1180–1182). Stoor blood there.
- "the folk of the Marish, and of Buckland, east of the River, which they afterwards occupied, came for the most part later into the Shire up from south-away" (1185–1187). → Buckland east of the Brandywine, occupied after the Marish.
- Elves: "they dwelt still at that time at the Grey Havens away to the west, and in other places within reach of the Shire" (1198–1200).
- "Three Elf-towers of immemorial age were still to be seen on the Tower Hills beyond the western marches. They shone far off in the moonlight. The tallest was furthest away, standing alone upon a green mound." (1200–1203).
- "The Hobbits of the Westfarthing said that one could see the Sea from the top of that tower; but no Hobbit had ever been known to climb it." (1203–1205).
- Sea-fear: "the Sea became a word of fear among them... they turned their faces away from the hills in the west" (1211–1213).
- Great family mansions: "the Tooks of Great Smials, or the Brandybucks of Brandy Hall" (1227).

## PROLOGUE §2 Concerning Pipe-weed
- Origin: "Tobold Hornblower of Longbottom in the Southfarthing first grew the true pipe-weed in his gardens... about the year 1070 of Shire-reckoning" (1260–1262). Varieties: Longbottom Leaf, Old Toby, Southern Star.
- Old Toby "went often to Bree... he certainly never went further from the Shire than that" (1267–1268).
- At Bree pipe-weed "grows well on the south slopes of the hill" (1269–1270). → Bree-hill has south slopes with cultivation.
- Bree = "that ancient road-meeting" (1277); "the old inn of Bree, The Prancing Pony... kept by the family of Butterbur" (1278–1279).
- Plant "not native to our parts of the world, but came northward from the lower Anduin, whither it was... originally brought over Sea by the Men of Westernesse" (1282–1284). "It grows abundantly in Gondor... in the North... flourishes only in warm sheltered places like Longbottom" (1285–1292). Climate note.
- "From that land it must have been carried up the Greenway during the long centuries" (1294–1295). → Greenway is the route from Gondor-ward lands north to Bree.

## PROLOGUE §3 Of the Ordering of the Shire
- "The Shire was divided into four quarters, the Farthings... North, South, East, and West" (1303–1304). Folklands within them; "Nearly all Tooks still lived in the Tookland" (1307–1308).
- "Outside the Farthings were the East and West Marches: the Buckland (p. 98); and the Westmarch added to the Shire in S.R. 1452" (1310–1311).
- "the high king at Fornost, or Norbury as they called it, away north of the Shire... even the ruins of Kings' Norbury were covered with grass" (1319–1321). → Fornost=Norbury, ruined, north of Shire.
- Mayor of Michel Delving "elected every seven years at the Free Fair on the White Downs at the Lithe, that is at Midsummer" (1346–1347).
- Shirriffs: "There were in all the Shire only twelve of them, three in each Farthing" (1361). Bounders "beat the bounds" (1363); at story's opening Bounders "greatly increased"; "many reports and complaints of strange persons and creatures prowling about the borders, or over them" (1366–1368).

## PROLOGUE §4 Of the Finding of the Ring
- Bilbo's quest destination: "the dwarf-hoards of the Kings under the Mountain, beneath Erebor in Dale, far off in the East" (1389–1391). [Note phrasing "beneath Erebor in Dale".]
- "The party was assailed by Orcs in a high pass of the Misty Mountains as they went towards Wilderland" (1396–1398).
- Bilbo "was lost for a while in the black orc-mines deep under the mountains"; found the ring "on the floor of a tunnel"; "went on down to the roots of the mountains"; "At the bottom of the tunnel lay a cold lake far from the light, and on an island of rock in the water lived Gollum" (1398–1405). Gollum's ring kept "in a hole on his island" (1413).
- Exit: "an unseen opening that led to the lower gates of the mines, on the eastward side of the mountains" (1461–1462). → Goblin-mines exit on E side of Misty Mountains.
- Bilbo "returned to his home at Bag End on June the 22nd in his fifty-second year (S.R. 1342)" (1517–1518); party S.R. 1401.

## PROLOGUE — Note on the Shire Records
- Libraries: "The largest of these collections were probably at Undertowers, at Great Smials, and at Brandy Hall" (1538–1539).
- Red Book "long preserved at Undertowers, the home of the Fairbairns, Wardens of the Westmarch" (1542–1543).
- Thain's Book "in Minas Tirith"; copy by Findegil finished IV 172; Peregrin "retired to Gondor in IV 64" (1559–1562).
- "the libraries at Bucklebury and Tuckborough" (1586). Brandy Hall works dealt "with Eriador and the history of Rohan" (1588).
- Rivendell after the War: "though Elrond had departed, his sons long remained... It is said that Celeborn went to dwell there after the departure of Galadriel" before at last seeking the Grey Havens (1607–1618).

## BOOK I Ch 1 — A Long-expected Party
- Setting: Hobbiton; Bag End on the Hill. Popular belief "the Hill at Bag End was full of tunnels stuffed with treasure" (1642–1643).
- The Ivy Bush, "a small inn on the Bywater road" (1683–1684); Gaffer held forth there. Gaffer & Sam "lived on the Hill itself, in Number 3 Bagshot Row just below Bag End" (1689–1690).
- Buckland from Hobbiton viewpoint: "away there in Buckland" (1699); Bucklanders "live on the wrong side of the Brandywine River, and right agin the Old Forest. That's a dark bad place" (1701–1703). "They fool about with boats on that big river" (1705). Drogo & Primula drowned boating on the Brandywine (1727–1729); Frodo raised at Brandy Hall — "Old Master Gorbadoc never had fewer than a couple of hundred relations in the place" (1740–1741).
- "a stranger, a visitor on business from Michel Delving in the Westfarthing" (1752–1753).
- Gandalf's cart "came in through Bywater from the direction of Brandywine Bridge in broad daylight... right up the hill" (1806, 1815). → Road from Brandywine Bridge passes through Bywater then up the Hill to Bag End.
- Bag End interior orientation: Bilbo & Gandalf "at the open window of a small room looking out west on to the garden" (1837–1838). → garden west of the smial.
- Party field: "the large field, south of Bilbo's front door" (1878–1879); "A special entrance was cut into the bank leading to the road" (1879–1880); Bagshot Row "adjoining the field" (1881); kitchen "in the north corner of the field" (1888).
- Party date: Thursday, September the 22nd (1893–1894).
- Dwarf-made toys "had come all the way from the Mountain and from Dale" (1917–1918); crackers "bore the mark dale" (2023).
- Firework spears "came down again into the Water" (1942); dragon firework "burst over Bywater" (1956). → The Water and Bywater below/near the Hill.
- Bilbo: anniversary "of my arrival by barrel at Esgaroth on the Long Lake" (2064–2065) — on his birthday, Sept 22.
- Guests: 144; "some... lived in remote corners of the Shire" (1973–1974).
- Bilbo's exit route: "went round into his garden, and trotted down the long sloping path. He jumped over a low place in the hedge at the bottom, and took to the meadows" (2334–2337). Direction not stated here.
- Old Winyards: "a strong red wine from the Southfarthing" (2431–2432).
- Lobelia "driving a pony-trap towards Bywater" from Bag End (2520).

## BOOK I Ch 2 — The Shadow of the Past
- Frodo: "Perhaps I shall cross the River myself one day" [ambig: which river — Brandywine implied] (2639).
- Shire cartography: "maps made in the Shire showed mostly white spaces beyond its borders" (2645–2646).
- Elves "passing westward through the woods in the evening... they were leaving Middle-earth" (2654–2656).
- KEY ROAD: "The ancient East–West Road ran through the Shire to its end at the Grey Havens, and dwarves had always used it on their way to their mines in the Blue Mountains." (2658–2660). → E–W Road terminates at Grey Havens; dwarf-mines in Blue Mountains reached along it.
- Mordor rumours: "the evil power in Mirkwood had been driven out by the White Council only to reappear in greater strength in the old strongholds of Mordor. The Dark Tower had been rebuilt" (2673–2675); "away far east and south there were wars and growing fear" (2676–2677); "Orcs were multiplying again in the mountains" (2677–2678).
- The Green Dragon inn "at Bywater" (2685); talk in spring of Frodo's fiftieth year.
- Northfarthing: tree-man "seen up away beyond the North Moors" (2702); Hal "works for Mr. Boffin at Overhill and goes up to the Northfarthing for the hunting" (2705–2706); walker "seven yards to a stride" (2710); "there ain't no elm tree on the North Moors" (2718–2719). → Overhill near Hobbiton; North Moors on Northfarthing's edge.
- To the Sea: Elves "going to the harbours, out away beyond the White Towers... neither he nor any of them knew how far it was to the Sea, past the old towers beyond the western borders of the Shire. But it was an old tradition that away over there stood the Grey Havens, from which at times elven-ships set sail, never to return" (2726–2731).
- Sam: "They are sailing... over the Sea, they are going into the West and leaving us" (2732–2733).
- Ring history (spatial): "In Eregion long ago many Elven-rings were made" (2813). Ring-verse: "One for the Dark Lord on his dark throne / In the Land of Mordor where the Shadows lie" (2980–2981).
- Sauron: "has indeed arisen again and left his hold in Mirkwood and returned to his ancient fastness in the Dark Tower of Mordor" (3003–3005).
- Isildur's loss: "It fell into the Great River, Anduin, and vanished. For Isildur was marching north along the east banks of the River, and near the Gladden Fields he was waylaid by the Orcs of the Mountains" (3066–3069). He leaped into the waters; killed with arrows. "there in the dark pools amid the Gladden Fields... the Ring passed out of knowledge" (3072–3073).
- Sméagol's people: "there lived by the banks of the Great River on the edge of Wilderland a clever-handed and quiet-footed little people... akin to the fathers of the fathers of the Stoors, for they loved the River" (3077–3080). Matriarchal family in a "hole" (3135).
- Déagol's find: "they took a boat and went down to the Gladden Fields, where there were great beds of iris and flowering reeds" (3095–3096). Ring found on the river-bed there. [Implies their home was upstream/above the Gladden Fields on Anduin.]
- Gollum's route into the mountains: "he journeyed up the River, till he came to a stream that flowed down from the mountains, and he went that way" (3137–3138); "he saw far ahead the tops of the Misty Mountains, out of which the stream came" (3145–3146); "journeyed by night up into the highlands, and he found a little cave out of which the dark stream ran; and he wormed his way... into the heart of the hills" (3151–3153).
- Gollum's later travels: left the mountains "After a year or two"; "He found his way into Mirkwood" (3308); "his padding feet had taken him at last to Esgaroth, and even to the streets of Dale, listening secretly and peering" (3318–3319); "We had made no secret of our return journey to his home in the West" (3326–3327); "He set out and came back westward, as far as the Great River. But then he turned aside" (3331–3333); "at the western edge of Mirkwood the trail turned away. It wandered off southwards and passed out of the Wood-elves' ken" (3343–3344); finally "he had made his slow, sneaking way, step by step, mile by mile, south, down at last to the Land of Mordor" (3362–3364).
- Gandalf & Aragorn "sought for Gollum down the whole length of Wilderland" (3353–3354). Wood-elves now hold Gollum "in prison" (3424–3425).
- "all folk were whispering then of the new Shadow in the South, and its hatred of the West" (3376–3377).
- Ring destruction: "There is only one way: to find the Cracks of Doom in the depths of Orodruin, the Fire-mountain, and cast the Ring in there" (3483–3485). Also called "the Fiery Mountain" (3521).
- Shire guarded: "there has never been a day when the Shire has not been guarded by watchful eyes" (3440–3441).
- Time markers: Gandalf away 3 years after Party, then visits, then absent over 9 years (2767–2776); returns early April (2755), talk next morning; Frodo's 50th year.

## Numerics collected (Part 1)
1. Hobbit height "between two and four feet"; "seldom now reach three feet"; Bandobras "four foot five" (Prologue §1).
2. Bree "some forty miles east of the Shire" (Prologue §1, 1065).
3. Shire: "Forty leagues... from the Far Downs to the Brandywine Bridge, and fifty from the northern moors to the marshes in the south" (Prologue §1, 1119–1120).
4. T.A. 1601 = S.R. 1 crossing of Brandywine; "adding 1600" converts (Prologue §1).
5. Fornost kings ended "three hundred years later" after Argeleb II (footnote, 1095).
6. Battle of Greenfields S.R. 1147; Days of Dearth 1158–60; Long Winter famine "Many thousands then perished" (Prologue §1).
7. Pipe-weed first grown "about the year 1070 of Shire-reckoning" (Prologue §2).
8. Westmarch added S.R. 1452 (Prologue §3).
9. Twelve Shirriffs, three per Farthing (Prologue §3).
10. Bilbo's return June 22, S.R. 1342; quest began April S.R. 1341 (Prologue §4).
11. Tree-man "seven yards to a stride"; "as big as an elm tree" (Ch 2).
12. Bree-Chetwood settlement "some forty miles east of the Shire" — same as #2.
13. Gandalf absent "over nine years"; away "three years after the Party" (Ch 2).
14. Sept 22 birthday; party year S.R. 1401 (Prologue §4/Ch 1).
