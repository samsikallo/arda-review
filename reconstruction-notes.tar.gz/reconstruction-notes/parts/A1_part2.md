# A1 Part 2 — Book I, Chapters 3–6 (lines 3634–6269)
Chapters covered: "Three is Company" (Ch 3), "A Short Cut to Mushrooms" (Ch 4), "A Conspiracy Unmasked" (Ch 5), "The Old Forest" (Ch 6). All quotes verbatim from file; no outside knowledge. [ambig] marks uncertainty.

## CHAPTER 3 — THREE IS COMPANY

### Destinations and general orientation
- Gandalf's advice: "If you want my advice, make for Rivendell." Frodo: "I will go east, and I will make for Rivendell." Rivendell = "the house of Elrond Halfelven... that deep valley where many of the Fair Folk still dwelt in peace."
- Directions from the Shire framed as compass set: "you must go, or at least set out, either North, South, West or East".
- Frodo buys "a little house at Crickhollow in the country beyond Bucklebury." — Crickhollow beyond Bucklebury.
- "Buckland was on the eastern borders of the Shire" — Frodo lived there in childhood.
- Gandalf (end of June): "I am going down beyond the southern borders to get some news" — implies news-worthy lands south of the Shire.
- Sam's geographic horizon: "Sam knew the land well within twenty miles of Hobbiton, but that was the limit of his geography." [MEASUREMENT: 20 miles]
- Southfarthing: "Down in the Southfarthing they have had trouble with Big People."
- Gaffer on Bucklebury (from Hobbiton): "He's moved to Bucklebury or some such place, away down yonder... a tidy way. I've never been so far myself; they're queer folks in Buckland."
- Frodo: "Can't a hobbit walk from the Water to the River in peace?" — the Water (Hobbiton stream) to the River (Brandywine) as a natural west–east traverse of this part of the Shire.
- Elves in the Shire: "One can meet them sometimes in the Woody End. They don't live in the Shire, but they wander into it in spring and autumn, out of their own lands away beyond the Tower Hills." — Elf-lands beyond (west of) the Tower Hills.
- High Elves: "Not many now remain in Middle-earth, east of the Great Sea." Gildor: "we are... only tarrying here a while, ere we return over the Great Sea. But some of our kinsfolk dwell still in peace in Rivendell."
- Bilbo's Road saying (Bag End doorstep): "this is the very path that goes through Mirkwood, and that if you let it, it might take you to the Lonely Mountain or even further" — the East Road as one continuous way from Bag End through Mirkwood to the Lonely Mountain [reported saying].
- The Road metaphor: "there was only one Road; that it was like a great river: its springs were at every doorstep, and every path was its tributary."

### Dates and timing (departure)
- Frodo planned to leave "on his fiftieth birthday: Bilbo's one hundred and twenty-eighth" (autumn, "on or after Our Birthday").
- "On September 20th two covered carts went off laden to Buckland... by way of the Brandywine Bridge." — furniture route = East Road over Brandywine Bridge.
- "Thursday, his birthday morning" — birthday is a Thursday; farewell dinner that evening.
- Next morning (Sept 23): third cart with Merry and Fatty Bolger off after breakfast (they drive to Crickhollow); Pippin stays. Frodo waits until nightfall, departs on foot at dusk.
- Merry on leaving: "see you later – the day after tomorrow" and later "Merry expects us some time the day after tomorrow; but that leaves us nearly two days more" (said near midnight of first night). Walk planned as ~2.5 days Hobbiton→Bucklebury Ferry.
- Climate: "The Shire had seldom seen so fair a summer, or so rich an autumn"; first night "clear, cool, and starry", wind in the West; day 2 "nearly as hot as it had been the day before" but clouds from the West, turning to rain (day 2 rain showers).

### Route leg 1: Bag End to first camp (night 1)
- Plan: "to walk from Hobbiton to Bucklebury Ferry, taking it fairly easy."
- Exit from Bag End: down the garden-path on the west side, "jumped over the low place in the hedge at the bottom and took to the fields"; "At the bottom of the Hill on its western side they came to the gate opening on to a narrow lane." (Bag End on the Hill; Hill Road runs down; Bagshot Row nearby with the Gamgees; gate in the lane beyond the meadows; they avoid the village.)
- "For a short way they followed the lane westwards. Then leaving it they turned left and took quietly to the fields" — westwards then south.
- "After some time they crossed the Water, west of Hobbiton, by a narrow plank-bridge. The stream was there no more than a winding black ribbon, bordered with leaning alder-trees." — the Water crossable by plank-bridge west of Hobbiton; small stream there.
- "A mile or two further south they hastily crossed the great road from the Brandywine Bridge; they were now in the Tookland and bending south-eastwards they made for the Green Hill Country." [MEASUREMENT: 1–2 miles from the Water crossing to the East Road; East Road = "the great road from the Brandywine Bridge"; Tookland south of East Road here; course SE to Green Hill Country.]
- Looking back from first slopes: "the lamps in Hobbiton far off twinkling in the gentle valley of the Water... followed by Bywater beside its grey pool." — Hobbiton and Bywater in the Water valley; Bywater by a grey pool.
- "When they had walked for about three hours they rested." [MEASUREMENT: ~3 hours]
- "Soon they struck a narrow road... : the road to Woodhall, and Stock, and the Bucklebury Ferry. It climbed away from the main road in the Water-valley, and wound over the skirts of the Green Hills towards Woody End, a wild corner of the Eastfarthing." — KEY: a narrow secondary road leaves the East Road (main road in the Water-valley) and runs via the Green Hills' skirts to Woody End, serving Woodhall, Stock, Bucklebury Ferry. Woody End is in the Eastfarthing.
- "deeply cloven track between tall trees"; "began to climb a steep slope"; Pippin: "It is nearly midnight."
- Camp: "Just over the top of the hill they came on the patch of fir-wood" — dry fir-wood camp; "they were still in the heart of the Shire."

### Route leg 2: camp to Woodhall (day/night 2)
- Morning view east: "Away eastward the sun was rising red out of the mists... A little below him to the left the road ran down steeply into a hollow."
- Water source: "There was a stream at the foot of the hill... a little fall where the water fell a few feet over an outcrop of grey stone. It was icy cold." [MEASUREMENT: fall of a few feet]
- Start "after ten o'clock"; "They went down the slope, and across the stream where it dived under the road, and up the next slope, and up and down another shoulder of the hills."
- "After some miles... the road ceased to roll up and down: it climbed to the top of a steep bank in a weary zig-zagging sort of way, and then prepared to go down for the last time... They were looking across the Woody End towards the Brandywine River. The road wound away before them like a piece of string." — from a high bank one sees across Woody End to the Brandywine; beyond the haze "lay the River, and the end of the Shire."
- Road quality: "This way was not much used, being hardly fit for carts, and there was little traffic to the Woody End."
- After lunch+rest, "jogging along again for an hour or more... now on level ground, and the road after much winding lay straight ahead through grass-land sprinkled with tall trees, outliers of the approaching woods." First Black Rider encounter here (rider sniffs; goes on; seems to turn aside into trees on the right).
- They then keep "a stone's throw to the left of the road", ground tussocky/uneven, trees thickening; "The sun had gone down red behind the hills at their backs" (hills to their west).
- KEY JUNCTION: "they came back to the road at the end of the long level over which it had run straight for some miles. At that point it bent left and went down into the lowlands of the Yale making for Stock; but a lane branched right, winding through a wood of ancient oak-trees on its way to Woodhall." — the Stock road bends left (down into the Yale lowlands, toward Stock); a right-branching lane goes to Woodhall through old oaks.
- Hollow tree refuge near the road-meeting; twilight descent: "Soon the road began to fall gently but steadily into the dusk. A star came out above the trees in the darkening East before them" (lane trends east/down).
- Second Black Rider encounter on the Woodhall lane (crawling shadow, driven off by approaching Elf-song).
- Elves' course: "Before long the Elves came down the lane towards the valley."
- Gildor's plan: "For tonight we go to the woods on the hills above Woodhall. It is some miles." [MEASUREMENT: "some miles" from encounter point to hall]
- The elven hall site: lane "went lower, running down into a fold of the hills... many deep brakes of hazel on the rising slopes"; Elves turn right off the lane up "a green ride... on to the top of a shoulder of the hills that stood out into the lower land of the river-valley"; "a wide space of grass... On three sides the woods pressed upon it; but eastward the ground fell steeply... Beyond, the low lands lay dim and flat under the stars. Nearer at hand a few lights twinkled in the village of Woodhall." — Woodhall village at the foot, hall on a hill-shoulder above it, open view east over flats; "the greensward" with tree-pillared "hall" at its south end.
- Night sky: "Away high in the East swung Remmirath, the Netted Stars... red Borgil rose... the Swordsman of the Sky, Menelvagor with his shining belt."

## CHAPTER 4 — A SHORT CUT TO MUSHROOMS

### The short-cut geometry (Woodhall to Bucklebury Ferry)
- Frodo's statement (KEY): "The Ferry is east from Woodhall; but the hard road curves away to the left – you can see a bend of it away north over there. It goes round the north end of the Marish so as to strike the causeway from the Bridge above Stock. But that is miles out of the way. We could save a quarter of the distance if we made a line for the Ferry from where we stand." — Ferry due east of Woodhall; road loops north around the Marish's north end; a causeway runs from the Bridge southwards through/above Stock; cutting straight saves ~¼ of the distance.
- [MEASUREMENT] "Frodo reckoned they had eighteen miles to go in a straight line" (Woodhall area → Ferry).
- Pippin's terrain warning: "The country is rough round here, and there are bogs and all kinds of difficulties down in the Marish."
- Golden Perch inn: Pippin "had counted on passing the Golden Perch at Stock before sundown. The best beer in the Eastfarthing." — inn at Stock.
- Course chosen: "to leave Woodhall to their left, and to cut slanting through the woods that clustered along the eastern side of the hills, until they reached the flats beyond. Then they could make straight for the Ferry over country that was open, except for a few ditches and fences."
- Weather: hot again, clouds from the West, heavy rain mid-morning, clearing past mid-day.

### Stock-brook and the wooded belt
- Descending "a steep green bank" into tangled thicket, they hit "a stream running down from the hills behind in a deeply dug bed with steep slippery sides overhung with brambles" — Black Rider seen above on the bank edge behind them (horse + stooped black figure against the sky).
- Downstream "the banks of the stream sank, as it reached the levels and became broader and shallower, wandering off towards the Marish and the River." Pippin: "Why, this is the Stock-brook!" They wade it and bear right.
- Beyond: "a wide open space, rush-grown and treeless"; then "a belt of trees: tall oaks, for the most part, with here and there an elm tree or an ash"; ground fairly level. Pippin: "It is not a very broad belt – I should have said no more than a mile at the widest." [MEASUREMENT: belt ≤1 mile wide]
- "They went on for perhaps another couple of miles" after a half-hour in the belt. [MEASUREMENT]
- A long-drawn wail and answering cry heard (Rider signals) — "fainter and further off".
- Emerging: "Wide grass-lands stretched before them. They now saw that they had, in fact, turned too much to the south. Away over the flats they could glimpse the low hill of Bucklebury across the River, but it was now to their left." — Bucklebury on a low hill east of the Brandywine, NE of their position.
- Land becomes "tame and well-ordered... well-tended fields and meadows: there were hedges and gates and dikes for drainage" as the River line nears.

### Bamfurlong / Farmer Maggot
- "This is Bamfurlong, old Farmer Maggot's land. That's his farm away there in the trees." Reached via "a stout gate" and "a rutted lane... between low well-laid hedges towards a distant clump of trees."
- Marish building culture: "The Maggots, and the Puddifoots of Stock, and most of the inhabitants of the Marish, were house-dwellers; and this farm was stoutly built of brick and had a high wall all round it." Wide wooden gate from wall into lane.
- Border position: "folk down here are near the border"; Maggot: "we do get queer folk wandering in these parts at times. Too near the River."; "We don't see many of the Big Folk over the border."
- Black Rider at Maggot's: came "in at the gate... right up to my door"; said "I come from yonder... pointing back west, over my fields"; Maggot: "You're in the wrong part of the Shire. You had better go back west to Hobbiton"; Maggot to rider: "This lane don't lead anywhere" [i.e. dead-ends at the farm]; rider left "through the gate and up the lane towards the causeway."
- Frodo's childhood: raised at Brandy Hall; Maggot's dogs once "chased me all the way to the Ferry" (Bamfurlong within dog-chase of the Ferry); "I've been in terror of you and your dogs for over thirty years."

### Maggot's lane to the Ferry (waggon, night)
- "After a mile or two the lane came to an end, crossing a deep dike, and climbing a short slope up on to the high-banked causeway." [MEASUREMENT: lane 1–2 miles; causeway is high-banked, crossing dikes; Maggot looks "either way, north and south" along it — causeway runs N–S]
- River-mist: "Thin strands of river-mist were hanging above the dikes, and crawling over the fields."
- [MEASUREMENT] "It was five miles or more from Maggot's lane to the Ferry." (along the causeway, northward [ambig: direction inferred from geometry — Ferry entrance appears "on their right"])
- Ferry lane entrance "marked by two tall white posts" opening on their right off the causeway.
- Merry had ferried across and "rode up towards Stock" looking for them — confirms causeway continues toward Stock north of the Ferry lane.

## CHAPTER 5 — A CONSPIRACY UNMASKED

### Bucklebury Ferry and the Brandywine
- Ferry lane: "straight and well-kept and edged with large white-washed stones. In a hundred yards or so it brought them to the river-bank, where there was a broad wooden landing-stage. A large flat ferry-boat was moored beside it." [MEASUREMENT: lane ~100 yards] White bollards, two lamps on high posts.
- Crossing: pole-pushed ferry; "The Brandywine flowed slow and broad before them. On the other side the bank was steep, and up it a winding path climbed from the further landing." — west bank flat/fields+dikes; east bank steep.
- "Behind loomed up the Buck Hill; and out of it... shone many round windows... the windows of Brandy Hall, the ancient home of the Brandybucks." — Brandy Hall dug into Buck Hill directly above the east landing.
- Boats: "Thank goodness you don't keep any boats on the west-bank!" — no boats kept on west bank.
- Horses crossing: "They can go ten miles north to Brandywine Bridge – or they might swim... Though I never heard of any horse swimming the Brandywine." [MEASUREMENT: Ferry→Brandywine Bridge = 10 miles, Bridge north of Ferry]
- A Black Rider seen left behind on the far (west) stage after they cross.

### Buckland — origin, layout, the High Hay
- "Gorhendad Oldbuck... had crossed the river, which was the original boundary of the land eastwards. He built (and excavated) Brandy Hall... master of what was virtually a small independent country." — Brandywine = original eastern boundary of the Shire.
- Brandy Hall: "occupied the whole of the low hill, and had three large front-doors, many side-doors, and about a hundred windows." [MEASUREMENT: ~100 windows, 3 front-doors]
- "That was the origin of Buckland, a thickly inhabited strip between the river and the Old Forest, a sort of colony from the Shire. Its chief village was Bucklebury, clustering in the banks and slopes behind Brandy Hall."
- Marish links: "The people in the Marish were friendly with the Bucklanders, and the authority of the Master of the Hall... was still acknowledged by the farmers between Stock and Rushey." — Stock and Rushey bracket the Marish farmlands (west bank).
- Bucklanders "fond of boats, and some of them could swim" (unique among hobbits of "the Four Farthings").
- THE HEDGE (KEY): "Their land was originally unprotected from the East; but on that side they had built a hedge: the High Hay... It ran all the way from Brandywine Bridge, in a big loop curving away from the river, to Haysend (where the Withywindle flowed out of the Forest into the Brandywine): well over twenty miles from end to end." [MEASUREMENT: Hedge >20 miles, Bridge→Haysend; Withywindle mouth at Haysend; Old Forest east of Buckland] "The Forest drew close to the hedge in many places." Bucklanders lock doors after dark.
- North-gate: Riders "could have reached here by now... if they were not stopped at the North-gate, where the Hedge runs down to the river-bank, just this side of the Bridge. The gate-guards would not let them through by night." — gated northern entry of Buckland just south of Brandywine Bridge; Buckland Gate has guards.
- Frodo: "the Bridge and the East Road near the borders will certainly be watched" — East Road passes the Bridge at the borders.

### Ferry to Crickhollow
- "It was some distance from the Brandywine to Frodo's new house at Crickhollow. They passed Buck Hill and Brandy Hall on their left, and on the outskirts of Bucklebury struck the main road of Buckland that ran south from the Bridge. Half a mile northward along this they came to a lane opening on their right. This they followed for a couple of miles as it climbed up and down into the country." [MEASUREMENTS: ½ mile north along Buckland's main road; then ~2 miles NE-ish up a right-hand lane (right = east side). Main Buckland road runs south from the Bridge.]
- Crickhollow house: "a narrow gate in a thick hedge... it stood back from the lane in the middle of a wide circle of lawn surrounded by a belt of low trees inside the outer hedge... in an out-of-the-way corner of the country... no other dwellings close by... built a long while before by the Brandybucks... long and low, with no upper storey; a roof of turf, round windows, and a large round door."
- Merry & Fatty "only got here with the last cart-load yesterday."
- Logistics: "we could get off in an hour... There are five ponies in a stable across the fields."
- Pippin: "chased for two days by Black Riders" (summary of the walk).
- Fatty Bolger: "His family came from the Eastfarthing, from Budgeford in Bridgefields in fact, but he had never been over the Brandywine Bridge." — Budgeford in Bridgefields, Eastfarthing.
- Old Forest knowledge: Maggot "used to go into the Old Forest at one time"; Brandybucks "have a private entrance. Frodo went in once, long ago."
- Escape logic: going by the North-gate would be seen; "The only thing to do is to go off in a quite unexpected direction" = the Old Forest. Plan: "Tell Gandalf to hurry along the East Road: we shall soon be back on it" (Ch 6).
- Frodo's dream (vision, not waking geography): "the sound of the Sea far-off"; "a dark heath... a strange salt smell"; "a tall white tower, standing alone on a high ridge" with desire to climb it and see the Sea. [dream]

## CHAPTER 6 — THE OLD FOREST

### Crickhollow to the Hedge tunnel
- Wake "half past four and very foggy"; "Soon after six o'clock the five hobbits were ready to start." Route: "a path that went through a spinney behind the house, and then cut across several fields." Ponies: "sturdy little beasts... not speedy, but good for a long day's work."
- "After riding for about an hour, slowly and without talking, they saw the Hedge looming suddenly ahead. It was tall and netted over with silver cobwebs." [MEASUREMENT: ~1 hour ride Crickhollow→Hedge]
- Entrance: Merry "turned to the left along the Hedge" to where "it bent inwards, running along the lip of a hollow. A cutting had been made, at some distance from the Hedge, and went sloping gently down into the ground. It had walls of brick at the sides... until suddenly they arched over and formed a tunnel that dived deep under the Hedge and came out in the hollow on the other side." Far end "closed by a gate of thick-set iron bars", locked; Merry has the key. — the Brandybucks' private brick-lined tunnel under the High Hay.
- "You have left the Shire, and are now outside, and on the edge of the Old Forest."

### Old Forest character, Bonfire Glade, paths
- Merry's lore: trees "watch you"; at night worse; "long ago they attacked the Hedge: they came and planted themselves right by it, and leaned over it. But the hobbits came and cut down hundreds of trees, and made a great bonfire in the Forest, and burned all the ground in a long strip east of the Hedge... There is still a wide bare space not far inside where the bonfire was made." — Bonfire Glade just east of the Hedge.
- "Something makes paths... they seem to shift and change from time to time." "Not far from this tunnel there is... the beginning of quite a broad path leading to the Bonfire Glade, and then on more or less in our direction, east and a little north." — intended bearing ENE toward the East Road.
- "a faint path leading up on to the floor of the Forest, a hundred yards and more beyond the Hedge" [MEASUREMENT]; ground "rising steadily" east of the Hedge; trees taller/darker/thicker inland.
- Bonfire Glade: "a wide circular space" of rough grass, hemlocks, wood-parsley, fire-weed, nettles, thistles; "No tree grew there."
- Beyond it "a clear path... They were still climbing gently."

### The bald hill and the view
- "The path stopped climbing... Before them, but some distance off, there stood a green hill-top, treeless, rising like a bald head out of the encircling wood. The path seemed to be making directly for it." Path "dipped, and then again began to climb upwards" to the hill-foot; they wind "round and round" to the top. Time at top: "It must have been about eleven o'clock."
- Southward view (KEY): "to the south of them, out of a deep fold cutting right across the Forest, the fog still rose... 'That is the line of the Withywindle. It comes down out of the Downs and flows south-west through the midst of the Forest to join the Brandywine below Haysend.'" — Withywindle: source in the (Barrow-)Downs, course SW across the Forest, mouth in Brandywine "below Haysend" [note: Ch 5 says AT Haysend — see contradictions]. "The Withywindle valley is said to be the queerest part of the whole wood – the centre from which all the queerness comes."
- Westward: "they could not make out either the line of the Hedge or the valley of the Brandywine beyond it" (haze).
- Northward: "they could see nothing that might be the line of the great East Road, for which they were making... the Road must lie that way, and it could not be many miles off." — East Road bounds the Forest region on the north within "not many miles" of the hill.
- Eastward: "they glimpsed far off in the east the grey-green lines of the Downs that lay beyond the Old Forest on that side... the Barrow-downs had as sinister a reputation in hobbit-legend as the Forest itself." — Barrow-downs east of the Old Forest.
- SE side of hill: "the ground fell very steeply."

### Being herded to the Withywindle
- Leaving north from the hill, the path "was bending steadily to the right... it must actually be heading towards the Withywindle valley." They leave it, strike northward; land at first "drier and more open, climbing up to slopes where the trees were thinner, and pines and firs replaced the oaks and ashes."
- But they "seemed unaccountably to have veered eastwards"; then "deep folds in the ground... like... wide moats and sunken roads long disused" lay "right across their line of march"; undergrowth "would not yield to the left, but only gave way when they turned to the right"; "always to the left and upwards it was most difficult... they were forced to the right and downwards."
- "After an hour or two they had lost all clear sense of direction... They were being headed off... eastwards and southwards, into the heart of the Forest and not out of it."
- Late afternoon: a fold "wider and deeper than any" — impossible to climb out with ponies; they follow it down; ground soft/boggy; springs; a brook grows and "flowed and leaped swiftly downhill"; "a deep dim-lit gully over-arched by trees."
- Exit: "they had made their way down through a cleft in a high steep bank, almost a cliff. At its feet was a wide space of grass and reeds; and in the distance could be glimpsed another bank almost as steep." — the Withywindle valley is flat-floored between two steep banks.
- The river: "there wound lazily a dark river of brown water, bordered with ancient willows, arched over with willows, blocked with fallen willows... a warm and gentle breeze blowing softly in the valley" — sheltered, warm microclimate; mid-course sluggish and willow-choked.
- Merry: "We have come almost in the opposite direction to which we intended. This is the River Withywindle!"; "fairly solid ground between the cliff-foot and the river; in some places firm turf went down to the water's edge"; "something like a footpath winding along on this side of the river. If we turn left and follow it, we shall be bound to come out on the east side of the Forest eventually." — path on their (north/left) bank; left = upstream = east.
- Path detail: "it passed over other rills, running down gullies into the Withywindle out of the higher forest-lands, and at these points there were tree-trunks or bundles of brushwood laid carefully across." — maintained crossings (someone maintains the path).
- Old Man Willow: "a huge willow-tree, old and hoary" beside the path/river; traps Merry and Pippin in cracks; tips Frodo into the river. "great winding roots grew out into the stream."

### Tom Bombadil and the walk to his house
- Tom appears "away down the path further back in the Forest" [ambig: behind = west/downstream? He is returning home with water-lilies and proceeds past them eastward], then "went hopping and dancing along the path eastward". Song: "Hop along, my little friends, up the Withywindle! Tom's going on ahead candles for to kindle." — Tom's house is UP the Withywindle (east/upstream) from Old Man Willow.
- Song locates house/Goldberry: "Down along under Hill... There my pretty lady is, River-woman's daughter" — Goldberry = "River-woman's daughter"; house "under Hill".
- "Down west sinks the Sun" behind them as they follow.
- Approach: "the ground was gently rising... the river flowed over a short fall" (white foam); "Then suddenly the trees came to an end... They stepped out from the Forest, and found a wide sweep of grass welling up before them. The river, now small and swift, was leaping merrily down to meet them." — upper Withywindle small/swift; a short fall at the Forest's eastern edge.
- "The eaves of the Forest behind were clipped, and trim as a hedge" (tended). "The path was now plain before them, well-tended and bordered with stone. It wound up on to the top of a grassy knoll... and there, still high above them on a further slope, they saw the twinkling lights of a house. Down again the path went, and then up again, up a long smooth hillside of turf, towards the light."
- House site (KEY): "There was Tom Bombadil's house before them, up, down, under hill. Behind it a steep shoulder of the land lay grey and bare, and beyond that the dark shapes of the Barrow-downs stalked away into the eastern night." — Tom's house on a turf hillside just outside (east of) the Old Forest, above the upper Withywindle, with a bare steep shoulder behind it and the Barrow-downs beyond to the east.
- Arrival after dark, stars out (evening of the day they entered at ~6 a.m. — one full day Hedge→Tom's house).

## MEASUREMENT REGISTER (this span)
1. "Sam knew the land well within twenty miles of Hobbiton" — Ch 3.
2. Water plank-bridge west of Hobbiton; "A mile or two further south they hastily crossed the great road" — Ch 3.
3. "walked for about three hours they rested" (night 1) — Ch 3.
4. "It is nearly midnight" (climbing steep slope, night 1) — Ch 3.
5. "Merry expects us some time the day after tomorrow; but that leaves us nearly two days more" — Ch 3.
6. Stream fall "a few feet over an outcrop of grey stone" — Ch 3.
7. Start "after ten o'clock" (day 2) — Ch 3.
8. "After some miles... the road ceased to roll up and down" — Ch 3.
9. "jogging along again for an hour or more" — Ch 3.
10. Road "run straight for some miles" before the Stock/Woodhall fork — Ch 3.
11. "we go to the woods on the hills above Woodhall. It is some miles" — Ch 3.
12. "On September 20th two covered carts went off" — Ch 3.
13. "The Ferry is east from Woodhall"; road "miles out of the way"; "save a quarter of the distance" — Ch 4.
14. "eighteen miles to go in a straight line" (to the Ferry) — Ch 4.
15. Tree-belt "no more than a mile at the widest"; "perhaps another couple of miles"; "After half an hour" — Ch 4.
16. Maggot's lane "After a mile or two... came to an end" at the causeway — Ch 4.
17. "It was five miles or more from Maggot's lane to the Ferry" — Ch 4.
18. Ferry lane "In a hundred yards or so it brought them to the river-bank" — Ch 5.
19. "They can go ten miles north to Brandywine Bridge" — Ch 5.
20. High Hay "well over twenty miles from end to end" (Bridge→Haysend) — Ch 5.
21. Brandy Hall "three large front-doors, many side-doors, and about a hundred windows" — Ch 5.
22. Buckland main road: "Half a mile northward along this... a lane opening on their right... followed for a couple of miles" — Ch 5.
23. "we could get off in an hour"; "five ponies" — Ch 5.
24. "chased for two days by Black Riders" — Ch 5.
25. Wake "half past four"; start "Soon after six o'clock"; "After riding for about an hour" to the Hedge — Ch 6.
26. Faint path "a hundred yards and more beyond the Hedge" — Ch 6.
27. Hilltop "about eleven o'clock" — Ch 6.
28. East Road "could not be many miles off" north of the bald hill — Ch 6.
29. "After an hour or two they had lost all clear sense of direction" — Ch 6.

## CONTRADICTIONS / ODDITIES (this span)
- Withywindle mouth: Ch 5 "Haysend (where the Withywindle flowed out of the Forest into the Brandywine)" vs Ch 6 "to join the Brandywine below Haysend." At vs below Haysend.
- Withywindle flow direction "south-west" (Ch 6) yet its valley is "a deep fold cutting right across the Forest" seen to the SOUTH from the bald hill, and following it upstream (turning LEFT when arriving from the north bank) leads "out on the east side of the Forest": consistent only if the river's upper course bends; text gives no further resolution. [tension, minor]
- Shire boundary: Ch 5 says the river "was the original boundary of the land eastwards", and Merry at the tunnel-gate says "You have left the Shire" on passing under the Hedge — so Buckland is treated as part of the Shire in Ch 6 speech though a "colony" in Ch 5 narration. [status ambiguity]
- Maggot tells the Rider "This lane don't lead anywhere", yet the Rider rides "up the lane towards the causeway" — the lane does connect to the causeway; Maggot's remark evidently means it leads only to his farm (rhetorical). [minor]
- Frodo's straight-line reckoning of 18 miles is from their overnight hill camp ("from where we stand"), i.e. above Woodhall, not from Woodhall itself. Combined with "save a quarter of the distance", the road route ≈ 24 miles [derived, not stated].

## WORLD-STRUCTURE (this span)
- "O Queen beyond the Western Seas... We sing to thee in a far land beyond the Sea... Thy starlight on the Western Seas" (Elbereth hymn) — Elbereth dwells beyond the Western Seas; the singers are in "this far land".
- "Few of that fairest folk [High Elves] are ever seen in the Shire. Not many now remain in Middle-earth, east of the Great Sea."
- Gildor: "We are Exiles, and most of our kindred have long ago departed and we too are now only tarrying here a while, ere we return over the Great Sea."
- Elves' present lands "away beyond the Tower Hills"; they pass through the Shire "in spring and autumn".
- Frodo's dream: far-off sound of the Sea; salt smell over a dark heath; "a tall white tower, standing alone on a high ridge" from which one might "see the Sea". [dream-vision]
- Gildor names hobbits' land part of a wider world: "The wide world is all about you: you can fence yourselves in, but you cannot for ever fence it out."
- "The Road" conceived as one continuous network: Bag End path → Mirkwood → Lonely Mountain ("and even further and to worse places").
