# A6b — Beren and Lúthien (2017): geography across versions
([early] = Lost Tales-era; Lay = Lay of Leithian 1925–31; QN = Quenta Noldorinwa 1930; cite section)

## Editorial frame (CT)
- Angband↔bridge of Menegroth "one hundred and fifty leagues" (Annals quote, Notes on Elder Days) — same figure as CoH.
- Drowned-Beleriand frame repeated; Ossiriand remnant = Lindon coastlands.
- Men entered over Blue Mountain passes; Dwarf-cities Nogrod, Belegost there.
- Name equations [early]: Artanor = later Doriath, "The Land Beyond"; Iron Mountains/Bitter Hills = later Ered Wethrin; beyond them Hisilómë (Hithlum) = Dor-lómin, "Land of Shadow"; Palisor = land of Elf-awakening.

## Tale of Tinúviel [early]
- Tinwelint's halls: deep cavern in heart of Artanor forest; stream before the doors; entry only by narrow guarded bridge.
- Beren [early] a Gnome of Hisilómë (son of Egnor); came "over the Bitter Hills"; Angband route = across Iron Mountains; also claims origin in Aryador (Men's name for Hisilómë).
- Hirilorn "Queen of Trees": mighty three-shafted beech above the king's portal-slope to the river; Lúthien's house set as high as the longest ladders reach; hair-spell 12 hours' growth. (QN: imprisoned "in the tallest of his mighty beeches".)
- Tinúviel's flight: near foothills of the Mountains of Night (Taurfuin, "where afterward Túrin slew Beleg"); she skirts it.
- Tevildo's castle [early, later fully abandoned]: grassy slope to a rocky spur; behind it the black cloud of Angamandi; castle on cliff-shelf, terraced approach, gate "in the air". Huan's fake lair "a dale not a mile westward"; Huan hears "a league away".
- Angamandi [early]: iron gates with knives/spikes; Karkaras before them; "ten thousand smiths"; Karkaras "nigh as large as a horse".
- Flight out: past Taurfuin, "many leagues of peril" still to the caverns; Huan finds them in Nan Dumgorthin, "land of the dark idols", a "northward region of Artanor".
- Wolf-hunt: four hunters; slot beside the stream near the king's doors; followed the stream all day.
- Second-life dwelling [early]: i-Cuilwarthon "mighty fairies in the lands about the north of Sirion"; in Nauglafring tale Beren ranges Hithlum/Artanor; "A Silmaril burns in the woods of Hisilómë".

## Sketch of the Mythology (1926)
- Beren flees south, "crosses the Shadowy Mountains", comes to Doriath.
- Thû the hunter in Tol Sirion → Tol-in-Gaurhoth "Isle of Werewolves".
- Second life: "woods of Doriath and in the Hunters' Wold, west of Nargothrond".

## Lay of Leithian
- Barahir's lair (1925 Canto II): "a wooded island in the fen"; ring taken beside a hot fountain. Beren buried him under boulder-stones.
- Beren's crossing south: over "the Shadowy Mountains cold" [so named here; = later Gorgoroth]; northern slopes evil, southern faces "mounted sheer in rocky pinnacle and pier"; from eagle-height one sees "Beleriand, Beleriand".
- To Nargothrond (Canto VI): down Esgalduin to Sirion; Sirion pools then plunges "into vast chasms underground... many miles" — Umboth-Muilin, Twilight Meres; across the Guarded Plain he sees Hills of the Hunters; Narog's "cloven way" and Felagund's halls "beside the falls of Ingwil"; every hill tower-crowned between Narog and Sirion.
- Crossing: "no ford nor bridge" before Nargothrond's gates; waded northward below the Ginglith-Narog confluence. [Contradicts none: CoH bridge is Túrin's later work.]
- Twelve from Nargothrond go north up Narog to its source at Ivrin's lake mirroring "Shadowy Mountains"; Orc-band of 30 ambushed; disguised, they pass "beyond Beleriand" to young Sirion between Taur-na-Fuin (east) and the "northward-bending Mountains grey" (west).
- Tol Sirion (Wizard's Isle): "isléd hill... amid the valley"; river loops round its feet; former Elvish watchtower; views south to Beleriand, north over dusty dunes to Thangorodrim's cloud; "stony bridge" to the isle. At Thû's fall the tower crumbles, bridge breaks; Thû flees to Taur-na-Fuin. Felagund's green grave on the hill-top.
- Celegorm/Curufin's road: met the lovers at "Mindeb's narrow stream" on Doriath's western border; their route home = north between Doriath and Taur-na-Fuin toward Himling's hill over Aglon's gorge.
- Beren north to Angband: leaves Lúthien in a Doriath glade; edge of Dor-na-Fauglith, "Land of Thirst"; slopes of Deadly Nightshade (Taur-na-Fuin) look north over it; sends horse back to Sirion's vale. Lúthien rides Huan "as Orc on werewolf".
- Desert crossing in wolf/bat disguise: "many parching leagues"; second morning reach "foothills of the North"; road up within the Mountain, tunnels; court of cliffs before Angband's "topless wall" and gates; Fingolfin's duel-pits there; descent "to the mountain's roots profound".
- Thorondor: wings "thirty fathoms wide"; bore Fingolfin's corse to a snowcap where mountains "ring far to the south" of that plain, "where after Gondolin did reign"; no Orc dared that pass "till Gondolin's appointed doom".
- Escape (Silmarillion text quoted by CT): three eagles bear them; set down on Doriath's border, same dell; eagles return "to the peaks of Crissaegrim".
- Lay abandoned Sept 1931 at line 4223; MS dates 23 Aug 1925 → 17 Sep 1931.

## QN and later
- Felagund met Men in "a dale in the western foothills" of the Blue Mountains; after Bragollach fled "to the fens of Sirion"; founded Nargothrond on Narog's banks; sons of Fëanor fortified Himling, filled Aglon gorge.
- Second life (QN): Ossiriand, "between the river Gelion and the mountains"; folk = Green Elves; land called Cuilwarthien. Dwarf-road Nogrod/Belegost passes through E. Beleriand and woods about Gelion.
- Sarn Athrad (QN): "a ford across the river Ascar... named Sarn Athrad, the Ford of Stones", north of Ossiriand, on the Dwarves' road to the mountain passes; Beren's last fight there, warned by Melian. Treasure drowned in Ascar → renamed Rathlorion "Goldenbed".
- Nauglafring tale [early] battle detail: ford widens over shingle-spits; far bank "great and sheer" and tree-thick; crossing morn→high noon; Beren vs Naugladur 3 hours; river called both Ascar and "Aros" [inconsistency, CT prints as-is].
- NOTE: Tol Galen and Lanthir Lamath never occur in this volume. Dior "went back to Doriath" (QN); Silm. quote: Green-Elf lord brings the Silmaril to Menegroth from Ossiriand.

## 1950s rewritten Lay (Appendix)
- Tarn Aeluin replaces the fen-island: tarn on "the highland brown and bare" of steep Dorthonion; birch-ringed, lonely moor; lair under grey stones. LoN: Aeluin "in the northeast of Dorthonion".
- Sauron (ridden from "Gaurhoth Isle") camps nearby; price on each head "the weregild of a king".
- Beren tracks the slayers to "where Rivil rises from the fell" flowing "down into Serech's reeds". Songs: "ambush in Ladros, fire in Drûn" (LoN: Drûn "north of Lake Aeluin; not named elsewhere").
- Route south now over "the dreadful peaks of Gorgorath" (name replacing the Lay's "Shadowy Mountains").

## List of Names highlights
- Aglon: "narrow pass between Taur-na-Fuin and the Hill of Himring". Gorgorath: precipices where Dorthonion "fell southwards". Guarded Plain: "between the rivers Narog and Teiglin, north of Nargothrond". Hills of the Hunters: "highlands west of the river Narog". Ingwil: falls into Narog at Nargothrond (later Ringwil). Umboth-Muilin: where Aros, "southern river of Doriath", met Sirion. Rivil: rises west of Dorthonion, joins Sirion at Serech "north of Tol Sirion". Hisilómë [early] gloss: scanty sun over Iron Mountains "east and south" (CT later flags this as uncorrected — see A6c).
