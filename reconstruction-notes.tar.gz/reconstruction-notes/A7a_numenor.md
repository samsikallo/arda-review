# A7a — Númenor: Description of the Island + Aldarion and Erendis (UT, src lines cited)

## Shape and size
- Full sentence (l.5128): "The land of Númenor resembled in outline a five-pointed star, or pentangle, with a central portion some two hundred and fifty miles across, north and south, and east and west, from which extended five large peninsular promontories."
- Promontories: Forostar (Northlands), Andustar (Westlands), Hyarnustar (Southwestlands), Hyarrostar (Southeastlands), Orrostar (Eastlands). Central Mittalmar; Arandor (Kingsland) a separated part of it containing Rómenna, the Meneltarma, Armenelos; most populous region.
- NOTE: the only ">700 miles" line in the whole volume is NOT about Númenor; it is CT's Introduction footnote on Middle-earth (l.14898): "In one of my father's map-sketches the northern coast of Middle-earth is shown stretching in a great curve east-north-east from the Cape [of Forochel], the most northerly point being some 700 miles north of Carn Dûm." The line connects the tip of the Cape of Forochel to the most northerly point of the coast.
- Tilt (l.5232): land "thrust upward out of the sea, but tilted southward" and a little eastward; steep cliffs on nearly all coasts save the south.
- Mittalmar raised above the promontories; grasslands, low downs, few trees; no coast except about Rómenna and head of its firth.

## Meneltarma
- Near centre of Mittalmar; sacred to Eru; unscalable near summit; "a winding spiral road" from foot on south to below summit-lip on north (l.5142).
- Summit flattened/depressed, "could contain a great multitude"; never any building; the Hallow — only the King spoke, thrice yearly (Erukyermë spring, Erulaitalë midsummer, Eruhantalë autumn); three eagles ("Witnesses of Manwë").
- Tarmasundar: five root-ridges toward the five promontories; climbing road on SW ridge crest; between SW and SE ridges lay Noirinan, Valley of the Tombs — rock-cut tombs of Kings and Queens at the mountain's base.

## Regions
- Forostar: least fertile, stony; fir/larch on westward moor-slopes; toward North Cape "great Sorontil rose sheer from the sea" (l.5172), eagle-haunted; Tar-Meneldur's star-tower there.
- Andustar: rocky north with fir-woods; three west-facing bays, northmost = Bay of Andúnië with the great haven Andúnië, town by shore, dwellings on slopes. South fertile: birch/beech uplands, oak/elm vales. Between Andustar and Hyarnustar the great Bay of Eldanna, "because it faced towards Eressëa" (l.5183); warm, wettest region; at its centre the haven Eldalondë the Green. Nísimaldar: fragrant Eressëan trees around it; only place the mallorn (malinornë) grew great. River Nunduinë entered sea at Eldalondë, forming lake Nísinen upstream.
- Hyarnustar: west mountainous with great cliffs (W and S coasts); east great vineyards, warm and fertile. Hyarnustar/Hyarrostar shores splayed wide — only gentle coasts. River Siril, chief river, rose "under the Meneltarma in the valley of Noirinan" (l.5217), flowed south through Mittalmar, slow winding lower course, entered sea amid marshes and shifting sandy mouths; wide white beaches for many miles; fisher villages, chief Nindamos.
- Hyarrostar: many trees incl. laurinquë; "From the days of Tar-Aldarion there were great plantations" for ship-timber (l.5227).
- Orrostar: cooler; sheltered by highlands toward promontory's end; grain-lands, esp. near Arandor.
- Emerië: in SW Mittalmar, rolling grass downs, "chief region of the Shepherds"; Erendis's white house on a downside facing west; Hyarastorni (Hallatan's sheep-lands) in Mittalmar to its south. Ride Armenelos→Emerië: hard riding, one evening + next day to nightfall.

## Roads
- Roads mostly unpaved (riding culture; cargo by sea). Chief wheeled road: Rómenna → Armenelos → Valley of the Tombs/Meneltarma; "early extended to Ondosto within the borders of the Forostar, and thence to Andúnië" (l.5255). Carried Forostar building-stone and Andustar timber.

## Havens, towers, misc.
- Rómenna: greatest port; firth; Tol Uinen "a little isle in the bay of Rómenna"; Aldarion's light-tower Calmindon on it; great sea-walls and quays built by the Guild of Venturers era.
- CT's Númenor map (Intro l.298): redrawn "from a little rapid sketch, the only one" JRRT made; original shows another haven west of Andúnië, name "almost certainly Almaida" (occurs nowhere else).
- Oromet: hill "nigh to Andúnië and the west shores"; Tar-Minastir's high tower, gazing westward (l.6817).
- SA 600: Vëantur's Entulessë, first voyage to Middle-earth, into Mithlond; returned following autumn.
- King's Archers: hollow-steel bows, arrows "a full ell long" (l.5283).

## Aldarion and Erendis — Middle-earth geography
- Vinyalondë founding (l.5443ff): seeking timber and a repair-haven, "at the mouth of the river that the Númenóreans called Gwathir" he established Vinyalondë, the New Haven (note 9: river later Gwathló/Greyflood; haven later Lond Daer).
- Later voyages found Vinyalondë "overthrown by great seas", plundered by hostile men; works repeatedly ruined; Gil-galad letter: haven "secure against sea and land" long laboured in vain. Editorial (l.6533ff): works "never completed, and the sea gnawed them", but laid foundation for Tar-Minastir's SA-1700 intervention — fleets "in time to the right place".
- Aldarion went "up the River Gwathló as far as Tharbad", met Galadriel (then dwelling in Eregion "at no great distance from Tharbad").
- Exploration south: past "mouths of Baranduin and Gwathló and Angren", rounded "the dark cape of Ras Morthil", beheld Bay of Belfalas and mountains of Amroth's country. Note 6: Ras Morthil = headland of the north arm of the Bay of Belfalas, "also called Andrast (Long Cape)"; (Sîr) Angren = Isen.
- First meeting of Númenóreans with Men of Eriador: on the Tower Hills; those Men dwelt about Lake Evendim, North Downs, Weather Hills, and lands to the Brandywine.
- Voyage durations (SA years): first 725–7; then ~730–3 (3 yrs); ~735–9 (4 yrs); 806–13 (7 yrs); Palarran 816–20; seven-ship voyage 824–9 (returned with nine ships, timber-laden); great voyage 829–843 (three times driven back crossing the Great Sea westward); 863–9 (6+ yrs; driven far north into ice-perilous wastes); Hirilondë spring 877–autumn 882; as King, Mithlond voyages ~18 yrs; last voyage ~SA 1000.
- Timber: Aldarion's fellings in Númenor caused "great dissensions"; Hyarrostar plantations begun; Middle-earth felling → see A7b (Appendix D).
- Enedwaith danger: "dark men out of the mountains" thrusting into Enedwaith in his later years.
- Drúedain of Númenor (Drúedain ch. n.7): foreboded evil from Aldarion's voyages; all departed Númenor before the Downfall.
- Tar-Minastir chronology discrepancy (l.6996): fleet reached Middle-earth SA 1700; CT "cannot in any way account for" clash with Line-of-Elros dates.
