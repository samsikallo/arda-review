# A7c — Númenórean Linear Measures + Disaster of the Gladden Fields (UT, src lines cited)

## Linear Measures appendix (l.8873–8952)
- League used for lár, longest measure. Númenórean reckoning decimal: 5,000 rangar (full paces) = 1 lár = "very nearly three of our miles".
- Lár = 'pause' (halt made after that distance except in forced marches).
- Ranga = "slightly longer than our yard, approximately thirty-eight inches".
- Exact equivalence: 5,000 rangar ≈ 5,280 yards (our league); precisely "5277 yards, two feet and four inches" if exact.
- 2 rangar = "man-high" = 6 ft 4 in (average male Dúnadan height, later period).
- Full stride "well nigh a ranga and a half".
- Elendil "more than man-high by nearly half a ranga" — tallest of the survivors; "Elendil the Tall".
- Galadriel: man-high by Dúnedain measure ≈ 6 ft 4 in; tallest of Eldarin women.
- Hobbits: three to four feet, "never less and seldom more".
- Index (l.14039): "*lár A league (very nearly three miles)."

## Isildur route figures (notes 6 and 9 to Gladden Fields)
- Intended route (Osgiliath → Vales of Anduin → Cirith Forn en Andrath [= the High Pass] → Imladris): "Three hundred leagues and more"; mostly roadless.
- Only Númenórean roads then: (1) Gondor–Arnor road through Calenardhon, over Gwathló at Tharbad, to Fornost; (2) East-West Road, Grey Havens–Imladris; crossing at [Bree] west of Amon Sûl.
- Western alternative: Osgiliath→road-meeting 392 leagues; road-meeting→Imladris east 116 leagues; total 508 leagues.
- As marched, the journey was "probably at least three hundred and eight leagues".
- March rates: fully-armed Dúnedain 8 leagues/day "with ease" — eight spells of one league, short breaks after each league + 1 hour near midday = ~10.5-hour march, 8 hours walking. In haste 12 leagues/day ("or in great need more"), shorter periods.
- Daylight at Imladris latitude at the date: ≥11 hours; midwinter <8. No long journeys Hithui (Nov)–Nínui (Feb) in peace.
- Plan: depart Yavannië 5, arrive within 40 days (by Narbeleth 15) — "sufficient, if all went well".

## Disaster of the Gladden Fields — itinerary (TA year 2)
- Force: Isildur + sons Elendur, Aratan, Ciryon + Guard of 200 knights/soldiers; 10 pack-ponies; 2 days' provisions per man; only ~20 archers.
- Day 1: left Osgiliath "early in Ivanneth", East-gate of the Bridge; over Dagorlad northward through empty lands south of Greenwood.
- Day 20: within far sight of the forest; rain 4 days (wind from Sea of Rhûn).
- At "the entrance to the Vales, between Lórien and Amon Lanc": left swollen Anduin, climbed eastern slopes to "ancient paths of the Silvan Elves" near the forest-eaves. (Amon Lanc "Naked Hill" = highest point of the SW Greenwood highland, later Dol Guldur.)
- Day 30, late afternoon: "passing the north borders of the Gladden Fields" on a path toward Thranduil's realm; "three parts of the long road" done. Isildur: Moria and Lórien far behind, "Thranduil four days' march ahead".
- Ambush: Orcs from forest above (path on steep slopes, gentler descent below to valley-bottom); outnumbered up to ten times; after first repulse column bent down to flatter ground; "gone scarcely a mile" when second, encircling attack came; night battle; all slain save Ohtar + companion (with Narsil's shards) and Estelmo.
- Note 29: last stand "a mile or more beyond their northern border" (of the Gladden Fields); course maybe bent south in the dark.
- Isildur's flight: note 27 — "Seven leagues or more" from battlefield to Anduin; fled at nightfall, reached river ~midnight. Cast off armour, kept an eket (stabbing sword "from a foot to one and a half feet long"). Swimming, forced "almost north against the current"; swept toward Gladden tangles ("nearer than he had thought"); Ring slipped off; reached "a marshy islet close to the western shore"; shot by Orc bank-watchers. Ring later found "sunk near the edge of the Gladden Fields", close to the western bank; deduction: he fell "into shallow water, no more than shoulder-high" (Elendilmir later found in Orthanc — Saruman had searched there).
- Evidence: his mail, helm, shield, great sword found "on the bank not far above the Gladden Fields"; an Orc watch-camp "close to the borders of the Gladden Fields".

## Gladden Fields physical geography (note 13 + note 14 draft)
- Anduin above the Fields: "the swiftest part of its course, a long descent of some seventy miles" into a deep depression; there met the torrent of the Gladden River (Sîr Ninglor).
- The old lake wider WEST of Anduin (east valley-side steeper); east side once reached the feet of the forest slopes; became a great marsh of islets, reeds, giant yellow iris (name-source); marsh had receded east leaving walkable grass flats below the slopes.
- Note 14 draft: the ancient Forest Road came down "from the Pass of Imladris" and crossed Anduin by a bridge (enlarged for the Alliance armies); "Anduin could not be bridged at any lower point"; a few miles below the Forest Road the land fell steeply, river very swift to the Gladden basin; below the Fields again a great flood fed by Gladden, Silverlode (Celebrant), Limlight (Limlaith). (Hobbit tradition: Old Ford, no bridge.)
- Note 18: east of Anduin beyond the depression, ground firmer/drier, climbing north until nearly level with the Greenwood eaves near the Forest Road.
- Note 16: Naith of Lórien = angle of Celebrant and Anduin, "narrower and more pointed" at the junction than a small-scale map can show.
- Oropher/Thranduil (note 14): Silvan king moved north three times from Amon Lanc; end of SA in "the western glens of the Emyn Duir" (later Emyn-nu-Fuin, Mountains of Mirkwood, NE forest); people west to Anduin, north of the Dwarf-Road (Men-i-Naugrim = Old Forest Road).
