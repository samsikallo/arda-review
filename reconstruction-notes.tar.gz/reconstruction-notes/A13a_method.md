# A13a — Fonstad Atlas of Middle-earth (rev. ed. 1991): Method & Assumptions
All items [Fonstad-derived], her interpretation, not Tolkien's text. Cites = Atlas chapter.

## Edition / source policy (Foreword)
- Original 1981; 1991 revision uses HoME I–IX (IX in typescript; page cites differ from print).
- HoME used "simply as a reference to confirm and/or elaborate on the original atlas, rather than to add maps and discussion comparing various forms of the stories."
- "'The Tale of Years' continued to stand as the authority for the quest of the ring, as well as the Elder Days."
- Marquette MS collection consulted; earlier-version sketches differed "notably Isengard, Dunharrow, and Minas Tirith."

## Guiding principle (Introduction)
- Tolkien's "inner consistency of reality" (On Fairy-Stories) governs; her two questions: "(1) What would it be like in our Primary World? (2) How was it affected by the Secondary World?"

## Round vs flat (Introduction)
- Arda flat until Fall of Númenor ("the world was indeed made round"); Ambarkanta diagrams (HoME IV): Vista (airs), Ambar (earth), Vaiya (encircling seas), Kúma (Void); disk like medieval maps.
- LotR maps show north arrow + bar scale (impossible for a round world). Her solution: "The only reasonable solution is to map his maps—treating his round world as if it were flat. Then Middle-earth will appear to us as it did to Tolkien."
- Middle-earth compass "faced west" (toward Valinor), but maps drawn north-up like Tolkien's.

## Grid (Introduction; Regional Maps intro)
- Worldwide index grid "extends from Valinor to the mounts of Orocarni, and from the Grinding Ice to Far Harad. Each square is 100 miles on a side, as are those used on Tolkien's working maps."
- Regional grids offset from Tolkien's: 50 mi east–west, 25 mi north–south.

## League → mile (Introduction)
- Units: fathom 6 ft; ell 27–45 in; furlong 220 yd; historical league 2.4–4.6 mi.
- Definitive: UT 285 — a league "in Númenórean reckoning . . . was very nearly three of our miles."
- She measured every LotR league reference (road + straight-line): range 2.9 mi/league (Pelargir–Harlond) to 17.5 (Helm's Deep–Fords of Isen, straight). Leagues treated as straight-line; constant **3.0 mi/league** adopted.
- Validation quote: "Applying the constant of 3.0 miles per league to the map and distances given in The Silmarillion produced a marvelous result: The curvature of the Blue Mountains—the only feature common to maps of both the First and Third Ages—matched exactly even before the maps in The History were available!"
- Scale bar applies to all large regional maps except Valinor, Númenor, the Shire.

## Latitude / climate anchors (Introduction; Climate chapter)
- No lat/long given by Tolkien; latitude guessed from climate clues (seasons, winds).
- Quote: "These alone indicate that the familiar lands of the northwest must have lain in roughly the locale of Europe. Tolkien, upon questioning, was even reported to have said that Middle-earth is Europe, but later denied it." (Cites Resnick interview, Niekas 18; denial via Kilby.)
- **NEGATIVE FINDING: the Letters passage equating Hobbiton with Oxford's latitude and Minas Tirith with Florence is NOT cited anywhere in this text.** Carpenter's Letters is in her bibliography; Letters 407 is cited once, only for Aglarond being inspired by Cheddar Gorge (Helm's Deep ch., n.2).
- Climate ch.: westerly-wind belt = European latitudes; Shire given "the climate of England" (Marine West Coast); Forochel cold only 100 leagues north of the Shire (Morgoth's lingering cold + Angmar's frosts); east of Misty Mtns continental; Mordor arid/semi-arid, possible Mediterranean dry-summer around Bay of Belfalas; good powers superimpose warm climates (Valinor, Lórien), evil powers cold/bitter ones.
- Tolkien quote she uses (Resnick): Middle-earth based on "my wonder and delight in the Earth as it is."

## Elevation / landform method (Introduction; regional chapters)
- "Tolkien's original maps and illustrations have been utilized as general references for location and elevation; but if differences arose, the final drawings were usually based upon the text and inferences drawn from its passages."
- Pictorial physiographic style; "cannot be construed as showing every hill"; cross-sections labeled with vertical exaggeration (e.g., 3:1).
- Elevations inferred from Primary-World analogy: snowline latitude (White Mtns ≥9500 ft), climbing rates, comparisons to Alps, Etna, Shiprock, Carlsbad/Mammoth caves, Crater Lake, English Downs/Weald, finger lakes; geomorphology texts cited (Lobeck, Strahler, Thornbury).
- Mapping precedence quote (Tolkien via HoME VI 302): "'. . . where this is possible and does not damage the story, to take the maps as "correct" and adjust the narrative.'"

## Pathways method (Introduction; Pathways chapter)
- Daily distances from known campsites/arrival times, interpolated, "with adjustments for change of travel speed (e.g., being chased by wolves)."
- HoME mileage charts checked; originals kept except one case (Trollshaws), where both versions shown.
- Map altered slightly toward text where stated distances conflict with map scale.
- Day length assumed: 7–5 (Dec–Jan), 6–6 (Sept, Mar); Shire Calendar; day begins midnight.

## Cultural overlays (Introduction)
- Six map types: physical; political; battles; migrations; pathways; site maps.
- Color code: "evil was represented by black, and good by gray and/or brown."
- Spellings and First Age dates follow Robert Foster's Complete Guide.
- Battle troop numbers are her estimates from populace, topography, roads, fords (Tolkien "gave little information about the numbers").

## Interpretive stance (Introduction, Conclusion)
- "An almost endless series of questions, assumptions, and interpretations was necessary... Each line has been drawn with a reason behind it... Among various alternatives, I have chosen those that seem most reasonable to me."

## Beleriand↔Third Age registration (First Age ch.)
- Superimposed LotR "First Map" (VII 302) on "Second 'Silmarillion' Map" (V 408–411), "aligning the locations of Tol Fuin over Dorthonion (Taur-nu-Fuin) and of the isle of Himling with the city of Himring"; both grids 100-mi squares, axes offset 50 mi.
- Confirms text distances (S cites): Menegroth–Thangorodrim 150 leagues (the one exception, see A13d); Dorthonion E–W 60; Nargothrond–Ivrin 40; Nargothrond–Falls of Sirion 25; East Beleriand (Sirion–Gelion) 100; R. Sirion 130; R. Narog 80; Gelion confluence–Ascar 40; Gelion total 260 leagues ("twice Sirion").
- Beleriand south coast drawn 260 leagues from Gelion's sources, assuming continued SW flow; forested by Taur-im-Duinath analogy.

## Valinor exception (Valinor ch.)
- "Distances not only were not given, they were meaningless" (Valar are spirits); Valinor mapped impressionistically, no scale.
