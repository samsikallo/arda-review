# A13 — Karen Wynn Fonstad, *The Atlas of Middle-earth* (Revised Edition, 1991; HMH ebook, eISBN 978-0-547-52440-5)

**STATUS OF SOURCE**: SECONDARY / DERIVED reference. Everything below is [Fonstad-derived] — her cartographic interpretation of Tolkien's texts and Christopher Tolkien's *History of Middle-earth* (HoME) materials, NOT Tolkien's own text unless she quotes him. Chapter citations given per Atlas chapter. Source file: `scratchpad/text/R_atlas.txt` (372 form-feed pages, full ebook incl. notes, references, index).

**Edition facts** (Foreword/Copyright): Original atlas 1981; this is the 1991 revision incorporating HoME vols I–IX (IX *Sauron Defeated* used in typescript — its page cites won't match print). Decision: use HoME "simply as a reference to confirm and/or elaborate on the original atlas, rather than to add maps and discussion comparing various forms of the stories." "The Tale of Years" "continued to stand as the authority for the quest of the ring, as well as the Elder Days." Marquette University Tolkien MS collection consulted; sketches there differed from published descriptions "notably Isengard, Dunharrow, and Minas Tirith" (drawings belonged to earlier text-versions).

---

## 1. METHODOLOGY & ASSUMPTIONS (Introduction; Regional Maps intro; Pathways intro; Appendix notes)

### Sub-creation principle
- Tolkien quote she uses: Secondary World must have "the inner consistency of reality" ("On Fairy-Stories", TL 48). Her two working questions for every feature: "(1) What would it be like in our Primary World? (2) How was it affected by the Secondary World?"
- Tolkien interview quote (Resnick, Niekas 18): "If you really want to know what Middle-earth is based on, it's my wonder and delight in the Earth as it is, particularly the natural earth."

### Round vs. flat (Introduction)
- Arda flat until Fall of Númenor: "the world was indeed made round" (S 281); "Circles of the World" = confines, not sphere. Ambarkanta diagrams (HoME IV, 243–245) confirm: 'Vista' (inner airs) domed above, 'Ambar' (earth) below, 'Vaiya' (encircling 'seas') separating from 'Kúma' (the Void). "There is no contradiction in the statement 'it was globed amid the Void,' for the diagrams clearly demonstrate that Middle-earth could be both round and flat!"
- Post-change mapping paradox (LotR maps have north arrow + bar scale = both distance & direction accurate, impossible on a round world): "The only reasonable solution is to map his maps—treating his round world as if it were flat. Then Middle-earth will appear to us as it did to Tolkien."
- Compass: Tolkien said Middle-earth compass points began with and faced west (toward Valinor); but all his maps oriented north-up for readers; Atlas does same.

### Indexing grid
- No latitude/longitude given by Tolkien. "Latitude can be roughly guessed by climatic clues—seasons and wind patterns. These alone indicate that the familiar lands of the northwest must have lain in roughly the locale of Europe. Tolkien, upon questioning, was even reported to have said that Middle-earth is Europe [Resnick interview], but later denied it [Kilby]."
- **IMPORTANT NEGATIVE FINDING**: Fonstad does NOT cite the Letters passage placing Hobbiton at Oxford's latitude / Minas Tirith at Florence's anywhere in this text. Her Europe-latitude argument rests on climate clues + the Resnick interview/Kilby denial. (Carpenter's *Letters* appears in her references, and Letters 407 is cited once — only for Aglarond being inspired by Cheddar Gorge caverns, Helm's Deep chapter note 2.)
- Grid: "all location maps have been based upon a worldwide grid that extends from Valinor to the mounts of Orocarni, and from the Grinding Ice to Far Harad. Each square is 100 miles on a side, as are those used on Tolkien's working maps" (V 408–411; VI 297, 300). Regional maps intro: index marks 100 mi apart "but they are off 50 miles east-west and are 25 miles north on the north-south grid" relative to Tolkien's originals.

### League conversion (Introduction, "How Long Is a League?")
- Units: fathom = 6 ft; ell = 27–45 in; furlong = 220 yd (1/8 mi). Historical league varies 2.4–4.6 mi.
- Definitive figure from UT 285: a league "in Númenórean reckoning . . . was very nearly three of our miles."
- She measured every league reference in LotR by road and straight line: usage ranged **2.9 mi/league** (Anduin, Pelargir→Harlond landings) to **17.5 mi/league** (straight-line Helm's Deep→Fords of Isen). Most reasonable if treated as straight-line. Constant **3.0 mi/league** adopted.
- Validation: "Applying the constant of 3.0 miles per league to the map and distances given in The Silmarillion produced a marvelous result: The curvature of the Blue Mountains—the only feature common to maps of both the First and Third Ages—matched exactly even before the maps in The History were available!"

### Pathways method (Introduction + Pathways chapter)
- Daily distances calculated from known campsites and arrival times, interpolating mileage since last known site, "with adjustments for change of travel speed (e.g., being chased by wolves)." Mileage charts in HoME checked, but originals retained (constant restructuring), "with one exception, and then both versions are shown" (Trollshaws).
- Day-length assumptions: 7 A.M.–5 P.M. sun Dec–Jan; 6–6 in Sept & March. Shire Calendar used; Shire day begins at midnight.
- Pathway maps use text distances even where they disagree slightly with map scale ("altered slightly to more closely agree with the text").

### Physical base map
- "Tolkien's original maps and illustrations have been utilized as general references for location and elevation; but if differences arose, the final drawings were usually based upon the text and inferences drawn from its passages."
- Pictorial physiographic style — "It certainly cannot be construed as showing every hill." Cross-sections flag "Vertical exaggeration 3:1" etc.
- Tolkien's later policy quoted (via HoME VI 302): "'. . . where this is possible and does not damage the story, to take the maps as "correct" and adjust the narrative.'"

### Cultural overlays
- Six map types: (1) physical (landforms, minerals, climate) w/ place names; (2) political/spheres of influence; (3) battles; (4) migrations (tied to linguistics); (5) travellers' pathways; (6) site maps. Symbol convention: "Whenever good and evil were mixed, evil was represented by black, and good by gray and/or brown."
- Spellings follow Robert Foster's *Complete Guide to Middle-Earth*; First Age dates also per Foster (because 'Later Annals of Beleriand' not used in preparing S).
- Battle troop estimates: "Tolkien gave little information about the numbers of troops... The necessary estimates, therefore, were based upon scattered comments about numbers and location of the populace; and upon knowledge of the topography, existing roads, bridges, and fords." (Battles of Beleriand intro; same approach in LotR battles.)

### Explicit interpretive stance (Introduction, Conclusion)
- "An almost endless series of questions, assumptions, and interpretations was necessary in producing the maps... Each line has been drawn with a reason behind it... Among various alternatives, I have chosen those that seem most reasonable to me."

### Beleriand↔LotR map registration (First Age chapter, "Beleriand")
- Superimposed the "First Map" for LotR (VII 302) over the "Second 'Silmarillion' Map" (V 408–411), "aligning the locations of Tol Fuin over Dorthonion (Taur-nu-Fuin) and of the isle of Himling with the city of Himring." Both use 100-mile squares, but lettered axes differ by 50 miles.
- Distance checklist confirmed (S cites): Menegroth→Thangorodrim 150 leagues*; Dorthonion highlands E–W 60 leagues; Nargothrond→Pools of Ivrin 40 leagues; Nargothrond→Falls of Sirion 25 leagues; East Beleriand Sirion→Gelion 100 leagues; River Sirion 130 leagues; River Narog 80 leagues; River Gelion: confluence of Greater & Little→River Ascar 40 leagues; total length "twice . . . Sirion" = 260 leagues. (*the one exception — see Thangorodrim below.)
- Southern coast of Beleriand: mapped "at a point 260 leagues from the sources of River Gelion—based on the assumption that the river continued its southwesterly flow. This brought the coast near that of the Bay of Belfalas." SW tip extended to emphasize Bay of Balar; area shown forested "assuming the circumstances that produced Taur-im-Duinath would have prevailed."

---

## 2. DISTANCE TABLES & DAILY RATES

Note: the printed Atlas has a large pathway table; the ebook text preserves its summary rates and the narrative legs. Extract of every figure present:

### Pathways chapter — general speeds
- Walking: 2.0–2.5 mph typical (24–30 min/mile); 3.0 mph run by Orcs and by Aragorn/Gimli/Legolas.
- Riding: ponies 3.4 mph jogging; horses of Rohan 6.7 mph galloping; horses of the Dúnedain 7.0 mph; Shadowfax 20 mph (3 min/mile).
- Boating: small boats drifting 2.8 mph; paddling 4.1 mph; ships rowing against current 4.7 mph; sailing 7.2 mph.
- Ents: 10 mph. Orc endurance: 56 hours with one camp and two other stops.

### Hobbit pathways (The Hobbit: Introduction chapter)
- Bag End→Rivendell: "slightly more than 400 miles"; up to 51 days available; her compromise: 38 days travel, 27 days at Rivendell — avg 10 mi/day (as little as 8 if 51 days).
- Rivendell→Lake-town: 84 days total (Midyear's Day→Sept 22), all en route except 1 rest day at Beorn's + captivity.
- Rivendell→Goblins' Front Porch: 25-day ascent (vs. Gandalf's "two marches" to top of Redhorn Pass for the Fellowship).
- Goblin tunnels: est. 35 miles Front Porch→back-door (2.5 days); Great Goblin's cavern est. 5 miles in; cavern ~300 × 100 ft; Gollum's lake shown 400 ft diameter; side passages ~1 mile from Gollum's cave.
- Anduin valley on Beorn's ponies: "a respectable twenty miles per day."
- Mirkwood forest path: **188 miles** total; 143 covered on reaching the Enchanted Stream; up to 4 weeks crossing at ~6.5 mi/day.
- Lake-town→Erebor: rowed 3 days up Long Lake & Running River, then rode. Long Lake ~20 mi south of the Mountain; Erebor diameter ≈ half the distance to Long Lake (Thrór's Map).
- Iron Hills: Dáin "some two hundred fifty miles away." Elves+Lake-men passed north end of Long Lake 11 days after Smaug's fall.
- Chronology (her calculations, "highly speculative" except Apr 27, Midyear's Day, Sept 22 2941, May 1 2942): dep. Hobbiton Apr 27 11 A.M.; Trolls May 29; Rivendell June 4; leave Midyear's Day; captured by Goblins July 16; escape July 19; Carrock/Beorn July 20; leave July 22; Gandalf departs Jul 25; Enchanted Stream Aug 16; leave path Aug 22; spiders/Elves Aug 23–24; escape Sept 21; Lake-town Sept 22; depart Oct 9; leave river Oct 12; camps moved Oct 14/19; **Durin's Day Oct 30**; Smaug killed Nov 1; siege Nov 16; Arkenstone Nov 22; Battle of Five Armies Nov 23; leave Nov 27; Beorn's Dec 30–spring; Rivendell May 1; home June.
- Scale problem flagged: "Had the scale of the Wilderland map been about twice that of the rest of Middle-earth, the Dwarves' pace would have been nearer normal." Tolkien "was greatly concerned to harmonise Bilbo's journey with . . . The Lord of the Rings . . . but he never brought this work to a definitive solution" (VI 204).

### LotR: Bag End to Rivendell chapter
- Dep. dusk Sept 23; Crickhollow evening Sept 25; Bombadil's twilight Sept 26 (via Old Forest); Barrow-wight night Sept 28; Bree Sept 29 — last 4 miles road-plod from downs; dep. Bree 10 A.M. Sept 30; Midgewater Oct 2–4; Weathertop noon Oct 6 (half-hour climb to summit); attack that night; Weathertop→Last Bridge **120 miles in little more than 5 days** (Oct 7–12ish); Trollshaws wandering Oct 13–18 (two map variants, see §5); after Glorfindel: on until dawn Oct 19, then "almost twenty miles before nightfall"; Ford of Bruinen late afternoon Oct 20; Rivendell deep night.

### Rivendell to Lórien chapter
- Dep. dusk **Dec 25**; Hollin Ridge dawn **Jan 8**; foot of Redhorn Jan 11; snow midnight; retreat Jan 12, wolf attack; West-door of Moria 15 mi SW of the pass; reached past dusk Jan 13; Moria West-door→East-gate "at least forty miles... in a direct line" (Gandalf); nearly half covered by after midnight; 8-hour climb; Twenty-first Hall night Jan 14; Gandalf falls Jan 15; flee Moria 1 P.M., Nimrodel by early evening — "little more than five leagues from the Gates" (≈15 mi); Caras Galadon after dusk **Jan 17**.
- Dep. **Feb 16**, 10-mile hike to Anduin, then boats; drifting 3 days; Sarn Gebir ~midnight Feb 23; portage few miles Feb 24; Parth Galen evening **Feb 25**.

### Rauros to Dunharrow chapter (Three Hunters; Merry & Pippin)
- Fellowship broken noon **Feb 26**. Orc route Rauros→Fangorn ≈ **165 miles**; Orcs camped once in 60 hours; 5-hour lead widened to 36.
- Aragorn/Gimli/Legolas ran **45 leagues (135 miles)** in one night + three days, "twelve leagues each day on the plains."
- Treebeard carried the Hobbits "seventy thousand ent-strides" to Wellinghall = **100 miles at seven and one-half feet per stride** (note: Treebeard's stride only a third the length of the Tree-man seen by Hal, FR 53).
- Edoras dawn Mar 2; Helm's Deep battle night Mar 3–4; Isengard: camp at Nan Curunír mouth Mar 3(4), then "the last sixteen miles"; Dol Baran camp; Gandalf+Pippin to Edoras by dawn; Gandalf reaches Minas Tirith dawn **Mar 9**; Aragorn & Dúnedain reach Dunharrow dusk Mar 7; Théoden via mountain paths sunset Mar 9.

### Dunharrow to the Morannon chapter
- Paths of the Dead Mar 8; Morthond Vale "two hours ere sunset" same day; Erech just before midnight. Erech→Pelargir: "ninety leagues and three" (= 279 mi) BUT "the road ran almost three hundred sixty miles" (note 4: the stated distance "irreconcilable with the scale shown on Tolkien's map... It actually measures about 30 miles too long"). Dúnedain covered 10–30 mi/day more than Théoden's riders. Pelargir Mar 13; ships Mar 14; arrive battle midmorning Mar 15 (rowing then southerly wind, sailing).
- Rohirrim: Edoras→Minas Tirith stated **102 leagues (306 miles)** apparently straight-line; road ≈ 360 miles. Set out just after noon Mar 10; first camp "some twelve leagues (36 miles) east"; ~**80 miles/day**; Eilenach camp Mar 13; Stonewain Valley; Grey Wood; last "seven leagues (21 miles)" to the Rammas before dawn Mar 15.
- Host of the West: dep. Mar 18; infantry halt 5 mi east of Osgiliath; Cross-roads; Mar 20 north "some hundred miles" to the Morannon (note 11: 100 mi shown; 8–10 added by leaving road Mar 23; compromise with TT 256 "nearly thirty leagues" = 90 mi); ambush near Henneth Annûn Mar 21; Morannon morning **Mar 25**. Force: 1000 cavalry + 6000 infantry; 1000 detached (Cross-roads guard + Cair Andros force); remainder faced "forces ten times, and more than ten times their match."

### Journey of Frodo and Sam chapter
- Cross Nen Hithoel afternoon Feb 26; Emyn Muil toil to Feb 29 (descent gully, capture of Gollum); Dead Marshes dawn Mar 1; SE edge by dawn Mar 2; Noman-lands 2 nights; slag heaps ("piled for twelve nights" of marching between there and Morannon — i.e., extensive); 1 mile from western Tower of the Teeth before Mar 5.
- Morannon→Cirith Ungol detour: Gollum's "thirty leagues (90 miles) south"; first night "eight leagues (24 miles)" to turn the mountain corner; N Ithilien Mar 6–7; stream by Henneth Annûn daylight Mar 7; "somewhat less than ten miles" downstream to the refuge; south Mar 8–9; Cross-roads sunset **Mar 10 (Dawnless Day)**; Morgul Vale, Straight Stair (if 600 ft direct, ~900 ft of stair), Winding Stair, rest dawn Mar 11 (slept 24+ hrs); Shelob's Lair entered Mar 12, escaped east end late Mar 13 — tunnel shown ~**12 miles** ("Tolkien's drawings seemed to indicate the passage was far shorter, but the chronology required the distance"); apparently 30+ hours inside. Tolkien note quoted: "It might be a good thing to increase the reckoning of the time that Frodo, Sam, and Gollum took to climb Kirith Ungol by a day . . ." — Tale of Years agrees, final text never fully clarified.
- Ephel Dúath width on Tolkien's map "little more than twenty miles" yet three nights and days pass — flagged discrepancy.
- Escape Tower before dawn Mar 15; north along Morgai valley: by dawn Mar 17 "about twelve leagues north from the bridge" (36 mi); road to Isenmouthe dusk Mar 18: 12 miles, then overtaken, forced 8 more at "brisk trot"; Mar 19 "a few weary miles"; then ~40 miles on the causeway road in slightly under 3 marches; **Mar 22** drew even with Mount Doom, turned south; Mountain's foot Mar 24; **Crack of Doom morning Mar 25**.

### Road Home chapter
- Minas Tirith dep. Jul 19 (Théoden's bier); Edoras Aug 7; Helm's Deep Aug 14+2 days; Isengard Aug 22 (Fellowship separates); Saruman met in Dunland Aug 28 (Hobbits "riding round twice as far" as Saruman's route to the Shire); west of Moria Sept 6 (+1 week); Rivendell Sept 21–Oct 5; Bree evening Oct 28; Brandywine Bridge evening Oct 30; **22 miles** to Frogmorton Nov 1; Bywater Nov 2; Battle of Bywater & Bag End Nov 3. Frodo to Grey Havens: dep. Sept 21 F.O. 1, firth of Lune Sept 29.

### Army sizes (battle chapters)
- Battle of the Hornburg (Mar 3–4): Théoden/Éomer 1000 cavalry; Gamling 1000 infantry (Helm's Deep, Erkenbrand had left "maybe a thousand fit to fight on foot"); Erkenbrand 1000 infantry via Gandalf; Huorns "hundreds and hundreds". Totals: 2000 on Mar 3; est. 3800 Mar 4 (2700 fighting) + Huorns. Saruman "ten thousand at the very least" (Merry); defenders "at best outnumbered five to one." Théoden's dawn sortie ~900.
- Pelennor Fields (Mar 15) — her estimate table: Gondor & allies: Lossarnach (Forlong) 200; Ringló Vale (Dervorin) 300; Morthond (Duinhir) 500 bowmen; Anfalas (Golasgil) 150 est.; Lamedon 50 est. hillmen; Ethir Anduin 100 fisher-folk; Pinnath Gelin (Hirluin) 300; Dol Amroth (Imrahil) 1200 est.; Guard of Minas Tirith (Denethor) 2000 est.; Rohirrim 6000 cavalry; Aragorn's Dúnedain 30; southern-fief troops with Aragorn 1000 est. → **TOTAL ≈ 11,250**. Mordor & allies: Mordor/Morgul-host (Angmar/Gothmog) 20,000 est.; Haradrim 18,000; Rhûn/Khand 7000 est. → **minimum 45,000** (≥4:1). Southern fiefs held back "all but a tithe"; outcompanies "less than three thousands"; Tower Guard ≥3 companies of 400–500 each.
- Morannon (Mar 25): 7000 marched (1000 cavalry/6000 infantry), 1000 detached; enemy 10×+.
- Five Armies: Dáin "five hundred grim dwarves"; Elvenking ≥1000 spearmen + archers; Bard's men possibly as few as 200 (Lake-town could house ~400+); enemy "a vast host."
- Battles in the North (Mar 11–30): Lórien attacked Mar 11, 15, 22; Wold Orcs routed by Ents Mar 12; Mirkwood battle Mar 15; Battle of Dale Mar 15–17, siege of Erebor till Mar 27.
- Nirnaeth: Turgon's Gondolin force 10,000, "probably doubled the strength in the west"; Maedhros delayed five days.
- Bywater (Nov 3, 3019): ~200 Hobbits + 100 from Tookland vs. 100+ ruffians (first skirmish ~20 Men); ~70 ruffians killed, buried in the Battle Pit.
- Dunharrow (early conception): feast-hall cavern for 500 Riders / meeting hall for 3000 (HoME VIII).

---

## 3. REGIONAL DIMENSION & ELEVATION CLAIMS (every figure)

### First Age / Beleriand (chapters: First Age; Beleriand and the Lands to the North; Thangorodrim and Angband; site chapters)
- Cuiviénen→west journey: "in excess of 2000 miles" (est. from Ambarkanta map).
- Beleriand distance list: see §1 registration (Menegroth–Thangorodrim 150 leagues = "about 450 miles"; Sirion 130 leagues; Narog 80; Gelion 260; East Beleriand width 100 leagues; Dorthonion 60 leagues E–W; Nargothrond–Ivrin 40; Nargothrond–Falls of Sirion 25).
- **Thangorodrim**: cliff above the door "only 1000 feet high" — "two-thirds that of our tallest modern building"; but the central tower per Tolkien's Tol Sirion drawing "would have to have been at least five miles in diameter at the base and some 35,000 feet high!" (vs. Everest 29,028 in her note); "the highest peak in Middle-earth"; "mightiest towers of Middle-earth"; Second Silm. Map shows it "almost as an 'island' of foothills around the three tall peaks, jutting out one hundred miles from where the curve of the Iron Mountains must lie." Built of slag and tunnel refuse; volcanic triple black peaks.
- Angband interior per Lay of Leithian: 10,000 smiths; "labyrinthine pyramid."
- Sirion underground: reissues "three leagues south (nine miles)" below Andram; Elves originally forded Narog 25 miles north of Nargothrond; Amon Ethir 1 league east of Nargothrond's doors.
- Ossiriand: no Gelion tributaries for forty leagues north of Ascar.
- **Gondolin**: Amon Gwareth shown 400 ft high, flat-topped; Tower of the King equally high, turret 800 ft above the Vale; city built in 52 years, occupied ~F.A. 104, fell 511 after 400 years of peace. Echoriath = collapsed volcanic caldera; Tumladen = drained lake floor.
- Menegroth: "square-mile area" of countless rooms, multiple subterranean levels; Hírilorn beech (largest beeches: trunks to 5 ft diameter, drip line 20× that).
- Linaewen: "probably only about twenty feet in depth."
- Hyarmentir: second-highest peak of Aman after **Taniquetil, "highest mountain in all of Arda."**
- Pelóri: highest mountains of Arda; steep seaward faces, gentle west slopes; raised higher after poisoning of Trees.

### Second Age (Second Age Introduction; Númenor chapters)
- Submergence of Beleriand: "The submergence of about one million square miles could have raised the level of the sea enough to produce drowned river mouths, embayments (such as near the later sites of Dol Amroth and the fortress of Umbar), and isolation of some higher areas into offshore islands (such as Tolfalas)."
- Ice Bay of Forochel: "The west end of the Ice Bay of Forochel aligned with the former location of the conjunction of the Ered Engrin and the Ered Luin and extended over 300 miles into the lower lands north and east."
- **Númenor**: "it measured 167,961 square miles—forty times the size of Hawaii's Big Island!"; Meneltarma "some 14,000 feet high," interpreted as volcanic (smoke/fire on two occasions); 5 peninsulas = Tarmasundar roots; NW–SE pitch, coastal cliffs on north shores of all peninsulas except SE. Great Armament: 39-day voyage; Elendil 4 ships, Isildur 3, Anárion 2.
- Vinyalondë (Lond Daer Enedh) built by Aldarion ~S.A. 750 "for lumbering and ship repair"; Umbar strengthened 2280; Pelargir built 2350. Númenórean relations: Days of Help 600–1700; Dominion 1800–3200; War 3200–3319.

### Third Age realms (Kingdoms of the Dúnedain chapter)
- **Arnor ≈ 248,540 square miles** (borders: down R. Lune & coast to Greyflood mouth; up Greyflood/Loudwater to Misty Mtns; west to Bay of Forochel).
- **Gondor direct rule ≈ 716,425 square miles; Harad(waith) possibly adding another 486,775** (west to Greyflood/Sirannon; north to Field of Celebrant; east to Sea of Rhûn; south to R. Harnen & coast to Umbar, excluding Mordor).

### The Shire (Shire chapter)
- Boundaries from stated distances: "from the Far Downs to the Brandywine Bridge, forty leagues (120 miles); and from the western moors to the marshes in the south, fifty leagues (150 miles). The latter was measured from northwest to southeast, for had the line run due north-south it would have ended in hills, not marshes. The total area was about **21,400 square miles**." Buckland added 2340; Westmarch F.O. 32.

### Mountains
- **Misty Mountains**: "north-south orientation of some 900 miles"; "orographic lifting, possibly to as high as 12,000 feet"; likely inspired by the Alps (Tolkien hiked them in 1911); alpine glaciation evidence (horns, troughs, Mirrormere as moraine-dammed lake); mithril only at Caradhras.
- **White Mountains**: "spanned some 600 miles, west to east"; "to have been snowcapped they must have been at least 9500 feet in elevation" (vs. Tolkien's early note that the then-'Black' Mountains were "not very high, but very steep on the north side"); the SW "knot" possibly "even higher than those of the Alps"; no passes (hence Paths of the Dead).
- **Ered Luin**: lower than Misty Mtns (lesser migration barrier); breached-anticline twin ridges; not snow-capped.
- Mordor's ranges: lower than White/Misty (no snow); trough between Ephel Dúath and Morgai fault-produced.
- Grey Mountains/Ered Mithrin: hypothesized Ered Engrin remnants (see §5).

### Mordor (Mordor chapter; Mount Doom chapter)
- **Udûn**: circular valley; caldera or ring-dike; "Imagine the original height of a volcano with a forty-five-mile base. This colossus would have towered almost 29,000 feet!"
- **Mount Doom (Orodruin)**: "only seven miles across and stood 4500 feet" — shoulders ~3000 ft "and half as high again its tall central cone"; 7-mile base gives "a very typical 20°" average slope; compared to Etna (11,000 ft, ~29 mi diameter base); composite/strato-volcano; Vulcanian-type eruptions; three fissures (S, W, E) venting the cone; Sammath Naur tunnel high in upper cone.
- **Sea of Nurnen**: "the bitter Sea of Nurnen (with its interior drainage) was salty"; Lithlad ash plain = the fertile farmable part; "great slave-worked fields" via dry-land farming (ash mulch). [No areal dimensions given.]
- Gorgoroth = lava plateau, higher than Udûn and Lithlad. Cirith Ungol pass "more than 3000 feet above the Cross-roads"; the Cleft ~3000 ft; steps beyond lair exit ~600 ft to the Cleft.
- Earlier conceptions: Gorgoroth originally extended almost to Nurnen; Cirith Ungol originally at the Gap of Gorgoroth (later Morannon site); Udûn/Isenmouthe/Morgai late additions; southern Ephel Dúath "originally bulging in two arcs nearly 150 miles wide toward Harad," narrow only at Nargil Pass.
- Dagorlad: stony pediment plain (arid indicator). Dead Marshes: grew during Third Age, swallowing Dagorlad graves (denudation → runoff → bracken swamps).

### Cities & sites
- **Minas Tirith**: Hill of Guard 700 ft ("look from its peak sheer down upon the gate seven hundred feet below"); White Tower of Ecthelion 300 ft (50 fathoms; her note 10), diameter ~150 ft, "two hundred feet lower than Orthanc"; city breadth averaged ~3100 ft (from comparing two Tolkien drawings); seven concentric walls, "over forty thousand linear feet," "more than two million tons of stone"; outer wall same black rock as Orthanc; Houses of the Dead domes "only slightly smaller than that of the Pantheon."
- **Orthanc/Isengard**: Orthanc "over five hundred feet high"; Ring of Isengard 1 mile rim to rim; rimwall ~100 ft or less; 27 entrance steps; Isengard 16 mi from mouth of Nan Curunír, 1 mi west of Isen; Orthanc = volcanic plug analog (Shiprock, NM); Saruman fortified after 2953.
- **Helm's Deep**: Deeping Wall shown 250 ft long, 20 ft high, four men abreast wide; Hornrock "no more than forty feet high"; Helm's Dike quarter-mile below the Burg, "a mile or more" across Deeping Coomb, a 20-ft cliff in places; Death Down 1 mi below the Dike; Aglarond limestone caverns (inspired by Cheddar Gorge per Letters 407); Hornburg tower lofty but "much lower than that of Minas Tirith."
- **Edoras**: lone foothill "like a sentinel"; dike + mighty wall topped by thorny fence; Barrowfield 9 kings' mounds (first line, Eorl–Helm) west + 7 (Fréaláf–Thengel, then Théoden) east; Meduseld completed by Brego T.A. 2569 [text prints 2969 — OCR; RK 349 basis].
- **Dunharrow**: Firienfeld "some hundreds of feet above the valley"; Snowbourn valley floor half-mile wide at the ford; refuge developed early Second Age; evolution of conception (see §5).
- **Erebor/Lonely Mountain**: summit snowcapped into spring → "possibly 3500 feet in elevation"; six radiating spurs; secret tunnel est. 2 miles long ("five feet high the door and three may walk abreast"), 3 hours' creep for Bilbo; Smaug ~60 ft long → hall ≥180 ft; hidden bay behind 150-ft overhanging cliff; western vale ~3 mi long; Front Gate center of south face.
- **Lake-town**: platform village ~"two city blocks," pop. potentially 400+; predecessor Esgaroth "larger city... on the same site... destroyed at some point (possibly by Smaug)," rotting pilings visible at low water; rebuilt "more fair and large" farther north.
- **Moria**: West-door→East-gate ≥40 miles direct; guardroom shown ~3900 ft deep; "The mines could have been as deep as 12,500 feet and still have been within limits reached in our Primary World"; Twenty-first Hall of the North-end; Second Hall/First Deep; West-door shelf "five fathoms" (30 ft) above riverbed; flooded valley ~3/8 mi falls→gate, ~2 mi end to end; Silvertine holds Endless Stair/Durin's Tower (her placement, west of Mirrormere).
- **Caras Galadon**: great mallorn "about four hundred feet in height and breadth, which is slightly larger than the tallest redwood" (UT 167: Númenórean mallorns taller still).
- **Weathertop/Amon Sûl**: "summit rose a thousand feet above the surrounding lowlands"; Weather Hills "almost a thousand feet" above landscape.
- **Bree**: ~100 stone houses; semicircular dike; at crossing of Great East Road & Greenway (old North Road, Fornost→Tharbad→Gondor).
- **Henneth Annûn**: falls est. ~80 ft; refuge 10 mi west of the road-pool (Faramir + map agree), cave held 200 men; conflict with Cormallen proximity noted.
- **Tower of Cirith Ungol**: three tiers — heights 100/75/50 ft, depths (top view) 40/30/20 yards; top roof 200 ft above the gate, 60 ft between turret and parapet; court 50 ft across; outer wall 30 ft, overhanging top.
- **Goblin-town**: see §2. **Beorn's hall**: ~20 × 35 ft (from trestle-table scaling); fireplace ~6 × 8 ft.
- **Barad-dûr**: built S.A. 1000–1600 (completed 1600); rebuilt in Third Age (Saruman fortified Isengard "in rivalry to the newly rebuilt Barad-dûr"); before its gates "the most barren land of all—a seething volcanic desert." [No height/size figure given anywhere in text.]
- **Brandywine**: "a major river, possibly comparable to the upper Mississippi"; too wide for a horse to swim.
- **Emyn Muil**: outer western ridge ~120 ft thick ("twenty fathoms" above the shelf); East Wall of Rohan sheer cliff; eastern gully end ~108 ft (18 fathoms); Sam's rope "thirty ells, more or less."
- **Rauros/Nen Hithoel**: three hills (Amon Hen, Amon Lhaw, Tol Brandir) left by downcutting; North Stair portage. Earlier map: Nen Hithoel 120 miles farther north (VI 314).
- **Anduin**: no total length stated anywhere; Osgiliath reach wide/deep enough for large vessels; the Undeeps = valley intersections with west bends (see §5). **Sea of Rhûn**: no dimensions given (Gondor's east border reached it; 1248 campaign destroyed camps east of it).

---

## 4. FIRST-AGE & COSMOLOGY MAPPINGS

### Arda world-model (Introduction; First Age chapter)
- Ambarkanta-based world maps ("In the original atlas the world maps were based strictly on analysis of the written text"; the revision remapped "the whole of Arda" using esp. HoME IV *The Shaping of Middle-earth*).
- Disk cosmology: Vaiya encircling seas; Kúma the Void; Vista domed airs; medieval-cartographer analogy; west-facing compass.
- Spring of Arda map: Almaren in the Great Lake "in the midst of the land"; lamps Illuin (N) and Ormal (S), pillars "mountains taller than any of later times"; **Ered Engrin "stretched in an unbroken curve from east to west"** far in the north; Utumno beneath them; Angband in the NW "facing Aman"; Belegaer narrower then.
- Fall of the Lamps: lands broken, Almaren destroyed; **Sea of Helcar formed by meltwaters of Illuin's pillar; "Cuiviénen was an eastern bay of the Inland Sea of Helcar"**; "Cuiviénen could not have been very far east of Utumno, for later, during the Siege, the Elves could see the light of battle in the north—not the west." [Ringil/Helcar pairing not named in this text; only Helcar used.]
- Orocarni = Mountains of the East, streams falling to Cuiviénen's Wild Wood.
- **Hildórien**: Men awoke there at first Sunrise; "That land, too, lay in eastern Middle-earth. From Hildórien Men spread west, north, and south."
- Siege of Utumno changes: Belegaer grew wide/deep; Bay of Balar & Great Gulf formed (Ambarkanta map's 'Great Gulf', also Beleglo[rn?]); "In the turmoils at the end of the First Age the shape of the gulf probably changed, joining the eastern end of the gulf with the inland Sea of Helcar, forming the later Bay of Belfalas." Dorthonion & Hithlum highlands raised; Ered Wethrin/Ered Lómin made from broken western Ered Engrin; Echoriath appears "as a gigantic active volcano"; Sirion formed.
- Hithaeglir raised by Melkor "to hinder Oromë's travels"; Ered Nimrais "probably lifted at the same time" (absent from Ambarkanta map). **"Notably absent from both map and text are the mountains of Mordor. That land would later lie in what now was the Sea of Helcar."** Second Age intro: "Although no text supports my conclusions, Mordor might have appeared as part of a worldwide upheaval during the destruction of the Iron Mountains in the area where the Great Gulf partially drained the Inland Sea."
- Ered Engrin fate: unroofing of Utumno partially changed them (her map assumption); "the final destruction of all but a few remnants must have occurred later, possibly in the War of Wrath"; never mentioned/mapped by Tolkien after the First Age.

### Valinor (Valinor chapter)
- "Distances not only were not given, they were meaningless" (Valar as spirits) — composited "a few swift strokes" into drawings of east-central Valinor & scattered locations; Valinor excluded from the standard bar scale.
- Layout: Pelóri raised as fence; barren shadowed east coastlands — Avathar (S, narrower) & Araman (N); Oiomúrë mists near Helcaraxë; Calacirya the only pass, cut to light Tol Eressëa; Shadowy Seas north & south of the light-fan; Tirion on Túna in the Calacirya "near the girdle of Arda"; Taniquetil south of the great canyon; Hyarmentir far south (Ungoliant's ravine); Valmar of Many Bells mid-plain (Tulkas's many-storied home, Oromë's low halls, Aulë's great court outside the golden gates); Mahanaxar (Ring of Doom) & Ezellohar with the Two Trees outside the gates; Formenos in the hills of the north; pastures of Yavanna west of the Woods of Oromë; Nienna "west of West" near Halls of Mandos (caverns reaching Hanstovánen, "the dark harbor of the north: site of the Prophecy of Mandos"); Gardens of Lórien with lake Lorellin; Ilmarin on Taniquetil; Alqualondë north of the pass, harbor entered through "an arch of living stone"; Tol Eressëa — Avallónë built end of First Age on south shore; Lost Tales layer mapped in inset: Kortirion/Koromas in Alalminórë.
- Enchanted Isles set beyond Aman after the raising of the Pelóri; Shadowy Seas widened (Second Age map).

### The Great March (Great March chapter)
- Route drawn: Cuiviénen → along **north shore of the Sea of Helcar** (black clouds of Utumno visible; some desert) → "possibly along the very path that later became the Old Forest Road" → through Greenwood the Great → east bank of Anduin (Teleri camp long) → over Misty Mountain passes → Eriador → "it was most likely that the Great East Road had its origins in this path of great antiquity" → crossing Sirion → coasts between Bay of Balar and Firth of Drengist.
- Southern route rejected: "Oromë probably did not lead them south, because another, greater barrier existed there—dense forests. Treebeard said that woods had once extended from the Mountains of Lune to the east end in Fangorn."
- Ered Luin crossing: "The pass lay in the upper vales of the River Ascar—where later the mountains broke apart and formed the Gulf of Lune."
- Nandor: Lenwë's Teleri south down Anduin; some through Gap of Rohan into Eriador; ancestors of Silvan Elves of Mirkwood & Lórien; Denethor's people over the mountains into Ossiriand (Laiquendi).
- Time depth: Hithaeglir "taller and more terrible in those days" → "Half a million years would hardly be sufficient" for erosion to lower the peaks noticeably.

### Beleriand ↔ Third-Age overlap (First Age ch.; Second Age Introduction)
- Registration quote: see §1 (Tol Fuin/Dorthonion, Himling/Himring alignment; Blue Mountains curvature match).
- Remnant quote (Second Age intro): "As Beleriand was destroyed, many retreated to the highlands, and as the waters lapped the hills, they built ships in which to set sail. **The last fragments of Dorthonion and the Hill of Himring remained as Tol Fuin and Himling: the Western Isles.**"
- **Tol Morwen**: "the low-lying graves of Túrin and Morwen withstood the turmoils as foreseen. Although Tol Morwen was described as 'alone,' it was perhaps the 'last' (most western) of the remaining lands."
- Lindon "the only portion of Beleriand that survived as part of the mainland, although Mount Dolmed and Rerir were both absent. At the River Ascar the Blue Mountains broke apart and the sea roared in, forming the Gulf of Lhûn." River Lhûn changed course (previously shown flowing east into Lake Evendim). "It was possible that the Tower Hills and the west-east ridge of the Ered Luin were newly formed at that time." Nogrod destroyed (probably collapsed); Belegost "apparently survived"; Dwarves to Moria S.A. 40.
- Post-Númenor changes: logic suggests bigger upheaval than Thangorodrim's fall, and Tolkien attempted rewritings (V 153–154), "Nevertheless, extensive writings were already in existence, in which most of the major features had already been mentioned... It has been necessary, therefore, to map few, if any, of the physical variations" — except forests (cut-over) and marshes (spreading).

---

## 5. INTERPRETIVE CHOICES WHERE SOURCES CONFLICT (with her reasoning)

1. **Thangorodrim location** (Beleriand ch.): text says 150 leagues from Menegroth "far, and yet all too near"; originally she mapped it beyond the north border; revised southern placement per First & Second Silm. maps. Six supports for reading 150 leagues "as the wolf runs" (bypass of Dorthonion; visible from Eithel Sirion; Tol Sirion drawing shows it near; Fingolfin's 7 days Helcaraxë→Mithrim; fast plain crossings; "Angband was beleaguered from the west, south, and east"). Notes Christopher Tolkien's unease that the southern site makes the Menegroth distance "scarcely more than seventy" leagues.
2. **Ered Engrin survival** (First Age; Wilderland): assumption that mountains only partially changed at Utumno's unroofing; **Grey Mountains as remnants** — three clues: (1) alignment once Thangorodrim fixed ("the approximate position of the Iron Mountains aligned perfectly with this later range"); (2) "North of the Ered Engrin lay the 'Regions of Everlasting Cold.' North of the Ered Mithrin was the 'Northern Waste.' These may have been synonymous"; (3) "Dragons bred in the Withered Heaths even before the coming of Thorin I... Ores long held the area around Mt. Gundabad. Both of these were creatures of Morgoth, and with the breaking of Thangorodrim, the most likely relocation for them would have been in any remaining portions of the Iron Mountains."
3. **Nogrod/Belegost placement** (note 54): "VII, 302 showed Belegost in this southern location, and IV, 220 indicated two alternate Dwarf-road routes; so the southern placement was shown in spite of IV, 232 and 335 which explained the editorial change on S, Map placing the cities further north."
4. **Beleriand south coast**: extrapolated 260 leagues down Gelion assuming continued SW flow; coast brought near Bay of Belfalas line; forested by analogy to Taur-im-Duinath.
5. **Menegroth**: assumed hand-cut, not natural caverns (wrong bedrock north of Andram) — "At first thought this might seem unlikely, until one remembers Khazad-dûm."
6. **Nargothrond doors**: Tolkien drew both 3-door and 1-door versions; "The text always referred in the plural to the Doors of Felagund, so three have been included here."
7. **Mordor origin**: own hypothesis, flagged "Although no text supports my conclusions" (uplift where Great Gulf drained Helcar).
8. **Trollshaws bridge/stream (Hobbit vs LotR)**: Dwarves reached Trolls ~1 hour from a river with (post-1960-revision) a stone bridge; Strider took ~6 days from the Last Bridge. 1960 unpublished rewriting explains; her solution: two variants mapped, incl. Strachey's — "interpreting the events to have occurred by a lesser stream (unmapped by Tolkien) closer to the Bruinen, and ignoring both the presence of the bridge and the statement that the river's source was in the mountains." Wilderland map scale would need ~2× to normalize Dwarves' pace.
9. **Bruinen course & East Road curves** (Misty Mtns ch.): 1st vs 2nd edition text discrepancy ("for many leagues to the Ford" vs "along the edge of the hills"); Christopher Tolkien quoted: "In 1943 I made an elaborate map . . . the course of the Road from Weathertop to the Ford is shown exactly as on my father's maps, with the great northward and southward swings. On the map that I made in 1954 . . . however, the Road has only a feeble northward curve . . . and then runs in a straight line to the Ford." Atlas restores original curving intent from two HoME sketch maps.
10. **Barrow-downs orientation** (Eriador; On the Barrow-downs): textual clues say scarps face south, ridges run E–W; "This orientation, however, conflicts with the circular pattern of downs shown on the map, as well as with processes found in the real world... As a compromise, the long axis has been illustrated as trending from northwest to southeast—a reasonable explanation in view of the distinct southwesterly flow of the Withywindle." Bombadil's house faces west because the Withywindle cut into the cliff.
11. **Shire villages**: unmapped settlements assumed beyond map edges; placements reasoned from names/history — Hardbottle ("hard dwelling") put on White Downs south end (Bracegirdle tobacco lands + S. Farthing connection); invented-village caveat: "Another village associated with the Sackville-Bagginses was never mentioned by Tolkien: Sackville... The final product, although not authenticated, helps show the Shire as it was." Tighfield/Gamwich in West Farthing (ropewalk; migrations); Longbottom near Sarn Ford shipping route to Saruman.
12. **Bree** name: "bree meant 'hill'... but it may also have been a dual play on words... bree is also Scottish for 'liquor' or 'broth'—both of which were served by Butterbur."
13. **Lake-town/Esgaroth/Dale**: Esgaroth = earlier larger city on same site, destroyed "possibly by Smaug"; Dale placement "based on Thrór's Map (H, 7), and the description on H, 255, rather than on P, 18" (note 3).
14. **The Undeeps** (Brown Lands ch.): explained structurally — valleys between the Wold and in-facing Downs escarpments intersect the Anduin's west bends, creating the North & South Undeeps "utilized by both the Balchoth and the Éothéod for easier river-crossing."
15. **Emyn Muil/Nen Hithoel evolution**: four successive Tolkien map designs; Nen Hithoel originally 120 mi north; Sarn Gebir name migrated from hills to rapids only.
16. **Mordor internal geography evolution** (Mordor ch.): Gorgoroth originally reached almost to Nurnen; Cirith Ungol originally at the Gap of Gorgoroth (later Morannon site); Udûn/Isenmouthe/Morgai and the east/west ranges "all absent until late in the story"; Lithlad kept "east of Gorgoroth, south of the Ash Mountains"; southern Ephel Dúath originally two arcs ~150 mi wide toward Harad, Nargil Pass at the southern feeder river of Nurnen.
17. **Henneth Annûn contradiction**: 10 mi west of the road (Faramir; map agrees) "yet Henneth Annûn was supposed to have been so near the Field of Cormallen on the banks of the Anduin that the noise of the waters rushing through the gate upstream could be heard."
18. **Shelob's Lair length**: shown ~12 miles though "Tolkien's drawings seemed to indicate the passage was far shorter, but the chronology required the distance." Stairs order (Straight/Winding) reversed by Tolkien mid-writing "apparently without even realizing he had done so."
19. **Cirith Ungol tower**: Tolkien's sketch round with four tiers; text: "it jutted out in pointed bastions... that looked north-east and south-east" — "The accompanying map has been made to agree with the text in this respect."
20. **Orthanc conception**: earliest drawings man-made multi-tiered on an island; latest, the rock itself is the tower; "a brief note indicated the true final vision was never drawn: a combination of the earliest and latest views" ("a peak and isle of rock").
21. **Minas Tirith bastion**: the ship-keel pier "absent from Tolkien's drawings"; "The cross section shows a position midway between the text and the drawings." White Tower a "spike," not tiered as in VIII 261/P 27 (note 10); 'King's House' initially misread as 'kitchen,' corrected by Taum Santoski (note 25).
22. **Dunharrow evolution**: originally the Firienfeld was the "lap" before a natural amphitheater Hold with caverns (500-rider feast hall), nothing supernatural; Snowbourn originally flowed over the field; later versions renamed the south peak Starkhorn, added Irensaga, wedged the Firienfeld between, added the Dimholt/Dark Door.
23. **Frodo/Sam Cirith Ungol chronology**: Tolkien's note "It might be a good thing to increase the reckoning of the time... by a day"; Tale of Years agrees; "for once Tolkien seems to have not completely clarified the change in the final text" → 30 hours in the Lair on her reconstruction.
24. **Stated vs. measured league conflicts**: Dunharrow–Minas Tirith 102 leagues "irreconcilable with the scale shown on Tolkien's map... It actually measures about 30 miles too long" (note 4); Erech→Pelargir 93 leagues vs ~360-mile road; Minas Tirith→Morannon 100 mi (RK) vs "nearly thirty leagues" (TT) — compromise shown.
25. **Edhellond**: mentioned as "the havens of Edhellond near Dol Amroth" (Third Age intro); note: "Some of those from Doriath may have established Edhellond, UT, 247."
26. **Mithlond**: note 13 (Refugee Relocation): "'Mithlond' may only be the bay, while Forlond and Harlond are the actual Grey Havens (V, 423)."
27. **Angmar**: realm mapped "north of the Ettenmoors... on both sides of the mountains" (Battles ch.); climatically, "around the Ice Bay of Forochel, Morgoth's cold lingered and was worsened at one time by frosts of Angmar," only 100 leagues north of the Shire.
28. **Forochel**: Lossoth camp on western shores of the Ice Bay; Arvedui's flight to a deserted Dwarf-mine in far-north Blue Mountains; bay's 300-mile extension aligned with Ered Engrin/Ered Luin junction (§3).
29. **Umbar**: coastline continuity argument — post-Downfall coasts "may not have been re-formed sufficiently to be evident on a world map, for the havens... were still present in later times—notably Umbar"; embayment at Umbar from Beleriand's submergence; strengthened 2280; besieged/won by Gondor 933, held 117 years against enemies; retaken 1810.
30. **Khand/Harad**: appear as allies of Mordor (1944 Wainrider alliance with Khand & Near Harad; Pelennor allies Near & Far Harad, Khand, Rhûn); Haradwaith a conquered tributary of Gondor (~486,775 sq mi).
31. **Fangorn/Entwash**: Entwash sources at Methedras springs; "large inland delta" explained as slope-break deposition, not muddiness; Nindalf not discussed in text (index only).
32. **Lórien extent**: "Most of the land of Lórien lay east of the Silverlode in the area known as the Naith or Gore"; Cerin Amroth "the heart of the ancient realm as it was long ago"; Fourth Age: Celeborn's "East Lórien" south of The Narrows in Mirkwood; "in Lórien there lingered sadly only a few of its former people."
33. **Goblin-gate/eagle eyrie**: clearing placed south (not east) of the eyrie, since the eyrie stood "atop 'a lonely pinnacle of rock at the eastern edge of the mountains'... at the far end of an east-running ridge."
34. **Old Forest/Barrow-downs history**: downs used as burial ground "even in the First Age by the forefathers of the Edain before they entered Beleriand"; refortified as Tyrn Gorthad; Cardolan's last refuge; after Great Plague inhabited by "spirits from Angmar—the Barrow-wights."
35. **Weathertop area**: forts of Arnor along the Hills, refortified after Rhudaur fell; tower burned 1409; three realms' corner at Weathertop; Rhudaur/Cardolan enmity over its palantír.
36. **NOT DISCUSSED in the prose** (index-only or absent in this text): Dorwinion (index L-41), Rhosgobel (index K-36, 'Brownhay'), Nindalf (index), East Bight (index), Framsburg (index I-35), Langwell/Greylin Anduin sources (not treated), the beacons (only "beacon-hills huddled close to the northern cliffs," Landforms ch.; Amon Dîn/Halifirien in index), Andrast/Drúwaith Iaur (index; Drúedain population noted in Population ch.: forefathers of the Wild Men, a few "reportedly had even moved into Brethil," UT 377–378 note), Enedwaith/Minhiriath deforestation (only: Númenórean lumbering "greatly amplified" Second Age cutting; Enedwaith "In the days of the Kings it was part of the realm of Gondor, but it was of little concern to them"; Minhiriath hard-hit by Plague), Tharbad (Stoor settlement ~T.A. 1150 area; North Road to Tharbad), Swanfleet (index only), Tolfalas (offshore isolation via submergence), Cair Andros (military references only), Ethir Anduin (100 fisher-folk at Pelennor; 830 coastal extension east of Ethir), Dol Amroth/Belfalas (embayment origin; Edhellond nearby; rugged coast near Dol Amroth; fair green coastlands of Belfalas/Anfalas from coalescing alluvial valleys).

---

## 6. CLIMATE / VEGETATION / POPULATION / LANGUAGES (Thematic Maps chapters)

### Climate
- Köppen-like classes with Primary-World analogies: Humid mild winter/mild summer = England, N-Central Europe, W Oregon; mild winter/hot dry summer = Mediterranean, S California; mild→severe continental = E Europe, Arkansas→Wisconsin; Arid = Arabia/W Arizona/Nevada; Semi-arid = Iran/Great Plains (E Colorado); Tundra = north coasts of USSR/Alaska/Canada; Ice cap = central Greenland.
- "The Known Lands of Middle-earth were probably about the latitude of Europe, for Europe lies in a belt of prevailing westerly winds, as did Middle-earth" (west-wind citations: Nevrast, Shire, Barrow-downs, Trollshaws, Lonely Mtn, Gondor, Mordor post-Pelennor).
- Marine West Coast climate assigned to northern Númenor, Beleriand, most of Eriador; "giving the Shire the climate of England." Valinor exempt from physical controls; Tirion near the girdle of Arda warm year-round; Oiomúrë fog = warm seawater vs Grinding Ice.
- "Only 100 leagues north [of the Shire], around the Ice Bay of Forochel, Morgoth's cold lingered and was worsened at one time by frosts of Angmar" — true of all the Northern Waste.
- East of Misty Mtns: continental; Aragorn quote "[We] are far from the sea. Here the world is cold until the sudden spring." Rohan normally mild (late Feb); Long Winter snow Nov–Mar.
- No rain-shadow steppe east of Misty/White Mtns (forests instead, "perhaps due to less evaporation in the cooler air of the north").
- Arid: Noman-lands ("aridity may have been due to noxious fumes rather than to lack of precipitation"); possible Mediterranean dry-summer pattern around Bay of Belfalas; Nurnen's bitterness + Dagorlad pediment "reinforce the probability of Mordor's being climatically arid as well as chemically denuded."
- Supernatural climate overlays: "good powers living in unusually warm, gentle climates (notably in Valinor and Lórien); and the evil powers of Morgoth, Sauron, and Angmar producing cold, bitter climates."
- First Age: Ered Engrin "in the borders of everlasting cold," impassable snow/ice; Lammoth wasteland by bitter winds; Ard-galen/Lothlann probably steppe (dry, cold, streamless grass) → after Bragollach, Anfauglith desert with dunes ("the sod could never reestablish itself, due to the poisonous airs of Thangorodrim"); Hithlum cold winters; Himring "ever-cold"; Aglon funneled north winds.

### Vegetation
- Primeval forest: Treebeard — once "from here [Fangorn] to the Mountains of Lune"; also west of Ered Luin and east of Anduin. By start of Third Age "only the Old Forest, Fangorn, and a few scattered woods continued as remnants" (cutting begun 1st Age, "greatly amplified during the Second by the lumbering activities of Númenor").
- Forest types: S Mirkwood "a forest of dark fir"; oak & beech stands near Thranduil; Old Forest/Fangorn dark, tangled but less dense than Taur-im-Duinath; Doriath: Nivrim oaks, Neldoreth beeches, Region denser mixed; beech stands = "green cathedrals"; mallorn ≈ giant beech (Treebeard's malinornélion = "gold beech tree"); conifers nearly absent except S Mirkwood + N/W Dorthonion edges + high Rivendell valley + wolf-clearing area.
- Grasslands: tall-grass prairies Ard-galen, Lothlann, Rohan (horse pasture); short grass on Himring hills, Downs, Weather Hills, Wold.
- Wastelands: thorn thickets replacing pines north of Dorthonion post-Bragollach; Hollin & S Dunland become waste after Ost-in-Edhil's fall and Saruman's turn; twisted birches E Emyn Muil; thorns in Morgai trough. Total deserts: doors of Angband, Desolation of the Dragon (Erebor), Desolation of the Morannon, Brown Lands ("blasted... not even grass"), and before Barad-dûr "the most barren land of all—a seething volcanic desert."
- Marsh spread: fens of E Mirkwood after Smaug; Dead Marshes swallowing Dagorlad graves.

### Population (relative densities only — "With little data given, only relative densities have been shown")
- First Age (Long Peace): Sindar & Green-elves "far more numerous" than returning Noldor; Noldor in the highlands; empty zones: Lammoth, Ard-galen, Lothlann, Nevrast (post-Turgon), central Dorthonion, Dimbar, Nan Dungortheb, marshes, Taur-im-Duinath. Dwarves at Nogrod/Belegost ("their presence [in Beleriand] was transitory"); Ents in the forests; Men: Estolad, NE Dorthonion (Ladros), Brethil, Hithlum/Dor-lómin; east of Ered Luin: ancestors of Rhovanion Northmen, Wood-men, Beornings, Dale-men; separate-origin Men in White Mtn dales → Dunland → Bree; Drúedain; Forodwaith in the icy north (ancestors of the Lossoth); Rhûn & Harad.
- Second Age: Númenor — Arandor (Kingsland: Armenelos + Rómenna) densest; Andúnië large early, declining; west ports & south fisher-villages; rural bulk; empty: Meneltarma, bleak northern hills, southern marshes.
- Third Age: "Middle-earth's population at the end of the Third Age was extremely sparse." Elves only NE Mirkwood, Lórien, Rivendell, Grey Havens. Dwarves: Blue Mtns, Iron Hills, Erebor. Arnor "virtually depopulated by war and plague"; in all Eriador "the only apparent settlements were those in the Shire and at Bree—the area beyond was called the Lone-lands"; Lossoth in extreme north [text misprints "Lammoth"]; folk in southern Dunland and along the coast. Gondor better: cities + lands south of White Mtns, coasts, mountain vales. Rohirrim: concentrations near Edoras & Westfold Vale; Wold mainly pasturage. Men increased in upper Anduin vales & near Erebor; east of Mirkwood; Easterlings/Southrons beyond Sea of Rhûn, in Khand, Harad, "especially Umbar." Orcs: few after Five Armies, multiplying again 77 years later; Saruman's army; Dol Guldur reoccupied; NW Mordor "filled with vast, seething hosts."
- Underpopulation as literary effect: "Middle-earth seemed tremendously underpopulated in the western lands, and this increased the sense of loneliness and isolation."

### Languages
- Quenya & Sindarin most complete; Silvan, Entish, Khuzdul ["Khazâd"], Mannish tongues, Black Speech glimpsed. Westron formation: Adûnaic (tongue of the Third House, Men of Dor-lómin, enriched with Elvish) mixed in Belfalas-bay colonies with Southern Mannish → "this conglomeration of Sindarin and Northern and Southern Mannish became Westron, the 'Common Speech.'" End of Third Age languages list: Westron, Sindarin, Silvan, Entish, Rohirric, Dunlending, Drúedain, Easterling/Southron tongues, Orkish dialects, Black Speech.

---

## MISC USEFUL DATA POINTS
- Second Age chronology used: Sauron reawoke ~S.A. 500; into Mordor ~1000; rings begun ~1500; Three made by Celebrimbor alone to 1590; One Ring forged soon after; war 1695–1700 (Eregion falls 1697; Imladris founded; Tar-Minastir's fleet 1700); Barad-dûr completed 1600; Númenor falls 3319; Realms in Exile 3320; Last Alliance war 3429–3441 (Dagorlad "days and months"; 7-year siege; Sauron comes forth 3446 [sic in text]).
- Third Age key data: division of Arnor 861 (Arthedain/Cardolan/Rhudaur; all met at Weathertop); Angmar appears ~1300; Amon Sûl falls 1409; Great Plague 1636–37 ("more than half of the folk of Rhovanion had perished"); Wainriders 1851–1944; Fornost falls 1974; Angmar defeated 1975; Minas Ithil falls 2002; Eärnur lost 2050; Watchful Peace 2063–2460; Osgiliath bridge broken & city finally ruined 2475 (palantír lost in river 1437 when Tower of the Stone fell in Eldacar's Kinstrife siege — "It was even possible that the bridge was the citadel, for towers and stone houses stood upon it"); Balchoth/Field of Celebrant 2510 (Éothéod crossed at the Undeeps); Long Winter/Days of Dearth 2758–60; Dwarf-Orc war 2793–99; Smaug takes Erebor 2770; Erebor kingdom founded 1999; Grey Mtn Dwarves 2210–2570; Balin to Moria 2989.
- Palantíri placement: Annúminas, Amon Sûl, Elostirion (Tower Hills); Orthanc, Minas Ithil, Minas Anor, Osgiliath.
- Osgiliath: Anduin wide/deep enough for large ships at the quays; walled causeway roads from Minas Anor & Minas Ithil; great bridge with houses/towers.
- Moria founding: Durin discovered caves above Azanulbizar; Balrog released T.A. 1980 (hidden "almost 5500 years").
- Hobbit migrations: ancestral lands upper Anduin vales between Gladden & Carrock; Harfoots west T.A. 1050 (some to Weathertop); Fallohides & Stoors ~1150; Stoors to Tharbad/Dunland; 1300 flight from Angmar (some Stoors to Gladden — Sméagol's people); Bree & Staddle chief early settlements; Shire colonized 1601 from Bree; Dunland Stoors joined 1630.
- Rivendell: founded S.A. 1697 by Elrond.
- Thranduil's halls modeled on Menegroth ("lived with Thingol"; UT 259): wooded hill, river, stone bridge, magic gates, pillared hall, cells; underground stream unique.
