# A13c — Fonstad Atlas: Dimensions, Elevations, Areas
All [Fonstad-derived] figures; cites = Atlas chapter.

## First Age / Beleriand
- Cuiviénen–west journey: >2000 mi (Ambarkanta-map estimate). (First Age ch.)
- Beleriand text distances (leagues, x3 for mi): Menegroth–Thangorodrim 150 (450 mi); Dorthonion E–W 60; Nargothrond–Ivrin 40; Nargothrond–Falls of Sirion 25; Sirion–Gelion width 100; R. Sirion 130; R. Narog 80; Gelion confluence–Ascar 40; Gelion total 260. South coast drawn 260 leagues from Gelion sources. (First Age ch.)
- Thangorodrim: gate-cliff 1000 ft; central tower ≥5 mi base diameter, ~35,000 ft high (from Tol Sirion drawing); "highest peak in Middle-earth"; foothill 'island' juts 100 mi from Iron Mountains curve (2nd Silm. Map). (Thangorodrim ch.)
- Angband: 10,000 smiths (Lay of Leithian). Sirion underground 3 leagues (9 mi). Narog ford 25 mi north of Nargothrond; Amon Ethir 1 league east. Ossiriand: no Gelion tributaries for 40 leagues north of Ascar. (Beleriand ch.)
- Gondolin: Amon Gwareth 400 ft, flat-topped; King's Tower turret 800 ft above the Vale; built 52 yrs, occupied ~F.A. 104, fell 511. Echoriath = collapsed caldera; Tumladen = drained lake bed. (Gondolin ch.)
- Menegroth: ~1 sq mi of delvings, multi-level. Linaewen ~20 ft deep. (Menegroth; Beleriand chs.)
- Taniquetil: "highest mountain in all of Arda"; Hyarmentir next highest in Aman. Pelóri highest range of Arda. (Valinor ch.)
- Misty Mtns in First Age "taller and more terrible"; half a million years insufficient to erode them notably. (First Age ch.)

## Second Age
- Beleriand submergence: ~1,000,000 sq mi; produced embayments (Dol Amroth, Umbar sites) and islands (Tolfalas). (2nd Age intro)
- Ice Bay of Forochel: extends >300 mi; west end aligns with old Ered Engrin/Ered Luin junction. (2nd Age intro)
- Númenor: 167,961 sq mi ("forty times... Hawaii's Big Island"); Meneltarma ~14,000 ft, volcanic; 5 peninsulas; NW–SE pitch, north-shore cliffs. Great Armament voyage 39 days; Elendil 4 + Isildur 3 + Anárion 2 ships. (Númenor; Voyages chs.)
- Vinyalondë/Lond Daer built ~S.A. 750 (lumbering/ship repair); Umbar fortified 2280; Pelargir built 2350. (Voyages ch.)

## Realms (Kingdoms of the Dúnedain ch.)
- Arnor: ~248,540 sq mi (Lune–Greyflood mouth–Loudwater–Forochel bounds).
- Gondor: ~716,425 sq mi direct rule; Haradwaith tributary +~486,775 sq mi.
- Shire: Far Downs–Brandywine Bridge 40 leagues (120 mi); moors–marshes 50 leagues (150 mi), measured NW–SE ("due north-south... would have ended in hills, not marshes"); area ~21,400 sq mi. (Shire ch.)

## Mountains
- Misty Mtns: ~900 mi north–south; possibly to 12,000 ft; Alps-inspired (Tolkien hiked 1911); alpine-glaciated (horns, troughs; Mirrormere = moraine-dammed). (Misty Mtns ch.)
- White Mtns: ~600 mi west–east; ≥9500 ft (snowline requirement); SW "knot" possibly higher than Alps; no passes. (White Mtns ch.)
- Ered Luin: lower than Misty (weaker migration barrier); breached anticline. (Eriador ch.)
- Mordor ranges: lower (no snow); Cirith Ungol pass >3000 ft above Cross-roads; the Cleft ~3000 ft. (Mordor; Path chs.)
- Erebor: est. 3500 ft (snowcapped to spring); 6 radiating spurs; diameter ~10 mi. (Lonely Mountain ch.)
- Weathertop: summit 1000 ft above lowlands; Weather Hills ~1000 ft. (Weathertop; Eriador chs.)

## Mordor (Mordor; Mount Doom chs.)
- Udûn: circular caldera/ring-dike, 45-mi base — original volcano "would have towered almost 29,000 feet."
- Mount Doom: 7 mi base diameter, 4500 ft (3000-ft shoulders + 1500-ft cone); avg slope 20°; composite volcano, Vulcanian eruptions; cf. Etna 11,000 ft/29-mi base.
- Sea of Nurnen: salty, interior drainage (no size given); Lithlad = farmable ash plain; Gorgoroth = lava plateau above Udûn/Lithlad.
- Earlier concepts: Gorgoroth reached nearly to Nurnen; south Ephel Dúath bulged two arcs ~150 mi toward Harad; Nargil Pass at south feeder river.
- Anduin total length: NOT given. Sea of Rhûn dimensions: NOT given.

## Cities & sites
- Minas Tirith: hill 700 ft; White Tower 300 ft (50 fathoms), ~150 ft diameter, 200 ft lower than Orthanc; city breadth avg ~3100 ft; 7 walls >40,000 linear ft, >2,000,000 tons of stone; outer wall = Orthanc-like black rock; tomb domes near Pantheon-size. (Minas Tirith ch.)
- Orthanc: >500 ft; Ring of Isengard 1 mi rim-to-rim; rimwall ~100 ft; 27 door-steps; Isengard 16 mi into Nan Curunír, 1 mi west of Isen; Orthanc = volcanic plug (Shiprock analog); fortified after 2953. (Isengard ch.)
- Helm's Deep: Deeping Wall 250 ft long, 20 ft high, 4 men abreast; Hornrock ≤40 ft; Helm's Dike 0.25 mi below Burg, >1 mi long, 20-ft cliff; Death Down 1 mi below Dike; Aglarond limestone caverns (Cheddar Gorge inspiration, Letters 407). (Helm's Deep ch.)
- Edoras: sentinel foothill; dike + wall + thorn fence; barrows 9 (Eorl–Helm) + 7 (Fréaláf–Thengel) + Théoden; Meduseld completed by Brego. (Edoras ch.)
- Dunharrow: Firienfeld "some hundreds of feet above the valley"; Snowbourn vale 0.5 mi wide at ford; refuge from early Second Age. (Dunharrow ch.)
- Erebor interior: secret tunnel est. 2 mi (door 5 ft high, 3 abreast; Bilbo 3 hrs); Smaug ~60 ft long → hall ≥180 ft; hidden bay under 150-ft cliff; west vale ~3 mi. (Lonely Mountain ch.)
- Lake-town: ~2 city blocks; pop ~400+; Esgaroth = earlier larger city, same site, "possibly" destroyed by Smaug; rebuilt farther north. (Lake-town ch.)
- Moria: West-door–East-gate ≥40 mi; guardroom shown ~3900 ft deep; mines possibly 12,500 ft deep (Primary-World mining limit); West-door shelf 30 ft (5 fathoms) above riverbed; flooded valley ~2 mi long; Silvertine holds Endless Stair (her placement). (Moria ch.)
- Caras Galadon: great mallorn ~400 ft high/broad, "slightly larger than the tallest redwood." (Lothlórien ch.)
- Tower of Cirith Ungol: tiers 100/75/50 ft high, 40/30/20 yd deep; roof 200 ft above gate; court 50 ft; wall 30 ft, overhung. (Tower ch.)
- Goblin-town: Great Goblin cavern ~300x100 ft; Gollum's lake shown 400 ft across. Beorn's hall ~20x35 ft. (Hobbit chs.)
- Henneth Annûn: falls est. ~80 ft; cave held 200 men; 10 mi west of road-pool. (Henneth Annûn ch.)
- Barad-dûr: built S.A. 1000–1600; rebuilt Third Age; NO size figure given; fronted by "a seething volcanic desert." (2nd Age; Vegetation chs.)
- Emyn Muil: outer ridge ~120 ft (20 fathoms); east gully 108 ft (18 fathoms); Sam's rope 30 ells. Nen Hithoel once mapped 120 mi farther north. (Brown Lands ch.)
- Brandywine: "possibly comparable to the upper Mississippi." (Along the Brandywine ch.)
- Bree: ~100 stone houses; at East Road/Greenway crossing. (Prancing Pony ch.)
- Osgiliath: Anduin deep enough for large vessels at quays; great bridge bore towers/houses (possibly the citadel itself); palantír lost 1437; bridge broken 2475. (Realms in Exile; Battles chs.)
