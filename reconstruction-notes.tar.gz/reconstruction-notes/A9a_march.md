# A9a — Great March of the Quendi (Nature of Middle-earth, Part One)

Source: NoME ed. Hostetter 2021. Chapter cites per book part/chapter. Line refs to I_nature.txt.

## Cuiviénen position (ch. I.VII "The March of the Quendi", c. 1959)
Full passage (lines 1547–1552):
"Distance? Beleriand was about 550 miles broad from Eglarest to the Mountains of Lune. From the Mountains of Lune to the Sea of Rhûn is, according to the LR map over 1,250 miles: [total] 1,750 miles. How far east or southeast of the Sea of Rhûn was Cuiviénen? [7] If we say in ancient days that Cuiviénen was 2,000 miles as the crow flies from the coast of ancient Beleriand this will be approximately right."
- Editorial note 7 (11803–05): Tolkien actually wrote "How far W or SW of Sea of Rhûn was Cuiviénen?" — editor calls it a slip; "the Eldar here too reach the shores of the Sea of Rhûn from the east."
- Editorial note 10 (11811): 2,000 mi is crow-flight; actual course "much longer."
- Ch. I.VI text A (1315–16): Cuiviénen "must be fairly far west (near centre of Endor?)" — Men awoke "much further east"; Men's centre "far south of Utumno."
- No Sea-of-Helcar remnant statement found in this volume; index only "Rhûn, Sea of 47, 49, 56, 370."
- Ch. I.VIII Cuivienyarna: lake with "great cliff above it upon the east side," waterfall; awaking in starlit twilight but Elves also delighted in "the sun of summer" (Sun coeval).
- Part Three intro conjecture (7219–24): diagram dot "k" perhaps Kuiviénen; Annals of Aman cited: "eastward of Endon (which is the midmost point) and northward."

## March itinerary with cumulative mileages (ch. I.VII; march begins VY 1129/29, host 20,000; "2,000 miles to go"; "goes about 200 miles by the end of April"; marches April–September)
- 400 mi: two 200-mi stints (Apr; Jun 20–Jul 20); "now near the east side of the Sea of Rhûn, then a very pleasant place."
- 450 mi: moves to shores of Sea of Rhûn; halts rest of year; child-begetting halt 120 löar.
- 650 mi (VY 1130/15): +200 mi; camps in "wide grasslands before Mirkwood"; sows grain 3 harvests.
- 800 mi (1130/20): +200 to Great Forest (Greenwood); lurking evils; retreat 50 mi (850−50=800); Oromë clears it 1130/25.
- 1,050 mi (1130/26): Ingar+Ñoldor pass Forest "at its southern end (which was farther south than in the Third Age)"; reach Anduin Vale; settle east bank of Anduin "(the region of later Lórien)" = Atyamar 'second-home'; long halts, begettings; >3,000 Teleri refuse to cross = Nandor.
- 1,150 mi (1130/91): cross Anduin (Teleri rafts/boats; river "wild and flooded"); "finds the Hithaeglir impassible. Some are lost"; Misty Mountains "then much taller"; wander south into plain of later Rohan (Calenardhon).
- 1,850 mi (1130/95): settle "about the Isen (near later Isengard)"; wandering took ~4 löar. NB: "All the coast south of the Haradwaith originally extended much farther west (before the ruin of Beleriand and later Númenor) so that they are still very far from the Sea." Deleted draft: many go to Sea "at Isenmouth" (deleted; ed. note 16 at 11839–49 on Isen mouth latitude problem).
- 2,110 mi (1132/9): west to Gwathló "(about 260 miles)".
- 2,310 mi (1132/11): reach Baranduin; "near the southern end of the Ered Luin."
- 3,111 mi (1132/17): led 1132/12 into "eastern Beleriand 'which is safe'"; "about 800 miles" more, to area of Western Doriath, reach coast of Beleriand 1132/17. "The March is over." By 1132/20 all 30,000 Eldar in Beleriand; Lindar push to Falas or Nevrast; Ñoldor/Ingar about Sirion.
- Duration: "The March began in 1129/29: they were nearly 3 VY in migration = 420 sun-years." Transit over Great Sea = 12 sun-years. Old Tale of Years: coast in VY 1125, "only 20 VY = 200 [sun-]years on the March."
- Halts logic: halts "at least 10 [sun-]years (gestation 9 + mother's rest) + 10 growth-years (120 [SY]) = 130 [löar]"; then march "about 30 [sun-]years"; halt 130 again. (First written: "at least 10... more likely 20"; "halt 20 again.")
- Ed. notes 15 & 19 (11826–78): in this scheme NONE cross the Misty Mountains; whole host goes south around them and enters Beleriand below southern Ered Luin — contradicts Silmarillion (crossing Hithaeglir passes and Ered Luin further north). Editor: earlier accounts ran "at about the mid-latitude of the Misty Mountains."
- Ch. III.XVII "Silvan Elves" (9060–66): legends say Vanyar/Noldor crossed "by the pass under the Red Mountain" [fn3: "Probably that mountain afterwards known as Caraðras... it was then loftier than in later ages"], followed by 2/3 of Teleri; 1/3 (folk of Olwë) stayed = Silvan Elves between Gladden and Limlight. Anduin then "wider and slower and forming great lakes." fn2: Misty Mts "at that remote time appear to have been continuous with the White Mountains" (ed. note 4 at 13626–29: no Gap of Rohan yet).

## Numbers of Elves (verbatim arithmetic)
- Ch. I.VII: awoke as 12 pairs (later 144 = 72 pairs; Companies 14/56/74: Imin→Ingar, Tata→Ñoldor, Enel→Teleri/Lindar). Begetting: age 40, intervals 24 yrs; children per pair 6/6/6, then 5, then 4. Population milestones: 36→96→312→960→1,710(sic table)→3,460 at Finding (1085)→7,460→15,060 (7th gen)→29,060 (8th gen).
- First plan: 10,000 march, 5,000 Avari stay: "Ingar 1,000, Noldor 3,500, Teleri 5,500." Revised: "Let 20,000 march (leaving 9,060 or about 9,000 Avari). Ingar 2,000, Ñoldor 7,000, Teleri 11,000." Final total in Beleriand 30,000.
- Ch. I.XIV "Calculation of the Increase": total 32,400 at Finding (VY 1090): companies 3,150/12,600/16,650; Avari 1/3 = 10,800; "The Marchers or Eldar then will number 21,600": Vanyar 2,100, Ñoldor 8,400, Lindar 11,100. Alt scheme: 35,738 by March. "In these 6 VY the Quendi must increase to over 30,000 from 144." 90 VY = 12,960 sun-years deemed "much too long"; original scheme allowed only 850 yrs.
- Ch. I.XV: population at Finding 20,588 (5,628 + 14,960). Ch. I.XVII notes: Scheme 1 march-total 26,270 (Avari 8,748, Eldar 17,496 → V 1,700 / Ñ 6,800 / L 8,900); Scheme 2 total 48,232 (Eldar 32,112 → 3,100/12,400/16,500).
- Key dates (ch. I.XIII): Awaking VY 850 or 865 or 1000 or 1386; Finding +864 sun-years (6 VY); March "[?occupies] 3 VY?" (text 3). VY = 144 löar (ch. I.I, 1957): "each Valian Year = 144 Mortal Years."
