# A14a — Map History & Scales (Companion front-matter, "The Maps of The Lord of the Rings")
[T] = Tolkien-quoted; [CT] = Christopher Tolkien quoted; [H&S] = editorial. Line refs to R_companion.txt.

## History
- [T, 11 Apr 1953, Letters 168] Three maps needed: Shire; Gondor; "general small-scale map of the whole field of action"; "must first make a map and make the narrative agree" (l. 2621–29).
- [T, 9 Oct 1953, Letters 171] "stumped" by the maps; "indeed in a panic"; blamed reduction "to black and white bareness" at tiny scale (l. 2630–39).
- [H&S] First edition: three maps, black and red, two on fold-outs, ALL drawn by Christopher Tolkien: general Middle-earth map late 1953; "A Part of the Shire" March 1954; large-scale Rohan–Gondor–Mordor map April 1955 (l. 2640–44).
- [T, 18 Apr 1955, Letters 210] "The map is hell!"; had not kept careful track of distances; large map "reveals all the chinks in the armour"; differs from "semi-pictorial" small map (l. 2645–50).
- [T, draft to H. Cotton Minchin, Apr 1956, Letters 247] general map "would not suffice for the final Book"; he spent days "drawing re-scaling and adjusting a large map"; Christopher redrew it in one 24-hour sitting (l. 2657–65).
- [H&S] Shire map based on Christopher's 1943 large-scale map; [CT] "virtually certain" his father allowed him "some latitude of invention" NW of the Water; Christopher proposed Nobottle, Needlehole, Rushock Bog, Scary (l. 2669–2700).
- [H&S] 1980: Christopher redrew the general map for Unfinished Tales (see scale below); 1969 India-paper edn added Adorn/Glanduin/Swanfleet to general map (wrongly placed — see A14d).

## Scale statements (verbatim)
- [T, 18 Apr 1955, Letters 210] Large-scale 1955 map: "is 5 times enlarged exactly from that of the general map" (l. 2666–68).
- [T, to Austin Olney, 28 July 1965; Letters 358] Shire map: "The chief fault is that the Ferry at Bucklebury and to Brandy Hall and Crickhollow have shifted about 3 miles too far north (about 4 mm.)." (implies Shire-map scale ≈ 3 mi : 4 mm) (l. 2917–31).
- [CT, UT Intro 13–14] 1980 map: "I have therefore redrawn it fairly exactly, on a scale half as large again" (l. 3169–72).
- [H&S] 1954 general-map scale inferred: "50 leagues (150 miles) from the Brandywine Bridge extends beyond Westmarch, even beyond the Tower Hills" — reason for 2nd-edn text change to "Forty leagues" (l. 4882–98).
- [H&S, Prologue note] "One league is generally considered equal to about three miles"; [T, UT 285] "very nearly three of our miles"; [T, Marquette MSS 4/2/19, Hobbit long measures] "3 miles or 1 league (Bree tigh)"; pace-mile 1,152 yds; long mile 2,304 yds (l. 4899–4946).

## Errors & corrections between printings
- Shire map vs text spellings: Bindbole misread "Bindbale" (Ballantine 1965, Strachey, Fonstad, Foster, even Tolkien's own 1956 Dutch note); [CT] intended reading Bindbole (l. 2712–37). Brockenborings/Brockenbores; Budge Ford/Budgeford; Green-Hill/Green Hill; Rushy/Rushey; Stockbrook/Stock-brook; Waymoot/Waymeet.
- Brandy Hall: 1st-edn map put road between hall and river, contradicting text; [CT, RS 305] error from his 1943 map "which my father did not notice"; corrected on A&U 2nd edn (1966) map (l. 2901–16).
- [T, 1965 Olney letter] decided "to take the maps as 'correct' and adjust the narrative"; Ferry 3-miles error could not be altered; missing wood at FR p. 99; "I have had simply to disregard these map-errors" (l. 2917–31).
- The Yale added to Shire map 1966 — but [CT, RS 387] as a black square, "a misunderstanding" (region intended, like the Marish).
- Stock road: map has road meet causeway IN Stock; text says "above Stock"; Tolkien made no change (l. 2895–2900).
- 1954 general map: "Hithaeglin" for Hithaeglir; "Nan Gurunir" for Nan Curunír; "South Gondor (Harondor)" — [T, Dutch notes] "the mapmaker should have written Harondor (South Gondor)"; Harondor omitted 1980 (l. 3000–3011).
- [CT, RS 441] on 1954 map the heights west of the range north of Hollin are "badly exaggerated" from what his father intended (l. 3012–16).
- [CT, UT 13 n.] "Icebay of Forochel" as marked was "only a small part" of the immense Bay; Cape of Forochel tip unnamed on 1954 map (l. 2994–99).
- 1955 large map spellings: [T, Minchin draft, Letters 247] "inconsistencies of spelling are due to me"; map has Kelos, Kiril, Kirith Ungol (Christopher's preference) vs text C-spellings; Houghton Mifflin 2004 map emended to C; HarperCollins kept K until 2005 (l. 3030–41, 3222–26).
- Dor-in-Ernil on 1955 map "placed on the other side of the mountains from Dol Amroth" [CT, UT 255 n. 14].
- 1980 UT map: area smaller; "only features lost are the Havens of Umbar and the Cape of Forochel"; adds Lond Daer, Drúwaith Iaur, Edhellond, the Undeeps, Greylin, Harnen, Carnen, Annúminas, Eastfold, Westfold, Mountains of Angmar; "mistaken inclusion of Rhudaur alone has been corrected" by adding Cardolan and Arthedain; Himling island shown; Great Road marked, its course Edoras–Fords of Isen "conjectural (as also is the precise placing of Lond Daer and Edhellond)" [CT, UT 13–14] (l. 3160–92).
- UT map error: Sirith/Celos branching reversed; corrected in some printings only; general map corrected 2004 (l. 3215–17).
- Prologue 1st edn "Fifty leagues… from the Westmarch"; 2nd edn "Forty leagues… from the Far Downs"; Ballantine typos "Fox Downs", "western moors" (corrected A&U 1966) (l. 4882–98).
- Tower of Ecthelion: 1st edn "one hundred and fifty fathoms" (900-ft tower); 2nd edn (1965) "fifty fathoms" = 300 ft, banner 1,000 ft above plain (l. 25670–78).
- Ferry–Bridge distance in text: "twenty miles" emended to "ten miles" (2004, on CT's suggestion) (l. 8864–83).
