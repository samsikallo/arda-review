# A7b — Galadriel & Celeborn + Appendices A–E (UT, src lines cited)

## Concerning Galadriel and Celeborn (narrative)
- Early Second Age: dwelt "about Lake Nenuial (Evendim, north of the Shire)" (l.7280).
- c. SA 700: went east, founded Eregion; Ost-in-Edhil, chief city, begun c. SA 750 (Tale of Years date for Eregion's founding).
- Eregion–Moria axis: Celebrimbor's friendship with Narvi; West-gate inscription cited; both realms enriched.
- Lórinand (Lórien): Nandorin realm "on the other side of the Misty Mountains"; it "extended into the forests on both sides" of Anduin, "including the region where afterwards was Dol Guldur" (l.7346).
- Galadriel left Eregion via Khazad-dûm to Lórinand between SA 1350–1400 (Mírdain revolt); Celeborn stayed.

## War of SA 1693–1701
- 1695: Sauron "moved over Calenardhon (Rohan)" invading Eriador; Gil-galad sent Elrond; Sauron turned north straight for Eregion.
- Eregion sacked; House of the Mírdain captured; Celebrimbor slain; Sauron took the Nine.
- Elrond saved by Dwarves of Khazad-dûm + Elves of Lórinand under Amroth; forced north; founded Imladris 1697 (Tale of Years). "The Gates of Moria were shut" against Sauron.
- 1700: Sauron master of all Eriador save besieged Imladris, "reached the line of the River Lhûn"; reserves "in Enedwaith at the Crossing of Tharbad". Tar-Minastir's navy arrived 1700; admiral Ciryatur.
- Sauron driven SE "after great slaughter at Sarn Ford" (Baranduin crossing); Ciryatur landed a force "at the mouth of the Gwathló", where was "a small Númenórean harbour" [= Vinyalondë/Lond Daer]. Battle of the Gwathló: Sauron "routed utterly"; remnant destroyed "in the east of Calenardhon"; he fled via the later-named Dagorlad to Mordor. Imladris besiegers crushed between Elrond and Gil-galad. First Council: eastern stronghold fixed at Imladris, not Eregion.
- Afterwards Galadriel & Celeborn dwelt "between the mouth of the Gwathló and Ethir Anduin... in Belfalas, at the place that was afterwards called Dol Amroth" (l.7472); Galadriel returned to Lórien TA 1981.

## Amroth, Nimrodel, Edhellond
- Amroth son of Amdír (slain Dagorlad SA 3434); dwelt on Cerin Amroth; Nimrodel by her falls near Lórien's north border; both fled TA 1981; met under eaves of Fangorn, "which in those days drew much nearer to Lórien" (l.7502).
- The haven in the south: less than a shipload of Elves, one seaworthy ship; autumn storm from the Northern Waste drove ship to sea; Amroth leapt overboard, drowned in the Bay of Belfalas.
- Nimrodel lost in the White Mountains; slept by a mere of the Gilrain (Lebennin). Gilrain course: swift from mountains, then at end of an Ered Nimrais outlier a "wide shallow depression", wandering, small mere at south end, cuts a ridge, joins the Serni.
- Edhellond position (l.7681): a haven and small Elf-settlement "at the south of the confluence of Morthond and Ringló" — CT gloss "(i.e. just north of Dol Amroth)". Founding traditions: (a) seafaring Sindar from the Falas havens fleeing "in three small ships" after their destruction; (b) Doriath-remnant Sindar early Second Age settling "at the mouth of the Morthond", displacing primitive fisherfolk. Note 18: name Edhellond occurs only on Pauline Baynes's decorated map; cf. Tom Bombadil preface: haven at Morthond-mouth sailing "as far back as the fall of Eregion".
- Dol Amroth: princes settled "between the mouths of Ringló and Gilrain", stronghold "upon the high promontory of Dol Amroth" (Cirion n.39, l.9859); named after Amroth. Contradiction CT flags: pre-Downfall Faithful settlement vs. Galador first Lord c. TA 2004–2129 (son of Imrazôr + Mithrellas, companion of Nimrodel) — "two distinct and independent 'traditions'".
- Dor-en-Ernil: on LotR map "on the other side of the mountains from Dol Amroth"; here linked to the Prince of Dol Amroth [ambig].

## Appendix B (Sindarin princes)
- Thranduil's realm once reached woods round the Lonely Mountain and west shores of Long Lake. Oropher withdrew "northward beyond the Gladden Fields" avoiding Moria and Galadriel; by end of SA in western glens of Emyn Duir; after TA 1000 shadow, realm fixed in the north-east with delved halls. Malgalad of Lórien = Amdír [CT equation]; slain Dagorlad, driven into the Dead Marshes.

## Appendix C (Boundaries of Lórien)
- LotR App. A error, JRRT "stated several times": read "to the Field of Celebrant", not "to Celebrant and the southern eaves of Mirkwood".
- Celebrant (Silverlode) lay within Lórien; Gondor's effective north bound west of Anduin = river Limlight. Parth Celebrant = grassland between Silverlode and Limlight (Lórien usage); in Gondor applied to land between lower Limlight and Anduin.
- Anduin below Lórien: enters "low flat lands" before the Emyn Muil chasm; "many shallows and wide shoals"; crossable by rafts/pontoons "especially in the two westward bends, known as the North and South Undeeps" (l.8161). Gondor bridged the upper Limlight.
- Lórien bounded E/W by Anduin and mountains; N/S undefined; claim north to the Silverlode falls; south into open woodland merging with Fangorn; heart in the Celebrant–Anduin angle (Caras Galadhon).

## Appendix D — The Port of Lond Daer (complete)
- Gwathló divides Minhiriath ("Between the Rivers" Baranduin–Gwathló) from Enedwaith ("Middle-folk"). At Glanduin–Mitheithel confluence land almost flat, waters "spread into fenland"; "some hundred miles below Tharbad the slope increased" (l.8199); Gwathló never swift — small-draught ships could reach Tharbad.
- Primeval state: both regions "vast and almost continuous forests" except the central Great Fens.
- Aldarion "chose the estuary of the Gwathló" for a haven wholly Númenórean; "in origin a timber-port and ship-building harbour".
- Deforestation: fellings first along both Gwathló banks, timber floated to Lond Daer; then "great tracks and roads" driven north and south; natives fled — from Minhiriath into "the great Cape of Eryn Vorn, south of the mouth of the Baranduin"; from Enedwaith to eastern mountains "where afterwards was Dunland"; they avoided the Isen–Lefnui promontory (Andrast) "because of the 'Púkel-men'". Devastation "incalculable"; timber shipped to Númenor; Sauron's raiders burned woods/stores; after 1701 the Gwathló ran through treeless desert on both banks.
- Naming: first Gwath-hîr/Gwathir "River of Shadow" (forest shadow over the water); after explorers reached the fens, Gwathló (lô 'fenland'); Adûnaic Agathurush.
- Tharbad: drainage and dyke-building made "a great port" there in the Two Kingdoms era; Bridge of Tharbad + "long causeways" over the fens on both sides, jointly maintained until the Great Plague TA 1636; "considerable garrison of soldiers, mariners and engineers" till the 17th century TA. Afterwards decay; Boromir found only crumbling causeways, ruined mounds, "a dangerous ford formed by the ruins" — river slow, shallow, wide. Tharbad ruined/deserted TA 2912 (great floods over Enedwaith and Minhiriath).
- Glanduin = 'border-river': southern boundary of Eregion (SA), then (with Gwathló) southern boundary of the North Kingdom. Enedwaith between Gwathló and Isen belonged to neither kingdom; the great North-South Road ran through it "from Tharbad to the Fords of Isen (Ethraid Engrin)".
- Lower Glanduin: swift only in upper course, then lost in fens — Nîn-in-Eilph "Waterlands of the Swans"; RotK "Swanfleet river (not River)".
- CT map-error admission (l.8296): JRRT intended Glanduin = upper course, fens marked Nîn-in-Eilph/Swanfleet; "his intention came to be misunderstood": Baynes marked lower course "R.Swanfleet"; on the LotR book map the names "are placed against the wrong river" ('Swanfleet' and 'River Glandin' [sic] against the upper Isen).
- Lond Daer Enedh footnote (l.14922ff): quickest inter-kingdom route was by sea to the port at the Gwathló estuary-head, then river-port Tharbad, then the Road; Tharbad fort "on great earthworks on both sides"; the ancient port begun by Tar-Aldarion, "called Lond Daer Enedh, the Great Middle Haven", as between Lindon and Pelargir. CT: that name must postdate Pelargir (built SA 2350).

## Appendix E / measures note
- Celeborn 'silver-tall'; Teleri smaller than Noldor (see A7c for stature data).
