# A11b — V08 ch. XIV "The Second Map" + Rohan/Gondor drafts; V06 distances

## Second Map (V08 txt 15447–15616)
- JRRT's working map during Book V. Single sheet; first stage black ink; few red-ink changes; final stage rough blue ink/crayon/pencil. Now limp, torn, wrinkled.
- SCALE (verbatim): "It is ruled in squares of 2 cm. side (= 100 miles), the squares being lettered and numbered according to the First Map."
- Contents: Rivers-of-Gondor list written on the map (see A11a). On map: Ereg (later Erui), Sirith (no western tributary), Lossarnach (seemingly large), Lameduin ("Lamedui" on map, 3 tributaries, only Serni named; junction dot R12 later named Linhir), Ringlo, Kiril (not yet Ringlo's tributary), Morthond, unnamed Calenhir from Pinnath Gelin; Lamedon written three times, final at top of Q12; Erech dot P11 (addition) with river to Morthond; Caerost on Kiril pencilled (= forerunner of Calembel); Tarnost pencilled Q12 (appears nowhere else); Belfalas late addition; note: Pinnath Gelin = 'lower Green Hills'; Odotheg > Odothui; Lhefned > Lhefneg; Tarlang's Neck shown unnamed; beacons = line of dots P13, Q13–14; Osgiliath now NE of Minas Tirith; map note: "Minas Morgul must be rather more north"; Anduin at Q14 originally straight — great elbow + hills of Haramon (> Emyn Arnen) superimposed in blue ink, devised so the black fleet could reach the Pelennor wall; Frodo's Emyn Muil→Morannon track carefully marked; pencilled Harad Road, Near/Far Harad, Desert of Lostladen, Khand, Umbar. Pelargir dot added on First Map R13.
- Mordor evolution on the map: Barad-dûr originally on "great peninsula of high land (Q16)" thrust south from the Ash Mountains — struck through; Barad-dûr moved NW to P16, where Orodruin had first stood; Orodruin moved to bottom right of P15. Late additions: Sea of Nurnen outline, Lithlad, Morgai, Nurn; vale behind Morannon first Gorgoroth, struck out, replaced "Narch Udûn" (V09 shows Narch first, Udûn its replacement).
- CT distances on Second Map (verbatim): "From Linhir to Pelargir direct is 2 cm. or 100 miles"; Erech–Linhir "36 mm. or 180 miles"; "it is 125 miles ... up river from Pelargir to the angle of the 'knee' in Anduin"; Edoras to the three beacon-dots nearest Minas Tirith "270 miles, to the next 245 miles, and to the next 218 miles" (= Amon Dîn, Min Rimmon, Eilenach); "from Edoras to the Rammas is about 285 miles, and to Minas Tirith about 295"; Erech–Dunharrow "(probably) 45 miles".

## Kirith Ungol's shifting meaning (V08 Part Two)
- Originally the main pass into Mordor, "Spider Glen" [draft]; so on First/1943 maps, guarded by two towers; Minas Morgul then west of the mountains.
- Sketch I [draft]: Minas Ithil/Morghul moved to guard the Black Gate itself, called Neleglos 'the White Tooth'; cleft of Kirith Ungol below it. Sketch II: cleft on far side of pass.
- Then abandoned [draft]: Gates (Ennyn Dur > Mornennyn) guarded by two towers "Nelig Myrn", the Teeth of Mordor; Minas Morgul restored southward; Kirith Ungol = high pass beneath its shadow; Tower of Kirith Ungol not yet conceived (cleft of spiders passed beneath Minas Morgul).
- Final: Kirith Ungol = cleft/stair high above Minas Morgul with its own Tower; main entrance = Morannon/Kirith Gorgor.

## Helm's Deep / Hornburg
- First appearance [draft]: "Heorulf's Clough" and "Heorulf's Hold" on the Stanrock, "an outjutting heel of land"; rejected names Helmshaugh, Neolnerwet, Theostercloh; Heorulf = precursor of Erkenbrand.
- Earliest fastness [draft]: only a natural fall across the coomb-mouth with stone parapet, three 'breaches' > 'inlets'; whole battle along Helm's Dike. Later the elaborate fortification; TT narrative followed "very precisely" in drawing 'Helm's Deep and the Hornburg' (Pictures no. 26). A cut-out square possibly removed a sketch-map.

## Dunharrow's evolution
- Stage 1 [draft]: Dunharrow = the mountain (First Map IVE); Hold = amphitheatre "lap of Dunharrow" with man-made caves, feast-hall, stream over the door; two sketches (V08 p. 239); east side of Harrowdale near its head.
- Stage 2 [draft]: mountain renamed Starkhorn; Hold on its "lap".
- Stage 3 [draft]: Hold moved far down-valley toward Edoras, caves in a hill ('Firien') ~50 miles from the Starkhorn.
- Final: Hold = the Firienfeld upland, climbing road, Púkel-men (written straight out as in RK). Note 37: on later large-scale map Edoras–Dunharrow 16 miles, Edoras–Starkhorn 19 miles.
- White Mts contour map (verso of draft): 2 cm squares, ~90 miles E/W of Edoras; margin: "Scale 4 times main map" → CT: "1 mm. = 1.25 miles"; Erech note "62 miles as crow flies from Dunharrow"; measured dot 51 mm = 63.75 miles. On First Map, 'Dunharrow'(mountain)–Erech = 18.5 mm = 92.5 miles.
- Anomalous Oct 1944 map (redrawn p. 269): 2 cm squares, made from memory; Ethir Anduin directly south of Rauros; Umbar too far north, east of Tolfalas; Mordor's east wall most complete of any map; Dark Tower on Ash-Mountains peninsula, Mt Doom NW of it; purpose: show no pass Harrowdale→Morthond.

## Minas Tirith / Rammas / Pelennor / beacons
- Draft wall "always distant some seven leagues from the First Gate"; fords of Osgiliath one league beyond. CT: townlands first "a great half-circle ... radius of seven leagues"; RK: four leagues furthest, little more than one nearest.
- Naming: 'Pelennor' first = the wall; then wall = Ramas Coren > Rammas Ephel > Rammas Echor; north-gate = Forannest (on slip listing Mering Stream + seven beacons' distances).
- Anduin knee [draft]: Ramas-Coren "but 15 [> 5] miles from the City"; visible straight reach "about 10 miles long"; Battle drafts: nearest [five >] four miles from the Gates; 'reach of Arnen' "three leagues" (longer on Second Map).
- City: plan (p. 290) with Rath Dinen, Othram (City Wall); White Tower 300 ft draft > 200 ft typescript; Tower of Denethor (later Ecthelion).
- Ride distances [draft list]: "Eilenach 215 (219); Min Rimmon 245 (246); Amon Dîn 270; Rammas 294; Minas Tirith 306"; camp west of Min Rimmon 243 miles; Halifirien camp at 160 miles; Dunharrow→Edoras 25 miles; Edoras–Minas Tirith pencilled "250 miles", later "a hundred leagues and two" (large-scale map 302 direct, JRRT noted 304). Forest of Eilenach = forerunner of Druadan Forest; small map on 'Ride of the Rohirrim' page: Druadan Forest, Stonewain Valley, Anórien road, Eilenach (sixth beacon, final position), Amon Dîn, 'Grey Woods' SE of Amon Dîn, Cair Andros, Osgiliath due east of city (large map: NE).
- Aragorn's ride [draft]: Erech–Fords of Lameduin "175 miles direct, about 200 by road"; Linhir–Pelargir 100 miles; Anduin in Lebennin 5–7 miles broad; rowing 4 mph, 100 miles by 6 a.m.; note 31: 60 leagues + 100 miles agrees with RK "ninety leagues and three".

## V06 surviving distance/day-count material (brief)
- Trotter on Weathertop [kept in essentials]: "about 120 long-miles from Bree to Weathertop - by the Road"; "between 80 and 90 miles in the last six days"; "nearer 40 than 30 miles from Brandywine Bridge to Bree"; Bridge–Ford "a deal over 300 miles"; "close on 200 from Weathertop to the Ford"; Bridge–Ford a fortnight going hard, most take nigh a month. JRRT bracketed it "? Cut out ... too cut and dried". Forsaken Inn a day's journey east of Bree. 'Halfway from Bree to Rivendell' goes back here.
- Earlier note [draft]: Weathertop "50 [beside: 100]" miles from Bree.
- Six days Bree→Weathertop, arrival Oct 5 = FR's chronology.
- High Hay [draft] "forty miles from end to end" (FR: well over twenty); CT: implied ~43 miles straight vs ~20 on maps.
- CT text-vs-map: FR 1st edn Road ran along Loudwater "for many leagues"; 2nd edn "runs along the edge of the hills" — change "made to save the appearance of the map". Last Bridge–Loudwater: 45/60/62 miles on JRRT's maps, ~75 on published map; Strachey's visibility objection "is real".
