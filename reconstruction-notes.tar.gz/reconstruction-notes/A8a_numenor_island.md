# A8a — Númenor island geography as printed in Sibley, The Fall of Númenor (2022)
Source: H_numenor.txt (line refs). Chapter "The Geography of Númenor" (ll. 1178–1336). Sibley's endnote (ll. 8735–8743): text drawn from UT "A Description of Númenor" pp. 165ff + NoME "Of the Land and Beasts of Númenor" pp. 328ff, "arranged to best describe the island's physical geography"; reign-specific details relocated into the chronology.

## Dimension statements (verbatim, permitted in full)
- Shape (ll. 1206–1209): "The land of Númenor resembled in outline a five-pointed star, or pentangle, with a central portion some two hundred and fifty miles across, north and south, and east and west, from which extended five large peninsular promontories."
- THE 700-MILES SENTENCE, full with context (ll. 1221–1230): "The promontories, though these were not all of precisely the same shape or size, were roughly 100 miles across and rather more than 200 miles long. A line drawn from the northernmost point of the Forostar to the southernmost of the Hyarnustar lay more or less directly north and south (at the period of the maps); this line was somewhat more than 700 miles long, and each line drawn from the end of one promontory to the end of another and passing through the land (along the borders of the Mittalmar) was more or less of the same length."
- Meneltarma: "about 3,000 feet high above the plain" (l. 1239); last 500 feet unscalable except by climbing road (spiral, foot on south, ends below summit lip on north; ll. 1656–1658).
- Orrostar highlands: 2,100 feet near NE end of promontory (l. 1313).
- Cliffs (NoME material, ll. 1316–1336): land "thrust upward out of the Sea," "slightly tilted southward"; cliffs highest N/NW, "often reached 2,000 feet"; lowest E/SE; shorelands at cliff-feet width one quarter mile to several miles; southern strands end in sheer fall to oceanic depths along a line joining the southernmost SW and SE promontory-ends.
- Other rocky heights "about 2,000 feet" (l. 2051). Lake Nísinen "about three miles inland" (l. 1482). Road Rómenna→Armenelos "(about 40 miles)" (l. 2099). Longbow range "some 600 yards or more" (l. 2033). Temple in Armenelos: walls 50 ft thick, base 500 ft across, walls 500 ft high, silver dome (ll. 6221–6226).

## Regions
Forostar (Northlands), Andustar (Westlands), Hyarnustar (Southwestlands), Hyarrostar (Southeastlands), Orrostar (Eastlands), Mittalmar (Inlands, coastless except about Rómenna and its firth-head); Arandor the Kingsland (Rómenna, Meneltarma, Armenelos; most populous) (ll. 1210–1220).
- Forostar: least fertile; fir/larch woods; North Cape; Sorontil rising sheer from sea; eagles (ll. 1254–1259).
- Andustar: rocky north; "Three small bays… facing west"; fertile south; Bay of Eldanna facing Eressëa; Eldalondë the Green at bay's centre; Nísimaldar fragrant trees; malinornë groves (ll. 1261–1283, 1567–1596).
- Hyarnustar: mountainous west, cliffed W/S coasts; vineyards east; Hyarnustar/Hyarrostar promontories "splayed wide apart"; gentle shores (ll. 1285–1291).
- Mittalmar: raised above promontory level; grasslands; Emerië (SW) chief sheep region; Tarmasundar (five root-ridges); Noirinan, Valley of the Tombs, between SW and SE ridges (ll. 1232–1252, 1695–1700).

## Rivers
- Siril: chief river; rises "in springs under the Meneltarma" in Noirinan; south through Mittalmar; slow lower course; many small mouths amid marshes; wide white beaches for many miles; chief fisher-village Nindamos "upon the east side if the Siril" [sic, "if" typo] close to the sea (ll. 1292–1306).
- Nunduinë: enters sea at Eldalondë; makes lake Nísinen (ll. 1280–1283, 1480–1483). All other rivers short swift torrents.

## Cities/havens
- Andúnië: of old chief city and haven, "in the midst of its western coasts"; a great bluff shelters the haven from the north (ll. 1644–1647, 3274–3276); Ar-Pharazôn made it chief harbour of king's ships, sent Amandil to Rómenna (ll. 5936–5938).
- Armenelos: "Hard [by Meneltarma] upon a hill"; Elros's tower and citadel; eagle-eyrie on king's tower ~2,000 years (ll. 1648–1651, 1496–1501).
- Rómenna: "the greatest port," chief haven, greatest shipyards; firth; Tol Uinen isle in the bay with light-tower Calmindon; Eämbar guild-ship; great sea-walls; Faithful concentrated there late (ll. 2588–2598, 2830–2834, 3137–3139).
- Others: Ondosto (Forostar, on the wheel-road extended thence "straight west to Andúnië"); Hyarastorni (Hallatan, Mittalmar); Tompollë (Forostar, bear-dances); Meneldur's star-tower in the Forostar (endnote l. 9050: UT places it near Sorontil); hill of Oromet "nigh to Andúnië" with Tar-Minastir's tower (ll. 5220–5222, 5838–5839).
- Lost Road appendix only: haven of Moriondë "in the east of the land"; CT note (l. 9992): "no doubt the forerunner of Rómenna."

## Charts/maps in-world (ll. 1180–1192)
Accurate charts all lost; deposited in Guildhouse of the Venturers, "confiscated by the kings," removed "to the western haven of Andúnië"; Gondor's maps derived from settlers' memory-drawings plus one chart (sea-soundings, port approaches) from Elendil's ship.

## Foundation/migration numbers (Peoples material; endnote l. 8640 says not in UT)
Elros's fleet 150 or 200–300 vessels; c. 5,000–10,000 people; migration lasted at least fifty years (ll. 1131–1139). Foundation date apparatus (ll. 8607–8614): draft ToY had SA 50, amended to 32.

## Differences from UT printing (as flagged in THIS volume or visible here)
1. Composite text: UT Description interwoven with NoME passages (tilt, cliffs, fauna); order rearranged; some UT footnote material promoted into text.
2. Editor's re-dating: Tar-Atanamir entries follow CT's "correct reading" (2251 = death); Ar-Gimilzôr's death emended 3177→3175 and Tar-Palantir's accession adjusted "Solely for the chronology" of this volume (ll. 9483–9512); Akallabêth's "three and twenty" restored to "four" (l. 9537).
3. Lifespan stated as "thrice" that of lesser Men in text (ll. 1145, 2238) vs endnote citing UT p. 224 n.1 "some five times" (ll. 8654–8656).
4. Guildhouse sentence identical to UT but juxtaposition with Eämbar note (l. 9095: perished "(i.e. in the Downfall)"; confiscation date unsaid).
5. Typos as printed: "if the Siril" (l. 1306); "(illégalement)" left in Tar-Anducal's entry (l. 5665).
6. Lavaralda note (l. 9810): not among Eressëan trees in UT's Description "[nor, as a consequence, in this volume]".
7. Tar-Aldarion called "the sixth King" when giving malinornë nuts to Gil-galad (l. 1616).
