# A6a — Children of Húrin (2007): geography notes
(cite: CoH + chapter/section; LoN = List of Names; * = name on the volume's map)

## Dor-lómin micro-geography
- Húrin's house: "in the south-east of Dor-lómin" (Ch.IV); mountains near.
- Nen Lalaith: stream past the house walls; rises "from a spring under the shadow of Amon Darthir" (Ch.IV); LoN: Amon Darthir* = peak of Ered Wethrin "south of Dor-lómin".
- Over Amon Darthir's shoulder: "a steep pass"; hardy folk cross Ered Wethrin "down by the wells of Glithui into Beleriand" (Ch.IV).
- "no other pass, for the unwinged, between Serech and far westward" where Dor-lómin marched with Nevrast (Ch.IV).
- Bridge over Nen Lalaith on Fingon's riding-route through Dor-lómin (Ch.I).
- Brodda's hall: north of Húrin's house. Húrin: Brethil "some thirty leagues, as the eagle flies" (Ch.I).
- Túrin's escape after slaying Brodda: south into hills → outlaw cave → "a pass little used" south to Sirion's Vale (Ch.XII).

## Journeys
- Túrin to Doriath (Ch.IV): over Shadowy Mountains → Vale of Sirion → through Brethil → Doriath borders; Beleg guides "by secret ways"; enters over "the great bridge over the Esgalduin".
- Beleg's ranges: north-marches/Dimbar; pursuit route (Ch.IX): Crossings of Teiglin → eaves of Brethil → Dimbar → Pass of Anach in Ered Gorgoroth → Taur-nu-Fuin → slopes over Anfauglith, within sight of Thangorodrim. Alt Orc-route: "the Narrow Land", defile of Sirion; via Brithiach and Tol Sirion.
- Anach (Ch.VI, Beleg): between Crissaegrim (west) and Gorgoroth walls (east), "above the high springs of Mindeb". Sirion "unbridged and unforded below the Brithiach".
- Gwindor+Túrin: west over Sirion → Eithel Ivrin ("springs whence Narog rose") → south along Narog to Nargothrond (Ch.IX).
- Túrin's flight north (Ch.XII): "forty leagues and more" Nargothrond→Ivrin without rest; 23 years since he last trod the passes.
- Morwen/Niënor (Ch.XIV): south through Region → Sirion above Twilit Meres; guarded ferries on east shore (messenger route Doriath↔Nargothrond); 30 riders + Niënor + 10 with spare horses; 3 days west across plain to near Narog. Return NE toward "guarded bridge near the inflowing of Esgalduin"; ferry-route closed southward. Niënor flees north, crosses Teiglin at Haudh-en-Elleth.

## Amon Rûdh / Dor-Cúarthol
- 3 days south of Teiglin woods to west edge of Sirion's Vale moorlands; capture-site → hill "All this day until dusk" (Ch.VII).
- Amon Rûdh on "eastern edge of the high moorlands" between Sirion and Narog vales; crown "a thousand feet and more" above its base heath; seregon on crown, aeglos below.
- Garth wall "forty feet high, maybe"; cleft 20 paces along cliff-foot; north-side shelf "level and almost square", unseen from below; sheer cliffs west+east; approach only from north; pool spills over western brink; caves could house "a hundred or more"; hidden stair to flat summit + hewn outer steps.
- Views: Brethil/Amon Obel north "seeming strangely near"; Ered Wethrin NW "league upon league away"; Vale of Narog west.
- Camps: Methed-en-glad (south of Crossings of Teiglin) to Bar-erib "some leagues south of Amon Rûdh"; all could see the summit; signals.
- Dor-Cúarthol bound, verbatim: "Túrin now gave the name of Dor-Cúarthol to all the land between Teiglin and the west march of Doriath" (Ch.VIII).
- Orc road (Ch.VIII): defile of Sirion → past Tol Sirion → land between Malduin and Sirion → eaves of Brethil → Crossings of Teiglin → Guarded Plain → past Amon Rûdh's highlands → vale of Narog → Nargothrond.

## Nargothrond
- Doors open on Narog gorge through Taur-en-Faroth; realm Sirion↔Nenning (Intro). Túrin's bridge "over the Narog from the Doors of Felagund"; north-march "Debatable Land" at sources of Ginglith, Narog, fringes of Woods of Núath; east to Teiglin and Moors of the Nibin-noeg (Ch.X).
- Glaurung's route: over Anfauglith → north vales of Sirion → under Ered Wethrin → defiled Eithel Ivrin → burned Talath Dirnen between Narog and Teiglin (Ch.XI).
- Tumhalad, verbatim: "The Elves were driven back and defeated on the field of Tumhalad; and there all the pride and host of Nargothrond withered away." LoN: "Tumhalad*: Valley in West Beleriand between the rivers Ginglith and Narog where the host of Nargothrond was defeated."
- Bridge too strong to cast down quickly; Glaurung later broke it into Narog.
- Amon Ethir, verbatim (Ch.XIV): "Now Amon Ethir was a mound as great as a hill that long ago Felagund had caused to be raised with great labour in the plain before his Doors, a league east of Narog." LoN: "'Hill of Spies', a great earthwork raised by Finrod Felagund a league to the east of Nargothrond." Tree-grown save the summit; views of roads to the great bridge.
- Gelmir/Arminas: shipped by Círdan, "put ashore in Drengist"; traversed Dor-lómin, eaves of Ered Wethrin, Pass of Sirion; muster about Sauron's Isle (Ch.XI).

## Brethil complex
- Ephel Brandir: stockade on Amon Obel "deep in the forest" (Ch.XIII). LoN: Amon Obel* "in the midst of the Forest of Brethil".
- Haudh-en-Elleth: Finduilas's mound "beside Teiglin", near the Crossings; Orcs shun it.
- Teiglin course (Ch.XVI, near-verbatim): flows from Ered Wethrin "swift as Narog", low shores till after the Crossings; then cleaves the feet of Brethil's highlands; "deep ravines, whose great sides were like walls of rock"; Glaurung's gorge "by no means the deepest, but the narrowest, just north of the inflow of Celebros".
- Dimrost/Nen Girith: Celebros falls on the steep road Crossings→Ephel; wooden bridge; falls "by many foaming steps into a rocky bowl"; green sward; view "towards the ravines of Teiglin some two miles to the west".
- Cabed-en-Aras: east side "a sheer cliff of some forty feet", tree-grown crown; west bank less sheer/high, hung with trees; deer's-leap name; renamed Cabed Naeramarth.
- Approach: from Nen Girith path toward Crossings, then "turned southward by a narrow track" through woods above Teiglin.
- Glaurung's line Nargothrond→Brethil: "a line that swerves not"; crossed a little north of the watchers; attack from SW/W across Teiglin.
- Túrin's stone: mound where he fell; grey stone with runes; "on the brink of Cabed Naeramarth"; Húrin came up from the Crossings; Morwen died there.

## Other numerics
- Angband gates↔bridge of Menegroth "one hundred and fifty leagues" (Annals, Intro; repeated in B&L).
- Túrin born ~6,500 years before Council of Elrond (Intro). Siege of Angband 395 years; Gondolin secret >350 years; Turgon's host 10,000; Nirnaeth on 4th day; Húrin's cry 70 times.
- "A hundred leagues" to any land beyond the Shadow (Túrin to Níniel). Ephel Brandir→Nen Girith "five leagues at the least" (Brandir's walk).
- Morwen fled Dor-lómin "a year and three months" before Túrin's return; Mablung searched 3 years, Ered Wethrin to Mouths of Sirion.

## CT map/editorial notes (Appendix + Note on the Map)
- Map "closely based on" published Silmarillion map, itself from JRRT's 1930s map, "which he never replaced"; redrawing omits Ossiriand/Blue Mountains eastward; mostly only tale-names marked.
- Star-direction emendation: original "the first stars glimmered in the east behind them" impossible (they moved east/SE); emended to "before them"; rejects his earlier War of the Jewels (1994, p.157) westward-turning track as "improbable".
- UT p.149 sketch-map "not in fact well oriented"; from JRRT's map: Amon Obel "almost due east" of the Crossings ("the moon rose beyond Amon Obel"); Teiglin flows SE/SSE in the ravines; sketch redrawn with Cabed-en-Aras placed.
- Glaurung-crossing draft ("many paces to the northward") vs final; CT's two small emendations for coherence.
- Bar-en-Danwedh description written "before Mîm himself" existed (composite-text caveat).
- Drowned Beleriand frame (Intro): Silmarillion map ends east at Ered Luin; LotR map ends west at the same range; Ossiriand remnant = Lindon.
