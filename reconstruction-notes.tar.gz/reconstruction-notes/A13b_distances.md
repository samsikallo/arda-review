# A13b — Fonstad Atlas: Distance Tables & Rates
All [Fonstad-derived]; 1 league = 3 mi. Cites = Atlas chapter.

## Daily rates (Pathways ch.)
- Walking: 2.0–2.5 mph; Orcs & Three Hunters running: 3.0 mph.
- Ponies jogging: 3.4 mph; Rohan horses galloping: 6.7; Dúnedain horses: 7.0; Shadowfax: 20 mph.
- Boats: drifting 2.8 mph; paddling 4.1; ships rowing 4.7; sailing 7.2.
- Ents: 10 mph. Orc endurance: 56 hrs, one camp, two stops.

## Hobbit pathways (Hobbit intro ch.)
- Bag End–Rivendell: 400+ mi; est. 38 travel days (avg 10 mi/day; as low as 8 if 51 days); Rivendell stay est. 27 days.
- Chronology (her calc; only Apr 27, Midyear's Day, Sept 22 canonical): dep Apr 27; Trolls May 29; Rivendell June 4; dep Midyear's Day; Goblins July 16–19; Beorn July 20–22; Enchanted Stream Aug 16; captured Aug 23–24; escape Sept 21; Lake-town Sept 22; dep Oct 9; leave river Oct 12; Durin's Day est. Oct 30; Smaug slain Nov 1; siege Nov 16; Battle of Five Armies Nov 23; Beorn's Dec 30; Rivendell May 1; home June.
- Rivendell–Goblins' Front Porch: 25-day ascent. Goblin tunnels Front Porch–backdoor: est. 35 mi (2.5 days); Great Goblin's cavern ~5 mi in.
- Anduin valley on Beorn's ponies: ~20 mi/day.
- Mirkwood path: 188 mi total; 143 at Enchanted Stream; ~4 weeks, ~6.5 mi/day.
- Lake-town: 3 days rowing up Long Lake/Running River, then riding. Long Lake ~20 mi south of Erebor; Erebor diameter ≈ half that (~10 mi, Thrór's Map).
- Iron Hills–Erebor: "some two hundred fifty miles" (Dáin arrived ~10 days after summons).
- Scale flag: Wilderland map scale ~2x would normalize Dwarves' slow pace; Tolkien never harmonized (HoME VI 204).

## LotR: Bag End–Rivendell ch.
- Dep dusk Sept 23; Crickhollow Sept 25; Bombadil Sept 26–27; Barrow-wight Sept 28; downs exit–Bree: last 4 mi; Bree Sept 29.
- Dep Bree 10am Sept 30; Midgewater Oct 2–4; Weathertop noon Oct 6 (0.5-hr summit climb, 1–2 mi); attacked that night.
- Weathertop–Last Bridge: 120 mi in just over 5 days (Oct 7–12).
- Trollshaws lost Oct 13–18 (~6 days; two map variants — see A13d). Post-Glorfindel: marched to dawn Oct 19, then "almost twenty miles before nightfall"; Ford of Bruinen late Oct 20; Rivendell that night.

## Rivendell–Lórien ch.
- Dep dusk Dec 25; Hollin Ridge dawn Jan 8; Redhorn foot Jan 11; snow-retreat Jan 12; wolves that night.
- Redhorn Pass–West-door of Moria: 15 mi SW; road found Jan 13, Door past dusk.
- Moria West-door–East-gate: "at least forty miles" direct (Gandalf); ~half by post-midnight; 8-hr climb; 21st Hall Jan 14; Gandalf falls Jan 15.
- Gates–Nimrodel: "little more than five leagues" (15 mi), 1pm–early evening; Caras Galadon after dusk Jan 17.
- Dep Feb 16; 10-mi hike to Anduin; drift 3 days; Sarn Gebir ~midnight Feb 23; portage Feb 24; Parth Galen evening Feb 25.

## Rauros–Dunharrow ch.
- Orc route Rauros–Fangorn: ~165 mi; one camp in 60 hrs; 5-hr lead grew to 36.
- Three Hunters: ran 45 leagues (135 mi); 12 leagues/day on the plains.
- Treebeard to Wellinghall: "seventy thousand ent-strides" = 100 mi at 7.5 ft/stride.
- Edoras dawn Mar 2; Helm's Deep Mar 3–4 (battle); Nan Curunír mouth camp, then final 16 mi to Isengard Mar 4 (Isengard 16 mi in-valley, 1 mi west of Isen).
- After Dol Baran: Gandalf+Pippin to Edoras by dawn; Gandalf reaches Minas Tirith dawn Mar 9; Aragorn's company Dunharrow dusk Mar 7; Théoden (mountain paths) sunset Mar 9.

## Dunharrow–Morannon ch.
- Paths of the Dead Mar 8; Morthond Vale 2 hrs before sunset; Erech before midnight.
- Erech–Pelargir: "ninety leagues and three" (279 mi) BUT road ≈ 360 mi; Dúnedain rode 10–30 mi/day more than Rohirrim; Pelargir Mar 13; ships Mar 14; battle midmorning Mar 15.
- Edoras/Dunharrow–Minas Tirith: stated 102 leagues (306 mi) = straight line; road ~360 mi; Rohirrim ~80 mi/day; first camp 12 leagues (36 mi); last 7 leagues (21 mi) to Rammas pre-dawn Mar 15. (Note: 306-mi figure "irreconcilable" with map scale, ~30 mi too long.)
- Host of the West: dep Mar 18; infantry halt 5 mi east of Osgiliath; Minas Tirith–Morannon "some hundred miles" (compromise with TT's "nearly thirty leagues"/90 mi; +8–10 mi off-road Mar 23); arrive Mar 25. Force 1000 cavalry + 6000 foot; 1000 detached (Cross-roads, Cair Andros).

## Frodo & Sam ch.
- Nen Hithoel crossing Feb 26; Emyn Muil to Feb 29; Gollum captured; Dead Marshes dawn Mar 1, SE edge dawn Mar 2; Noman-lands 2 nights; 1 mi from Tower of the Teeth by Mar 5.
- Morannon–Cirith Ungol detour: 30 leagues (90 mi) south; first night 8 leagues (24 mi).
- Stream–Henneth Annûn: "somewhat less than ten miles."
- Cross-roads sunset Mar 10 (Dawnless Day); Straight Stair (600 ft direct ≈ 900 ft climbed); rest dawn Mar 11 (slept 24+ hrs); Shelob's Lair Mar 12–13, tunnel shown ~12 mi (chronology-driven; drawings imply shorter) — ~30 hrs inside; Ephel Dúath ~20 mi wide on map yet 3 days crossing (flagged).
- Tower escape pre-dawn Mar 15; Morgai valley north: 12 leagues (36 mi) from bridge by dawn Mar 17; road to Isenmouthe Mar 18: 12 mi + 8 mi forced trot; Mar 19 "a few weary miles"; then ~40 mi on road in <3 marches; abreast of Mt Doom Mar 22; Crack of Doom morning Mar 25.

## Road Home ch.
- Minas Tirith dep Jul 19; Edoras Aug 7; Helm's Deep Aug 14; Isengard Aug 22; Saruman met Aug 28 (Hobbits "riding round twice as far"); Moria west-side Sept 6; Rivendell Sept 21–Oct 5; Bree Oct 28; Brandywine Bridge Oct 30; 22 mi to Frogmorton Nov 1; Bywater Nov 2; Bag End Nov 3.

## Army sizes (battle chapters; her estimates)
- Hornburg: Théoden 1000 cavalry; Gamling 1000 foot; Erkenbrand 1000 foot; Huorns "hundreds and hundreds"; Saruman ≥10,000; outnumbered ~5:1; dawn sortie ~900.
- Pelennor, Gondor: Lossarnach 200; Ringló 300; Morthond 500 bowmen; Anfalas 150e; Lamedon 50e; Ethir 100; Pinnath Gelin 300; Dol Amroth 1200e; Minas Tirith Guard 2000e; Rohirrim 6000; Dúnedain 30; southern fiefs w/ Aragorn 1000e = ~11,250 total.
- Pelennor, Mordor: Morgul/Barad-dûr host 20,000e; Haradrim 18,000; Rhûn/Khand 7000e = minimum 45,000 (≥4:1).
- Morannon: 6000 of 7000 faced "ten times, and more" their match.
- Five Armies: Dáin 500 Dwarves; Elvenking ≥1000 spearmen + archers; Bard maybe 200; Lake-town pop ~400+.
- Bywater: ~200 + 100 Tookland Hobbits vs 100+ ruffians; ~70 ruffians killed.
- Nirnaeth: Turgon 10,000, roughly doubling the western host.
