# A10c — V01/V02 Book of Lost Tales: earliest world-image
ALL items [EARLIEST-SUPERSEDED]. Cites: volume + tale/commentary.

## Earliest map and Valinor (V01)
- CT reproduces a scribbled pencil map (I.81; in the Theft of Melko text): Utumna in the extreme North, NORTH of the lamp-pillar Ringil [pillar-names later reversed]; Valmar, the Two Trees north of Valmar, Mandos, Kôr marked; Eruman/Arvalin coastal strip; Magic Isles as circles; Mountains of Valinor "a great ring curving westward"; Shadowy Seas a Great Sea region west of Tol Eressëa. (V01, Coming of the Valar comm.; the map CT cites in the Ambarkanta commentary.)
- Kôr: "a lonely hill" by the shore, named "by reason of its roundness"; gold sand from its feet toward the Trees; every window "looked out toward the sea" (V01, Coming of the Elves). Taniquetil at the bay's head, looking south over Eruman, north over the Bay of Faëry (V01, Chaining of Melko).
- World-Ship diagram (I Vene Kemen): world in section as a Viking ship — mast on the Great Lands' highest point, sail bearing Sun and Moon, ropes to Taniquetil and a great eastern mountain; labels Vai, Neni Erumear, Ulmonan, Koivieneni, Palisor, I Nori Landar (Great Lands); the world "floats in and upon Vai" (V01, Music of the Ainur comm.).

## Tol Eressëa = England frame (V01)
- Ossë anchored the ferried isle "even to the sea-bottom"; it stands "upon a pillar of rock"; Lonely because "no land may be seen for many leagues"; Twilit Isles west of it, Magic Isles "backward in the East" (V01, Coming of the Elves).
- Frame: Tol Eressëa drawn back "unto the confines of the Great Lands" and becomes England; Kortirion = Warwick (Kor-/War- linked), Alalminórë = Warwickshire, Tavrobel = Great Haywood; Koromas = "the Resting of the Exiles of Kôr" (V01, Cottage of Lost Play + comm.). Gilfanon's House of the Hundred Chimneys by Tavrobel's bridge over Gruir and Afros (V01/V02; cf. V05 App. III Shugborough note).

## Great Lands, North, Palisor (V01/V02)
- 'Great Lands' = all lands east of the Great Sea (first 'Outer Lands', changed); later usage narrowed (V04 1st map: lands east of the Blue Mountains).
- Iron Mountains lie "to the east and south" of Hisilómë — CT: they "correspond to the later Mountains of Shadow" (Ered Wethrin); possibly one range whose northern peaks stood over Angband (V01 comm.; V02 Tinúviel comm.).
- Utumna in the extreme North; Angamandi "the Hells of Iron" — Melko's two fortresses (Utumna original; Angband his dwelling on return; see V04 Ambarkanta comm. table).
- Palisor: "the midmost region" of the Great Lands, with pinewoods; Waters of Awakening Koivië-néni a lake there, "bare margin", vale "surrounded by pine-clad slopes" (V01; quoted in V04 Ambarkanta comm.). Gnome exiles marched "nigh half across" the world from Palisor.
- Helkaraksë/Icefang: a neck jutting from the WESTERN mainland; the sound between its tip and the Great Lands = Qerkaringa, "Chill Gulf" (V01, Flight of the Noldoli).

## Proto-Beleriand (V02)
- Artanor (later Doriath) lies south of Hisilómë, divided from it by the Iron Mountains/Bitter Hills; Beren crossed them coming from Hisilómë (Tinúviel + comm.).
- Rodothlim caves (proto-Nargothrond) above a stream feeding Sirion (Turambar).
- Fall of Gondolin: Arlisgion 'place of reeds' south of Dor Lómin; Iron Mountains' "spurs run even to the sea"; Sirion rises in them; Land of Willows downstream; Gondolin on a flat-topped hill (Amon Gwareth) not quite central in the plain Tumladin, ringed by the Encircling Mountains; tunnel = Way of Escape; Sirion dives underground "at the great cavern of the Tumultuous Winds" ABOVE the Pools of Twilight [reverse of 1st map's arrangement — CT notes the reversal]; survivors settle at Sirion's mouth.
- Numerics (Fall of Gondolin): the Mountains "seven leagues save a mile from Gondolin"; Cristhorn "two leagues of upward going" from the mountains' beginning; fugitives "nigh eight hundreds". V02 Index: "league about three miles".

## Early cosmology (V01)
- Three airs: Vaitya (outermost), Ilwë (mid, blue, where stars sail), Vilna (grey, "therein may the birds fly safely"). Vai = Outer Ocean, tideless, cold, thin; "one Ocean", running "from the Wall of Things unto the Wall of Things"; the Earth "floateth" on Vai upheld by Ilúvatar's word (Ulmo, Hiding of Valinor). Valinor stands nearer the Wall than the easternmost shore.
- Sun and Moon are SHIPS sailing the airs; the Sun leaves by the Door of Night — "utterly black and huge" in the "deep-blue walls" — voyages the Outer Dark, re-enters by the Gates of Morn, a golden arch "barred with silver gates" in the East where the Wall is LOWER (Hiding of Valinor). [Ambarkanta abolishes the Gates of Morn; Door of Night repurposed for Melko's expulsion; Sun passes UNDER the earth.]
- Wall of Things originally wall-like, a "ring-fence" with a top (first draft); Ambarkanta turns it into the closed sphere Ilurambar.
