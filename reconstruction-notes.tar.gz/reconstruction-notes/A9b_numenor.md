# A9b — Númenor (NoME Part Three, chs. XI–XIII, c. 1965)

## Dimensions & area (ch. III.XIII "Of the Land and Beasts of Númenor")
- Promontories "roughly 100 miles across and rather more than 200 miles long."
- N–S line (northernmost Forostar point to southernmost Hyarnustar) "somewhat more than 700 miles long"; each promontory-tip-to-tip line through the Mittalmar "more or less of the same length."
- Area: island extent "probably some 180,000 square miles" (5-pointed star; no Great Britain comparison in this text).
- Populations: first migration guesses "between 200,000 and 350,000 people"; Elros's fleet "150 vessels, to others two or three hundred," carrying "probably between 5,000 or at the most 10,000"; migration lasted "at least 50 years"; after 1,000 yrs population "not... much exceeded 2 million"; before Downfall "as many as 15 million."

## Meneltarma & relief
- Meneltarma "only about 3,000 feet high" (ch. XI); "about 3,000 feet high above the plain," position in Mittalmar "nearly at its centre, though somewhat nearer the eastern edge"; unscalable "in places" in "last 500 feet"; climbed by spiral road from southern base near Valley of the Tombs (kings' burials).
- Mittalmar above general level of promontories; grasslands and low downs, few trees at settlement.
- North: land rose to "rocky heights of some 2,000 feet," highest Sorontil "rose straight from the sea in tremendous cliffs" (North Cape).
- Orrostar: highlands "2,100 feet" near NE end shield colder NE winds; inner parts grow much grain (near Kingsland).
- Cliffs everywhere ("thrust upward out of the Sea... slightly tilted southward"): greatest 2,000 ft N/NW, lowest E/SE; shorelands at cliff-feet 1/4 mile to several miles wide, then sheer plunge "to oceanic depths"; southern strands end in sheer fall along line joining SW and SE promontory tips.

## Regions/terrain/climate
- Bay of Eldanna "warm, almost as warm as the southernmost lands"; Eldalondë "almost at [the Bay's] centre, not far from the borders of the Hyarnustar." Mallorn in Númenor "at its tallest height almost 600 feet"; seed-gift by Tar-Aldarion to Gil-galad.
- Siril river: "last 50 miles... slow and winding," near-flat land; village Nindamos "upon the east side of the Siril close to the sea"; region calm, later reclaimed into fish-pool country. Eels in meres/marshes of lower Siril; salmon in Siril and Nunduinë.
- Nunduinë flows to sea at Eldalondë; forms lake Nísinen "about three miles inland."
- Hyarrostar: S/SW parts like Hyarnustar; rest flatter, fertile; Tar-Aldarion's timber plantations for shipyards; walnuts; laurinquë flowers.
- Hyarnustar: wild vine. Forostar: stone most esteemed for building; great black bears; large white owls; ravens in north. Andustar (Westlands): rich timber. Emerië: sheep-rearing region, shepherd dogs.
- No great mountains; rocky regions in N, NW, SW promontories, heights "about 2,000 feet."

## Roads & travel (ch. III.XI "Lives of the Númenóreans")
- Inland roads mostly unpaved "horse-roads"; heavy transport by sea; riding chief quick travel.
- Chief wheeled road: Rómenna (greatest port) NW to Armenelos "(about 40 miles)," thence to Valley of Tombs and Meneltarma; extended to Ondosto (Forostar) then "straight west to Andúnië" (Andustar); used mainly for timber-wains and Forostar stone.
- S.A. 600 Vëantur's first voyage to Middle-earth (ship Entulessë, to Mithlond, out on spring westerlies, back in autumn).
- Ports: Rómenna (E, greatest), Andúnië (W haven; Guildhouse records moved there, all perished), Eldalondë. Cities/towns all by the coast.
- Bows: Númenórean long-bow shafts "carry to great distance (some 600 yards or more)."
- All charts of Númenor lost; Gondor maps derived from memory-drawings + one chart of Elendil's ship (sea-soundings, ports).

## Fauna (native, ch. III.XIII)
- No canines (dogs imported), no wolves, no large felines; wild cats hostile; many foxes; lopoldi = rabbits (unknown before in NW Middle-earth); bears (black/brown, mostly Forostar; Great Bear-dance ruxöalë of Tompollë, autumn, up to "50 or more" bears); red/brown/black squirrels; otters, badgers, wild black swine; wild kine (white and black) west Mittalmar; red/fallow deer, roe-deer in hills — all "somewhat smaller" than Middle-earth kin; beavers and land-tortoises in south; seals abundant N and W; ekelli (large hedgehogs); small wild horse ("smaller than a donkey") found in Mittalmar; wild goats.
- Birds: eagles (sacred to Manwë; golden-eagle eyrie on king's tower in Armenelos "some two thousand years," Elros to Tar-Ankalimon); kirinki (tiny scarlet, wren-size); seabirds in multitudes greet ships; hawks, falcons, ravens, choughs; finches; nightingales except north.
- Trees: settlers missed hornbeam, small maple, flowering chestnut; found wych-elm, holm-oak, tall maples, sweet chestnut; wild apple/cherry/pear; orchard fruit and grape-vines from Eldar gifts.
- Fish chief food-source; sharks never approached shores. Whales, narwhal, dolphins classed nendili.
- Metals: lead; iron/steel needed for tools/axes (imported materials).

## Life-spans (ch. III.XI–XII, for reference)
- Ordinary Númenóreans die "350 to 420 years"; Elros ~500. Ageing formula: subtract 20, add remainder ÷5. Line of Elros: vigour to 300+, weariness 350–400 (or c. 400); others vigour to 175, weariness 200–225 (or 200–250). Marriage norms: men 50–100 (royal 100–150), women 30–75 (royal 50–100); child-bearing to ~year 125.
- Decline began 14th generation, after Tar-Atanamir's death S.A. 2251.
- "Days of bliss... lasted well nigh two thousand years."

## Aman after the Downfall (ch. III.XV, c. 1959)
- "Is Aman 'removed' or destroyed at the Catastrophe? It was physical. Therefore it could not be removed, without remaining visible as part of Arda or as a new satellite!" Tolkien: "best that it should remain a physical landmass (America!)" — becomes "an ordinary land, an addition to Middle-earth, the European-African-Asiatic contiguous landmass"; damaged, "especially on West [sic; read 'East'?] side, sunk into Sea." Aman/Eressëa persist only as memory. Editor notes conflict with Frodo's bodily voyage to "a seemingly very physical Tol Eressëa."
