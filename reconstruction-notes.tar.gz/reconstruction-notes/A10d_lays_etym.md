# A10d — V03 Lays: geography beyond Silmarillion detail + V05 Etymologies glosses

## V03 LAYS OF BELERIAND (cites: poem + line/commentary)

### Lay of the Children of Húrin
- Menegroth/Thousand Caves: Esgalduin flows "past the frowning portals / of the Thousand Caves" (lines 2167-8); river of "root-fenced pools roofed with silence"; name Thousand Caves "first occurs in the poem" (CT). [Lays]
- Nan Dungorthin: Túrin and Flinding, after passing the Unnumbered Tears battlefield, crossed Sirion near its source and reached the Shadowy Mountains' roots, entering the vale there — basis of the 1st map's second siting (CT, III.59, 87). "in Nan Dungorthin where nameless gods" have shrouded shrines (line 3423 area) — older than Morgoth's coming. [Lays]
- Nargothrond approach: no bridge — "nor bridge was built where Narog poured / before the gates"; entry by wading north of the gates "below the tongue" of land where Ginglith joins Narog. Carven stone bridge over the INGWIL: "a bridge was builded, a bow gleaming" in Ingwil's foam (CoH 2d version; CT: this bridge "mentioned nowhere else"). Sheer terrace in the hill-face above Narog. [Lays]
- Thangorodrim: "the threefold peaks of Thangorodrim" — CT: "first reference to the triple peaks"; Maidros hung "from a sheer precipice", from "Thangorodrim's stony crown" (Leithian 2735-9). [Lays]

### Lay of Leithian
- Tarn Aeluin/Dorthonion: unnamed lake in Lay proper — hideout was "a wooded island in the fen" (A-text; CT); in the later Lay (recommenced): birches on the margin, "a lonely moor", bare bones of Earth "like standing stones" through heather and whin; "by houseless Aeluin" the outlaws denned under grey stones. Names appearing in the later Lay: Dorthonion, Aeluin, Ladros (NE lands granted to Bëor's house), Drun ("north of Aeluin and west of Ladros", marked on the second map, "named in no other place" — CT), Rivil, Gorgol, Dagmor. [Lays]
- Rivil/Serech (verbatim, key relation): Beren found the Orc-camp "beside a darkling well, / where Rivil rises from the fell / down into Serech's reeds to flow". V03 index: Rivil rises in Dorthonion, flows into Sirion in Fen of Serech; Serech "North of the Pass of Sirion". Orc-camp at a HOT spring in the earlier Lay (CT). Also "of reedy Serech stood at bay". [Lays]
- Beren's Gorgoroth crossing (Canto III, lines ~540-5): "the awful mountains' stones he stained / with blood of weary feet"; gained "only a land of ghosts"; "in dark ravines imprisoned sheer" mighty spiders wove webs — creatures "with birdlike nebs". CT: first account of Ered Gorgoroth, "the precipices in which Dorthonion... fell southward"; earlier called 'Shadowy Mountains' in Canto II. Waters that drove drinkers mad. [Lays]
- Tol-in-Gaurhoth/Wizard's Isle: captives "cross the stony bridge of woe / to Wizard's Isle" to Thû's throne "of blood-darkened stone"; Lúthien sings "on the bridge of woe"; wolves come "at the bridge's end"; at Thû's defeat "the rocks yawned and the bridge broke", blocking Sirion on one side, "the dungeons gape" (Synopsis). Form Gaurhoth in later Lay; Tol Thu in V05 List of Names. [Lays]
- Angband approach: Fingolfin at the gate under "that vast shadow"; "desperate he smote upon that gate"; "endless fortresses of stone" engulf his horn-call; "ghastly brazen doors". Synopsis V: "Thangorodrim towers above them", rumblings, "steam and vapours burst from fissures"; "Ten thousand smiths"; journey through Taur-na-Fuin down to "its smoky foothills". Anfauglith seen from Taur-nu-Fuin's skirts. [Lays]
- Distances: Celegorm/Curufin hunting from Nargothrond rode "three days" to near Doriath's WEST borders (2342-7; basis of 1st-map placements). [Lays]
- CT map comments in V03: Umboth-Muilin north of Sirion's fall (Leithian 1722ff) vs reversed in Fall of Gondolin; Nan Dungorthin sitings (III.59, 87); Hills of the Hunters/Guarded Plain discussions III.87-9 underlie the 1st map.

## V05 ETYMOLOGIES — place-name glosses (stem: gloss)
1. AK-: Aglon "defile, pass between high walls".
2. AT(AT)-: Adurant — river with "double course" for a distance (isle of Adurant).
3. AY-: Belegoer/Belegaer 'Great Sea' (Q Alataire), between Beleriand and Valinor.
4. BAL-: Balar — island at Sirion's mouth; Beleriand named from it, "colonized from the island"; Valinor < *bali-ndore 'land of the Valar'.
5. BIRIT-: Brithon 'gravelly' river; whence Brithombar.
6. DEM-: Dimbar < dimb 'sad, gloom'.
7. DUI-: Ilk. duin 'river' — Esgalduin, Duilwen.
8. DUL-: Gondolin(d) "heart of hidden rock" (dolen 'hidden').
9. DUN-: Nan Dungorthin = "Vale of Black Horror".
10. ERE-: Tol-eressea, Amon Ereb (lone, isolated); Eruman "desert N.E. of Valinor".
11. EREG-: Region = holly-forest (Taur-nan-Erig).
12. ELED-: Eglador = Doriath ('Land of the Elves'); Ariador 'lands outside'; Eglor Elf-river; Eglamar, Eglorest.
13. SKAL1-: esgal "screen, hiding, roof of leaves" — Esgalduin (hidden river).
14. GAT(H)-: Doriath "Land of the Cave" (gath 'cavern'); gathrod 'cave'.
15. 3AR-: Garthurian "Fenced Realm" = Doriath (= N Ardholen, also of Gondolin); GARAT-: Garthoren 'Fenced Fort' = Gondolin.
16. GYEL-: Gelion — Gnome interpretation, 'merry singer'.
17. KAL-/KIL-: Kalakilya "'Pass of Light', in which Kor was built".
18. KHELEK-: heleg 'ice' — Helkarakse (N elcharaes).
19. KHIL-: hildi 'followers' = mortal Men — Hildorien.
20. KHIS-/LUM-: Hithlum 'Mist-and-Dusk' (hith mist + lum gloom; Q Hisilumbe).
21. LAT-: Tumladen "plain of Gondolin" (open, cleared land).
22. LIN2-: Lhinnon = Ossiriand "'musical land'... because of water and birds"; hence Eredlindon 'Mountains of Ossiriand' (but List of Names: lind 'blue').
23. LONO-: Avalona = Tol Eressea "the outer isle"; A-val-lon "hard by Valinor".
24. LUG2-: Luindirien 'Blue Towers' = Eredlindon.
25. MBAD-: Angband "Hell (Iron-prison) (Q Angamanda)".
26. MBOTH-/MUY-: Umboth Muilin "veiled pool" (N Lhin Uial/Eilinuial; Hithliniath 'pools of mist').
27. MITH-/RINGI-: Mithrim = 'white-fog' + ring "cold pool or lake (in mountains)"; Ringil = one of the great Lamps "(pillared on ice)".
28. MIZD-: Dolmed "'Wet Head', name of mountain" in Eredlindon.
29. NARAK-: Narog 'violent, rending'; Nargothrond "fortress of Narog"; Narogardh 'realm of Narog'.
30. NAUK-: Nogrod "Dwarf-city".
31. NDOR-: Endor 'Middle-earth (midmost)'; -nore 'folk-land' (Vali-nore).
32. NEL(ED)-: Neldoreth — forest of Doriath, "properly name of Hirilorn the great beech".
33. NGOROTH-: Gorgoroth "deadly fear"; (Fuin) Gorgoroth "later name of Dorthanion".
34. NGOL-: Ingolonde "Land of the Gnomes (Beleriand...)"; N Angolonn/Geleidhien.
35. NIB-/ROS2-/RAD-: Nivrim 'West-march', Nivrost 'West-dales/vale' (rost "plain, wide land between mountains"); Radhrim 'East-march' (of Doriath), Radhrost 'East-vale' = Thargelion.
36. PEL(ES)-: Tavrobel — Túrin's village in Brethil AND village in Tol Eressea ('woodpecker-village'); Tindobel "starlit village".
37. PHAL(AS)-: falas 'shore, beach' (of Beleriand), adj. Falathren.
38. RAMBA-: Ilurambar 'World-walls'; Andram "long-wall".
39. RIS-: Eglorest — "ravine made by the river Eglor" at its mouth, town there.
40. ROD-: Meneg-roth < roth 'cave/vault'; Ilk. rond 'domed roof' (Elrond "vault of heaven").
41. SIR-: sir 'river' (flow) — Sirion.
42. STAG-: Thangorodrim "(the mountains of duress)".
43. THON-: Dor-thonion "'Land of Pines'"; Taur-na-Fuin a "punning alteration of Dor-na-Thuin".
44. UY-: Amon Uilos = Taniquetil (uir 'eternity'); Q Elerina 'star-crowned' = Taniquetil.
45. WATH-: gwath 'shade' — Eredwethion (Ilk. Urthin).
46. WAY-: Vaiya "envelope, especially of the Outer Sea" within the Ilurambar; Ulmo = Vaiaro 'lord of Vaiya'.
47. KUY-: Kuivienen = N Nen-Echui 'Water of Awakening'.
