# Book II ch2 "The Council of Elrond" + ch3 "The Ring Goes South"

## Rivendell setting (ch2)
- Terraces above "loud-flowing Bruinen"; sun rises "above the far mountains" E; snow on peaks; pine-woods up valley side to the north.
- Imladris = "a far northern dale" (Denethor's lore); Rivendell "of which many had heard, but few knew where it lay" (Boromir).

## Glóin (ch2)
- Erebor dwarves troubled; Moria = Khazad-dûm; Balin, Ori, Óin "went away south" ~"nigh on thirty years ago"; silence since.
- "About a year ago" Mordor messenger rode to Dáin's gate; returned twice; third visit due "before the ending of the year".
- Messengers also to King Brand in Dale; "war is gathering on his eastern borders".

## Elrond's history (ch2)
- Elven-smiths of Eregion, friendship with Moria; One forged "in the Mountain of Fire".
- North-realm Arnor; South-realm Gondor "above the mouths of Anduin".
- Dagorlad "before the Black Gate"; last combat "on the slopes of Orodruin".
- Gladden Fields: Isildur perished; "three men only came ever back over the mountains".
- Annúminas "beside Lake Evendim" ruined; heirs moved to Fornost "on the high North Downs" = Deadmen's Dike, now desolate.
- Osgiliath chief city, "through the midst of which the River flowed"; Minas Ithil "eastward upon a shoulder of the Mountains of Shadow"; Minas Anor "westward at the feet of the White Mountains"; Ithil→Minas Morgul; Anor→Minas Tirith; Osgiliath "lay between".
- Gondor keeps "the passage of the River from Argonath to the Sea".
- Old Forest = "outlier of its northern march"; once "a squirrel could go from tree to tree" Shire→"Dunland west of Isengard".
- "Anduin the Great flows past many shores, ere it comes to Argonath and the Gates of Gondor."

## Boromir (ch2)
- Ithilien "our fair domain east of the River"; war out of Mordor "in the days of June"; last Osgiliath bridge destroyed; four escaped by swimming; Gondor holds "all the west shores of Anduin"; only Rohan sends aid.
- "a hundred and ten days I have journeyed all alone" (Minas Tirith→Rivendell); Bilbo repeats "a journey of a hundred and ten days".

## Gollum hunt (ch2)
- Gandalf+Aragorn "explored the whole length of Wilderland, down even to the Mountains of Shadow and the fences of Mordor".
- Aragorn: near Black Gate, Morgul Vale; caught Gollum "along the skirts of the Dead Marshes"; drove him to Mirkwood; Gandalf later heard "out of Lórien" that Aragorn had passed that way.
- Gollum's ring "came out of the Great River nigh to the Gladden Fields".
- Legolas: Gollum escaped via orc raid; trail "plunged deep into the Forest, going south" toward Dol Guldur ("we do not go that way").

## Gandalf's tale (ch2)
- 17 years ago fears woke ("That was seventeen years ago").
- End of June in Shire; rode to its southern borders; then "east and north... along the Greenway"; met Radagast "not far from Bree" at Midsummer. Radagast "dwelt at Rhosgobel, near the borders of Mirkwood".
- Isengard: "far south... in the end of the Misty Mountains, not far from the Gap of Rohan". Gap of Rohan = "great open vale... between the Misty Mountains and the northmost foothills of Ered Nimrais" (White Mountains). Isengard: "circle of sheer rocks", one gate; Orthanc tower in midst, Númenórean; pinnacle reached by "a narrow stair of many thousand steps".
- Gwaihir rescue; Edoras "not very far off" from Isengard; Rohan = "that great vale between the Misty Mountains and the White".
- Shadowfax: reached Shire when Frodo was on Barrow-downs though leaving Rohan only when Frodo left Hobbiton.
- Frodo left Hobbiton "less than a week before" Gandalf arrived; Black Rider came "the same evening".
- Bree: five Riders came from west; Captain lurked "south of Bree"; some sent "eastward straight across country".
- Gandalf reached Weathertop (Amon Sûl) "before sundown on my second day from Bree"; besieged; fled north.
- Return route: "up the Hoarwell and through the Ettenmoors, and down from the north"; "nearly fifteen days from Weathertop"; couldn't ride the troll-fells; reached Rivendell "only two days before the Ring".
- Galdor: threat of Sauron marching "along the coasts into the North", assailing "the White Towers and the Havens"; remaining power "in Imladris, or with Círdan at the Havens, or in Lórien".

## Ch3: scouts and departure
- Scouts: north "beyond the springs of the Hoarwell into the Ettenmoors"; west "far down the Greyflood, as far as Tharbad, where the old North Road crossed the river by a ruined town"; east/south crossed Mountains into Mirkwood; others "climbed the pass at the sources of the Gladden River", down over Gladden Fields to Rhosgobel (Radagast absent); returned "over the high pass that was called the Redhorn Gate". Elladan+Elrohir "down the Silverlode into a strange country" (errand secret). No Iron Hills mention.
- Rider remains: 3 horses drowned at the Ford, 5 bodies on rocks below; "Eight out of the Nine are accounted for".
- Hobbits "nearly two months in the house of Elrond"; November gone, December passing. "In seven days the Company must depart." Departure "a cold grey day near the end of December", at dusk. (No Dec 25 date stated.)
- Route: crossed bridge, up "the cloven vale", high moor; "At the Ford of Bruinen they left the Road and turning southwards"; plan: "hold this course west of the Mountains for many miles and days"; country rougher than "the green vale of the Great River in Wilderland on the other side". South of Rivendell the mountains "rose ever higher, and bent westwards".
- Fortnight out, wind veered south → holly ridge = Hollin/Eregion border. Gandalf: "Five-and-forty leagues as the crow flies we have come, though many long miles further our feet have walked" (endpoints: Rivendell→Hollin border). "It will get warmer as we get south."
- "Beyond those peaks the range bends round south-west."
- Peaks: Barazinbar = Redhorn = Caradhras (tallest, nearest, "tooth tipped with snow", bare northern precipice, red); Celebdil the White = Silvertine = Zirakzigil; Fanuidhol the Grey = Cloudyhead = Bundushathûr. "There the Misty Mountains divide"; between arms: Azanulbizar = Dimrill Dale = Nanduhirion. Under them Khazad-dûm/Moria.
- Redhorn Gate pass "under the far side of Caradhras"; descend "by the Dimrill Stair" to the vale; there Mirrormere (Kheled-zâram) and "the River Silverlode rises in its icy springs" (Kibil-nâla). Plan: "down the Silverlode into the secret woods, and so to the Great River".
- Crebain "out of Fangorn and Dunland" over "all the land between the Mountains and the Greyflood".
- Ancient road "from Hollin to the mountain-pass".
- Moria vs Gap debate: Aragorn: "Further south there are no passes, till one comes to the Gap of Rohan. I do not trust that way"; Gandalf's alternative "the dark and secret way".
- Two more night-marches; third morning Caradhras ahead; "more than two marches before we reach the top of the pass"; by midnight "climbed to the knees of the great mountains"; cliff-wall left, ravine right; cliff "faced southwards".
- Aragorn: snow "seldom falls heavily so far south, save high up"; "we are still far down, where the paths are usually open all the winter". Boromir: Sauron "can govern the storms in the Mountains of Shadow". Gimli: snow drawn "from the North... three hundred leagues away".
- Storm gap "not gone more than a furlong"; shoulder of rock "no more than a furlong off, I guess"; drift crest "more than twice the height of Boromir", yet "little wider than a wall". Frodo's dream: "Snowstorms on January the twelfth". Retreat: "Caradhras had defeated them."
