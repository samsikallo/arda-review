# A5d — S4 Contradictions & Oddities + S5 World-Structure key lines

## S4 CONTRADICTIONS & ODDITIES
1. Angband vs Utumno placement: Ch3 (3060–3064) Angband is "not far from the north-western shores of the sea", built against assault "from Aman" — distinct from Utumno "far in the north" beneath dark mountains (ch1, 2612–2614). Ch14 (6143–6146) restates: Angband "Behind the walls of Ered Engrin in the west, where they bent back northwards". So Angband = western/NW outwork; Utumno = central-north citadel. No explicit sentence says "Angband westward of Utumno", but both texts imply it. [ambig on exact separation distance — none given.]
2. Utumno's latitude vs Cuiviénen: Utumno lies where "the beams of Illuin were cold and dim" (2613) — i.e. near-north; yet the Sea of Helcar (formed at Illuin's roots, 3119–3121) is "far off in the east… and northward" (3117–3118). Illuin stood "near to the north" (2569–2570). Mapping tension: the Lamp's site yields an eastern inland sea while Utumno is a northern fortress "beneath dark mountains" — the text never reconciles Illuin's position relative to both. [ambig]
3. Sirion length vs Gelion: Gelion "twice as long as Sirion" (6364–6365) with Sirion "one hundred and thirty leagues" (6238) implies Gelion ~260 leagues, yet East Beleriand is only "a hundred leagues from Sirion to Gelion" at widest (6278–6279) — internally consistent only if Gelion's course is mostly N–S; noteworthy for scale-checking any map.
4. Ivrin's location: ch14 (6246) Narog rose "in the falls of Ivrin in the southern face of Dor-lómin"; but ch13 (5953–5955) puts the pools of Ivrin "at the feet of the Mountains of Shadow" (Ered Wethrin). Dor-lómin is a region west of the Mountains of Mithrim (6177–6178); "southern face of Dor-lómin" presumably = southern wall of the Dor-lómin highland, i.e. part of Ered Wethrin. [ambig]
5. Menegroth's bank: ch10 (5065–5069) only says the hill rose where Esgalduin parted Neldoreth from Region, river at its feet, bridge the sole entry; ch14 (6311–6312) fixes it: "Upon the southern bank of Esgalduin, where it turned westward towards Sirion". (Southern bank = Region side.)
6. Nevrast drainage oddity: "a hollow land… and no river flowed thence" (6198–6200) — endorheic basin with mere Linaewen; coast-cliffs HIGHER than the plains behind (6199).
7. Ard-galen "northward of Dorthonion" (ch13, 5675) vs ch14 "South of Ard-galen the great highland named Dorthonion" (6213) — consistent, mutually confirming.
8. "The hills near Eithel Sirion" (ch13, 5680) and Fen of Serech placed between them and the Pass region — Serech's exact position not defined in ch1–14. [ambig]
9. Two names for Lamp-sites: editorial map caption (2632–2633) uses "Helkar [Illuin] and Ringil [Ormal]" — Ringil never appears in narrative text of ch1–14; Helcar only as the Inland Sea.
10. Enchanted Isles "before Tol Eressëa… by one sailing west" (5505–5507) vs Eressëa anchored "in the Bay of Eldamar" (3575) — the isle sits within the Bay yet outside the new leaguer; fine, but note the Shadowy Seas begin east of it.
11. Alqualondë's light: "north of the Calacirya, where the light of the stars was bright and clear" (3689–3690) — i.e. outside the Trees' beam through the pass; Tree-light through Calacirya reached only the west shore of Eressëa (3589–3592). Directly cartographic: the light-cone axis runs Calacirya→Eressëa.
12. "Ilmarin" absent from Ainulindalë–ch14; Taniquetil's halls are only "above the everlasting snow, upon Oiolossë" (2266–2267). Ilmarin appears first in Akallabêth (15628).
13. Talath Dirnen (Guarded Plain) and rivers Brithon/Ginglith are NOT in ch14's text; ch14 gives only Nenning reaching the sea at Eglarest (6254). Ginglith/Brithon presumably in later chapters (out of scope).
14. Thangorodrim's coordinates: never given a league-distance from anything except via the Angband→Menegroth 150 leagues (5213–5214); "in the north-west" as a phrase does not occur in ch14 — the NW placement is inferential from 6143–6146 and ch3's 3060–3061.
15. Hithlum boundary phrasing makes Ered Wethrin a single "great curve" bounding it "in the east and south" (6172–6173) — so the same range faces Ard-galen (E) and the Vale of Sirion (S).
16. First Battle geometry: eastern Orc camps "between Celon and Gelion" (5228) — Celon (Aros tributary from Himring, 6403–6404) thus bounds Doriath's NE approaches.
17. Doom of the Lamps symmetry: "the symmetry of its waters and its lands was marred" (2628–2629) — original Arda was symmetric; all later geography is the marred version.
18. Túna "set nigh to the girdle of Arda" (4737) — Calacirya at Arda's equatorial belt; northward the seas narrow (4738–4740): the two continents converge toward Helcaraxë.

## S5 WORLD-STRUCTURE key verbatim lines (full quotes kept short)
- "it was globed amid the Void" (1990).
- "two mighty lamps for the lighting of the Middle-earth which he had built amid the encircling seas" (2566–2567).
- "One lamp they raised near to the north of Middle-earth… Illuin; and the other was raised in the south… Ormal" (2569–2571).
- "upon the Isle of Almaren in the Great Lake was the first dwelling of the Valar" (2584).
- "lands were broken and seas arose in tumult" (2626); "the shape of Arda and the symmetry of its waters and its lands was marred" (2628–2629).
- Aman "the westernmost of all lands upon the borders of the world" (2647); "its west shores looked upon the Outer Sea… Ekkaia, encircling the Kingdom of Arda" (2648–2649); "beyond it are the Walls of the Night" (2651); "the east shores of Aman were the uttermost end of Belegaer, the Great Sea of the West" (2651–2652).
- "upon the shores of the sea they raised the Pelóri, the Mountains of Aman, highest upon Earth" (2654–2655).
- Taniquetil "standing upon the margin of the sea" (2751).
- "the Great Sea that sundered it from Aman grew wide and deep… a deep gulf to the southward… between the Great Gulf and Helcaraxë far in the north, where Middle-earth and Aman came nigh together" (3237–3242).
- "a bay in the Inland Sea of Helcar; and that sea stood where aforetime the roots of the mountain of Illuin had been" (3119–3121).
- Helcaraxë: "the chill waters of the Encircling Sea and the waves of Belegaer flowed together" in "a narrow strait" (4896–4898).
- Sun/Moon: courses "above the girdle of the Earth from the West unto the East and to return" (5340–5341); Sun drawn "under the Earth" to the east (5429–5430); Moon in "the chasm beyond the Outer Sea… at the roots of Arda" (5451–5453).
- Pelóri raised "to sheer and dreadful heights, east, north, and south"; sole pass Calacirya (5483–5488).
- Ered Engrin "upon the borders of the regions of everlasting cold, in a great curve from east to west" (6142–6143).
