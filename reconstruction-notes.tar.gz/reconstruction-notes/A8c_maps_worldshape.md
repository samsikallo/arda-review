# A8c — Sibley (2022): map apparatus + world-shape/Straight Road as printed
Source: H_numenor.txt (line refs).

## Plates list (ll. 223–238)
Thirteen plates by Alan Lee plus two maps (asterisked): Host of the Valar Descend into Angband; **Map of Númenor\***; Looking West from Andúnië; Aldarion departs Númenor; The Building of Barad-dûr; The Forging of the Rings; Galadriel leads the Elves through Moria; The Temple of Sauron; Ar-Pharazôn Assails Valinor; The Fall of Númenor; Gil-galad crosses the Misty Mountains; The Last Alliance of Elves and Men; **Map of The West of Middle-earth at the End of the Third Age\***.
Footnote (l. 8448): asterisk = "Maps by Christopher Tolkien, coloured by Nicolette Caven." Copyright page (ll. 55–56): both maps "drawn by C.R. Tolkien for Unfinished Tales 1980."

## The map-history endnote ("MAP OF MIDDLE-EARTH", ll. 10023–10048)
- For Fellowship (1954) Christopher Tolkien drew a large general map: "Unnamed, the map was inked in black and red" and issued as a fold-out at the back of the volume; based on his father's much-amended pencil map; drawn "in some haste" under publisher deadline pressure.
- For UT (1980) CT made the Map of Númenor (facing UT p. 168; "in this volume, see p. 12") and redrew the Middle-earth map; quotes UT p. 13: redrawn at a scale "half as large again," area smaller, only losses being "the Havens of Umbar and the Cape of Forochel."
- Because Umbar is referenced in this book, "Christopher's original 'unnamed' map is reproduced here (p. 298)"; the UT map, titled "The West of Middle-earth at the End of the Third Age" (coloured by Nicolette Caven, 2020 illustrated UT), is the rear endpaper.
- So THIS volume prints three CT maps: Númenor map (plate + p. 12); the 1954 unnamed first-edition LotR map (p. 298); the UT Third-Age map (endpaper/plate).

## First Map / Treason of Isengard references (ll. 9579–9589)
CT (Peoples p. 187 n. 23), on the Tolfalas/Pelargir coast-change passage: it "appears to be the sole reference in any text to Tolfalas," apart from a Two Towers-era outline (Treason p. 435); "The isle and its name appeared already on the First Map of Middle-earth ([Treason] pp. 298, 308)," but on all maps its extent is much greater than described. CT also notes the coast-change statement is found nowhere else; Akallabêth's parallel passage names no region or river.

## World-shape / Straight Road passages printed here
1. Akallabêth (ll. 6495–6685): Ilúvatar "changed the fashion of the world"; chasm between Númenor and the Deathless Lands; Aman and Eressëa removed; new lands and seas made, "the world was diminished." Downfall on the 39th day after the fleets sailed. Exiles' beliefs: Meneltarma's summit "rose again above the waves" as a lonely isle, sought vainly; farthest sailors "set but a girdle about the Earth"; "All roads are now bent"; the Straight Road as an invisible bridge through bent air, traversing Ilmen, to Tol Eressëa "and maybe even beyond, to Valinor"; tales of mariners who saw "the face of the world sink below them."
2. Waldman letter 1951 (ll. 5947–5957, 6686–6697): old world "envisaged as flat and bounded"; after the Fall "the world is round, and finite"; only lingering Elves may find the "straight way."
3. Drowning of Anadûnê extract (endnote, ll. 9639–9667): "All the ways are bent that once were straight"; earth "was not plain [flat]"; the Adûnâim came to believe roundness dated only from the Downfall — flagged by Sibley as a "notably different account" from the Akallabêth/Epilogue.
4. Fall of Númenor original "scheme" (Lost Road pp. 11–12; endnote ll. 9595–9628): CT describes Tolkien's sketch — globe Ambar within circles Ilmen and Vaiya, crossed by a straight line — which Sibley calls the first diagram of "the World Made Round and the Straight Path." Text: the Gods "globed the whole earth"; new lands "beneath the Old World"; the old line of lands remained "a plain of air" for the Gods; Númenórean attempts built only ships sailing "in Wilwa or lower air"; their sea-fleets rounded the world and were taken for gods.
5. Letters No. 154 (1954; ll. 9670–9683): Tolkien on the legendarium's flat-to-round "transition"; he could not imaginatively conceive a flat world, though geocentric was easier.
6. Straight Road for the Firstborn: Mithlond departures — Firstborn "could still follow the Straight Road" to Eressëa/Valinor (ll. 1019–1023); Elrond's grace "continued after the change of the world" (ll. 1035–1036).
7. Lost Road narrative (Appendix B) world-details: Númenor "half-way between the worlds"; lavaralda scent smellable at sea before Eressëa is sighted; Valinor "has no further bounds" claim rebutted — "the world itself is bounded"; the wave-borne ships "cast far inland" at Moriondë; plot-notes: "the flying ships," "the painted caves," "how Elf-friend walked on the Straight Road"; "As they approach Númenor the world bends" (ll. 8385–8392). Key divergence flagged for cartography: in Lost Road the Temple stands ON the Mountain's summit and Sauron "surveys our land from the Mountain" (ll. 8207–8217), versus the Akallabêth (also printed here) where the Meneltarma stays undefiled and the Temple is in Armenelos; plus "a secret haven to the North" for the Armament (l. 8289) vs fleets gathering "in the havens of the west" (l. 6411).
8. Pre-change geography: Avallónë on Eressëa visible from the Meneltarma or a tall ship offshore to the keenest eyes (ll. 2440–2452); Númenor sundered from both Middle-earth and Valinor "by a wide sea; yet it was nearer to Valinor" (ll. 1071–1074).

## Other Sibley map-relevant editorial notes
- Ras Morthil (CT, l. 9025): name found nowhere else; "must be the great headland" ending Belfalas's northern arm, = Andrast (Long Cape); (Sîr) Angren = Isen.
- Calenardhon gloss: Sindarin "Green Region/Province," later Plains of Rohan (l. 9172); "Gap of Calenardhon, later known as the Gap of Rohan" (l. 9289).
- Moriondë (CT, l. 9992): occurs nowhere else; "forerunner of Rómenna."
- Tal-Elmar (endnote ll. 8956–8990): tale not included; town "in the green hills of Agar"; date unknown ("before the Downfall"), Sibley suggests c. 3262–3310; extract on Númenórean slave-ships quoted.
- Editorial method (ll. 323–338): published texts treated as final; variant names/dates/spellings silently conformed; editorial matter set smaller/indented; [brackets] editorial; ellipses = omissions.
