# A5c — S2 Measurements (every numeric, verbatim core) + S3 Itineraries

## S2 MEASUREMENTS (chapter; line; quote; endpoints)
Distances/lengths:
1. Ch10 (5213–5214): "one hundred and fifty leagues" — "the gates of Morgoth… distant from the bridge of Menegroth". Endpoints: Angband's gates ↔ Menegroth's bridge over Esgalduin.
2. Ch14 (6214): Dorthonion "stretched for sixty leagues from west to east".
3. Ch14 (6238–6239): Sirion "flowed south for one hundred and thirty leagues" — from where he "plunged through the pass" (after rising at Eithel Sirion and skirting Ard-galen) to "his many mouths and sandy delta in the Bay of Balar". [ambig: 130 leagues measured from the Pass, or from source? "Thence" follows the pass-plunge clause.]
4. Ch14 (6246–6247): Narog "flowed some eighty leagues" — falls of Ivrin → junction with Sirion in Nan-tathren.
5. Ch14 (6278–6279): East Beleriand "at its widest a hundred leagues from Sirion to Gelion and the borders of Ossiriand".
6. Ch14 (6338–6339): "some twenty-five leagues east of the gorge of Nargothrond" — Nargothrond gorge ↔ Falls of Sirion below the Meres.
7. Ch14 (6342–6343): Sirion underground "issued again three leagues southward" — Falls of Sirion ↔ Gates of Sirion.
8. Ch14 (6363): Gelion "flowed south for forty leagues before he found his tributaries" — arms-meeting ↔ Ascar confluence.
9. Ch14 (6364–6365): Gelion "before he found the sea he was twice as long as Sirion, though less wide and full"; (6348–6349) "neither fall nor rapids throughout his course… ever swifter than was Sirion".
10. Ch13 (5843): Thorondor's "outstretched wings spanned thirty fathoms".
11. Ch14 (6158–6160): filth spread "southward for many miles" over Ard-galen (no number).
12. Ch10 (5059): pearl Nimphelos "as great as a dove's egg".

Counts/times (spatially relevant):
- Ch1 (2569–2571): 2 Lamps: Illuin "near to the north", Ormal "in the south".
- Ch1 (2701–2712): Tree cycles 7 hours each; Valian day 12 hours; Telperion first hour = Opening Hour.
- Ch3 (3271): Melkor imprisoned "three ages"; Dwarves came in second age of captivity (4994–4995); Menegroth built before the third age (5100).
- Ch9 (4523): "threefold peaks of Thangorodrim".
- Ch11 (5398): Tilion crossed heaven "seven times" before first Sunrise.
- Ch13 (5682): Dagor-nuin-Giliath "Ten days that battle lasted".
- Ch13 (5952): Mereth Aderthad "When twenty years of the Sun had passed"; (5981) "when again thirty years had passed" Turgon/Finrod dreams; (6036) "in the next year" Ulmo appeared to Turgon.
- Ch13 (6064–6065): Siege of Angband "lasted wellnigh four hundred years of the Sun".
- Ch13 (6087–6088): "nearly one hundred years… since the Dagor Aglareb" — Orc raid on Drengist; (6102) "Again after a hundred years" — Glaurung; (6114–6115): "Long Peace of wellnigh two hundred years".
- Ch14 (6360–6362): Gelion "rose in two sources… two branches"; six tributaries from Ered Luin; Ossiriand = Land of SEVEN Rivers (Gelion+6).
- Ch4/5: none numeric. Ch12: none numeric.
- Fëanor doom "for twelve years thou shalt leave Tirion" (ch7, 4089); ten thousand centuries weariness figure (ch1, 2847) — non-spatial.
- Noldor exodus: "but one tithe refused to take the road" (ch9, 4685).

## S3 ITINERARIES
A. Great Journey (ch3, 3350–3414; ch5):
1. Depart Cuiviénen (bay of Inland Sea of Helcar, east+north); "passing northward about the Sea of Helcar they turned towards the west" (3352–3353); black clouds over the northern ruins of war; some turn back.
2. Long pathless march west; hosts halt whenever Oromë departs.
3. Through a forest to "a great river, wider than any they had yet seen" = Anduin the Great; beyond it the Hithaeglir, "reared by Melkor to hinder the riding of Oromë" (3368–3377).
4. Teleri "abode long on the east bank"; Vanyar+Noldor cross, "into the passes of the mountains" (3377–3380). Lenwë's Nandor secede "southwards down the great river" (3384–3387).
5. Vanyar+Noldor "came over Ered Luin" into Beleriand; foremost "passed over the Vale of Sirion" to the Sea "between Drengist and the Bay of Balar" (3396–3401).
6. Teleri later cross Misty Mountains + Eriador, over Ered Luin into EAST Beleriand; dwell "beyond the River Gelion" (3406–3414). Oromë avoided the far north because of the ice-strait (3490–3496).
7. Ferry: Ulmo anchors island in Bay of Balar; Vanyar+Noldor ferried to Aman (3505–3511). Teleri move to Mouths of Sirion coast; later ferried; island halted and rooted in Bay of Eldamar = Tol Eressëa (3563–3576). Falathrim remain (Brithombar, Eglarest). Denethor's Nandor later cross Ered Luin into Ossiriand "ere the rising of the Moon" (3393–3395).

B. Melkor's flight (ch7–9): Formenos → through Calacirya → seen from Túna → north past Alqualondë "towards Araman" (feint) → secretly "far to the south" → Avathar (4154–4184). With Ungoliant: climb Hyarmentir → north over fields of Valinor → Ezellohar (Trees slain) → north through Araman → mists of Oiomúrë → across Helcaraxë → "north of the Outer Lands" → lands "north of the Firth of Drengist" (Lammoth strife) → ruins of Angband; rebuild, rear Thangorodrim (4443–4524).

C. Fëanor's host (ch9, ch13): Tirion → north "along the coasts of Elendë" → Alqualondë (Kinslaying; seize ships) → north by ship and land → Araman (Doom of Mandos) → at the narrowest sea "steering east and somewhat south he passed over" → landing "at the mouth of the firth… called Drengist" in Lammoth; ships burned at Losgar "at the outlet of the Firth" (4735–4945). Then up the Firth through Ered Lómin into Hithlum → north shore of Lake Mithrim (5656–5661). After Dagor-nuin-Giliath, pursuit over Ered Wethrin to Ard-galen → Dor Daedeloth confines; Fëanor dies near Eithel Sirion pass (5674–5710).
D. Fingolfin's host (ch9, ch11, ch13): abandoned in Araman → "into the bitterest North" → crossed Helcaraxë (Elenwë lost) → entered Middle-earth at first Moonrise (4959–4969; 5394–5396) → marched into Mithrim at first Sunrise; passed through Dor Daedeloth to Angband's gates, then back; camp on north shore of Lake Mithrim (5760–5780). Ch13 (6089–6092) confirms the route: down "the coasts to the Firth of Drengist, by the route that Fingolfin followed from the Grinding Ice… into the realm of Hithlum from the west" [i.e. Fingolfin entered Hithlum from the west via the Drengist coast].
E. Post-settlement moves (ch13): Fëanoreans → south shore of Mithrim → east beyond Aros to Himring region (March of Maedhros); Caranthir → Thargelion/Lake Helevorn; Turgon → Nevrast (Vinyamar) → later Tumladen; Finrod → Tol Sirion → Nargothrond.
