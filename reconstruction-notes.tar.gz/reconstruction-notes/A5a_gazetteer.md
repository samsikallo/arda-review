# A5a — Gazetteer: world structure, Aman, early Middle-earth (Ainulindalë–ch9, ch11–12)
Line refs = A_silmarillion.txt. Quotes trimmed.

## World structure
- Arda: "globed amid the Void" (Ainulindalë, 1990); habitation "amid the innumerable stars" (2027).
- Two Lamps (ch1): pillars "more lofty far" than later mountains (2568); Illuin raised "near to the north of Middle-earth"; Ormal "in the south" (2569–2571); light everywhere, "changeless day".
- Almaren (ch1): first Valar dwelling, "Isle of Almaren in the Great Lake", in "the midmost parts of the Earth" where both Lamp-lights blended (2582–2584).
- Utumno (ch1): delved "deep under Earth, beneath dark mountains" where Illuin's beams were "cold and dim" (2612–2614) — i.e. far north, at the light-fringe. Melkor came "far in the north" over the Walls of the Night (2609–2610).
- Fall of the Lamps (ch1): pillars cast down; "lands were broken and seas arose in tumult"; Arda's "symmetry of its waters and its lands was marred"; first designs "never after restored" (2624–2630). Editorial map caption equates Helkar=Illuin, Ringil=Ormal sites (2632–2633).
- Aman (ch1): "westernmost of all lands upon the borders of the world"; west shores on Ekkaia, "the Outer Sea… encircling the Kingdom of Arda"; beyond it the Walls of the Night; east shores = "the uttermost end of Belegaer, the Great Sea of the West" (2646–2652).
- Ekkaia width: "How wide is that sea none know but the Valar" (2649).
- Ulmo dwells in the Outer Ocean (2769–2770); Sun after setting rests on the Outer Sea, passes "under the Earth" to the east (ch11, 5425–5431); Moon plunges "in the chasm beyond the Outer Sea" among "the grots and caverns at the roots of Arda" (5451–5453).

## Aman / Valinor
- Pelóri (ch1): raised as fortification "upon the shores of the sea", "highest upon Earth" (2654–2655). Later (ch11) raised higher "east, north, and south"; outer sides sheer, "hard as glass"; only pass = Calacirya, guarded (5483–5501).
- Taniquetil (ch1): highest Pelóri summit, Manwë's throne; also Oiolossë, Elerrína, Amon Uilos; "standing upon the margin of the sea" (2750–2751); view "even into the furthest East" (2661). Valaquenta: halls "above the everlasting snow, upon Oiolossë" (2266–2267). NOTE: name "Ilmarin" does NOT occur in ch1–14 (only Akallabêth 15628 and appendix).
- Valinor: "Behind the walls of the Pelóri" (2662); Valmar "in the midst of the plain beyond the mountains" (2673–2674).
- Ezellohar/Corollairë: green mound of the Two Trees "Before its [Valmar's] western gate" (2674–2675).
- Máhanaxar: "the Ring of Doom near to the golden gates of Valmar" (2680–2681).
- Two Trees: Telperion (silver, elder), Laurelin (gold); 7-hour bloom cycles; Valian day = 12 hours (2701–2713).
- Mandos (Valaquenta 2353–2354): "westward in Valinor". Ch3: halls "built in the west of the land of Aman" (3269–3270). Nienna's halls "west of West, upon the borders of the world", near Mandos; windows "look outward from the walls of the world" (2381–2388).
- Lórien: Irmo's gardens "in the land of the Valar"; lake Lorellin (2364–2369). Melian dwelt there (2482–2483). Aulë's mansions "in the midst of the Blessed Realm" (2732–2733).
- Oromë's woods: "woods that Yavanna brought forth in Valinor" (2418); seen from Hyarmentir in the SOUTH: "Below them lay the woods of Oromë, and westward… fields and pastures of Yavanna"; Valmar visible far NORTH (ch8, 4234–4238).
- Túna/Tirion (ch5): "a gap was made in the great walls of the Pelóri"; in "a deep valley that ran down to the sea" the Eldar raised green hill Túna (3583–3585). Tree-light from west, shadow "ever eastward"; looks east to Bay of Elvenhome, Lonely Isle, Shadowy Seas (3586–3588). Calacirya = "the Pass of Light" (3589). Tirion on Túna's crown; Mindon Eldaliéva, Ingwë's tower, lamp seen far at sea (3594–3597). Fëanor: Tirion "cooped… between the mountains and the sea" (4586–4587).
- Alqualondë (ch5): Olwë's pearl mansions; rock-arch harbour gate; "upon the confines of Eldamar, north of the Calacirya, where the light of the stars was bright and clear" (3689–3690). Confirmed by ch7: Melkor fled through Calacirya, "thence he had turned northward", seen passing Alqualondë "towards Araman" (4154–4159).
- Tol Eressëa (ch5): island used as ferry, anchored finally "in the Bay of Eldamar" (3575); Ossë "rooted it to the foundations of the sea" (3566–3567); Teleri there "within sight of Aman" (3577). Its broken "eastern horn" off Sirion's mouths = Isle of Balar (3512–3515).
- Formenos (ch7): Fëanor's banishment stronghold, "northward in Valinor… in the hills" (4098–4100).
- Avathar (ch8): "That narrow land lay south of the Bay of Eldamar, beneath the eastern feet of the Pelóri", shores stretching south, "lightless and unexplored" (4184–4187). Ungoliant's abode, ravine/cleft of the mountains. Hyarmentir: "highest mountain in that region", "far south of great Taniquetil" (4225–4227). West of Pelóri there = "an empty land in twilight" (4227–4228).
- Araman (ch9): "lay northward between the Mountains of the Pelóri and the Great Sea, as Avathar lay to the south; but Araman was a wider land"; barren plains "ever colder as the Ice drew nearer" (4444–4448); mists of Oiomúrë before Helcaraxë (4450).
- Helcaraxë (ch5, ch9): in the far north "only a narrow sea divided Aman… filled with grinding ice" (3492–3494); strait where Aman "curved eastward" and Endor "bore westward"; Encircling Sea + Belegaer waters mix; "clashing hills of ice" (4895–4901).
- Enchanted Isles (ch11): "strung as a net in the Shadowy Seas from the north to the south, before Tol Eressëa" (5505–5507).

## Early Middle-earth
- Angband founded (ch3): "a fortress and armoury not far from the north-western shores of the sea, to resist any assault that might come from Aman"; commanded by Sauron (3060–3064).
- Cuiviénen (ch3): "far off in the east of Middle-earth, and northward"; "a bay in the Inland Sea of Helcar"; Helcar "stood where aforetime the roots of the mountain of Illuin had been" (3117–3121); waters flowing "from heights in the east" (3122).
- Orocarni (ch3): Oromë "turned north by the shores of Helcar and passed under the shadows of the Orocarni, the Mountains of the East" (3132–3134).
- Battle of the Powers (ch3): fought "in the North-west of Middle-earth" (3225); Great Sea "grew wide and deep"; "a deep gulf to the southward" (the Great Gulf); lesser bays between Great Gulf and Helcaraxë; chief = Bay of Balar; Sirion flows into it "from the new-raised highlands northwards: Dorthonion, and the mountains about Hithlum" (3236–3245). Vaults under "Angband and Utumno" not all found (3256–3258).
- Hildórien (ch12): Men awoke there "in the eastward regions of Middle-earth" at first Sunrise; first Sun "arose in the West", Men wandered toward it (5538–5543). No Vala came there.
- Nan Elmoth (ch4): starlit wood where Elwë met Melian; they later ruled from Menegroth in Doriath (3443–3473).
